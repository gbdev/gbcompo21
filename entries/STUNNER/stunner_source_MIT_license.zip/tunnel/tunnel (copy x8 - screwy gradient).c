#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>

#include <gb/bgb_emu.h>

// C99 comment test. Oh, thank god. 
// Anyway - Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Notably, this code initially uses an interrupt every scanline, which is undesirable, 
		// since we need all the cycles we can get for some indirection-heavy rendering. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 
// Hang on, I think this does do minimal scanline interrupts. 
	// It's not just a comparator. It sets LYC_REG - which is the switch() variable.

/*
// Banged this out in JS console because GBDK has no trig library. 
for( j = 0; j < 1; j++ ) { 
n = 0; d = 0; p = 0; z = 0; t += 1; screen = ""; ymax = 18; xmax = 20; 
for( sy = 0; sy < ymax; sy++ ) { screen += "\n"; 
for( sx = 0; sx < xmax; sx++ ) { 
x = sx - (xmax-1)/2; y = sy - (ymax-1)/2; y *= -1; 
d = Math.hypot( x, y ); 
z = 180/d;
if( x > 0  && y > 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) } 
else if ( x < 0 && y > 0 ) { n = parseInt( 180 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
else if ( x < 0 && y < 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) + 180 }
else if ( x > 0 && y < 0 ) { n = parseInt( 360 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
p = n % 120  > 120/2; 
p = p ^ ( z % 10 > 5 ); 
screen += parseInt( z ) + ", " ; }  } console.log( screen ); }
*/

// These might become un-const so we can modify them on-the-fly. 
// And they might be better off as one table with interleaved elements because consecutive reads are cheaper. 
// For now, clarity is key. 
const uint8_t distance_table[] = { 14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 254, 254, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 254, 254, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14 };

const uint8_t angle_table[] = { 
98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 44, 40, 36, 34, 32, 29, 
100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 41, 37, 34, 32, 29, 27, 
103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 39, 34, 32, 28, 26, 24, 
105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 35, 32, 28, 25, 22, 21, 
109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 32, 27, 24, 21, 19, 17, 
113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 26, 22, 19, 17, 15, 14, 
117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 20, 17, 14, 12, 11, 9, 
121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 12, 10, 8, 7, 7, 5, 
125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 4, 3, 2, 2, 2, 2, 
130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 251, 251, 252, 253, 253, 253, 
133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 242, 244, 246, 247, 248, 249, 
137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 234, 238, 240, 242, 243, 245, 
142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 228, 232, 235, 237, 239, 241, 
145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 224, 227, 231, 233, 236, 237, 
149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 219, 224, 226, 229, 232, 233, 
152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 216, 220, 224, 226, 228, 231, 
155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 213, 217, 220, 224, 226, 228, 
157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 211, 214, 218, 221, 224, 226 }; 



const unsigned char std_data[] = { 

  /* Basic tiles (0xFC to 0xFF) */
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,
  0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00

};

/* 
I fucking hate dealing with bitmasks in hex, but binary is so verbose. 

0000 = 0
0001 = 1
0010 = 2
0011 = 3

0100 = 4
0101 = 5
0110 = 6
0111 = 7

1000 = 8
1001 = 9
1010 = A
1011 = B

1100 = C
1101 = D
1110 = E
1111 = F

*/

const unsigned char gradient_data[] = { 

	/* 0xFF to 0x00, presumably white to black */
	/* 0b1010 = A, 0b0101 = 5 */
	// Black. Black / dark. Dark. Dark / light. Light. Light / white. White. 
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 		// Black
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// 11 / 10


	0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF, 		// Dark
	0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 

	0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00, 		// Light
	0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 






	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 		// White

};

const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
const uint8_t * scanline_offsets = scanline_offsets_tbl;

#define SCROLL_POS 15
#define SCROLL_POS_PIX_START (SCROLL_POS * 8) - 1
#define SCROLL_POS_PIX_END ((SCROLL_POS + 1) * 8) - 1

uint8_t scroller_x = 0;

void scanline_isr() {
	switch ( LYC_REG ) {
		case 0: 
			SCX_REG = 0;
			LYC_REG = SCROLL_POS_PIX_START;
			break;
		case SCROLL_POS_PIX_START:
			SCX_REG = scroller_x;
			LYC_REG = SCROLL_POS_PIX_END;
			break;
		case SCROLL_POS_PIX_END:
			SCX_REG = LYC_REG = 0;
			break;
	}
}

uint8_t sy = 0; 

void half_tile_isr() { 
//	LYC_REG += 4;
	LYC_REG = sy * 4;    
	SCY_REG = sy * 8;
	SCX_REG = sy * 8; 
	sy++; 
//	SCY_REG += 4; 
//	SCX_REG += 4; 
	// if( last scanline ) could go here, but should be in vblank interrupt. 
	// Wait, does this show the tops of some rows but the bottoms of others? Why? 
	// What exactly is LYC counting? Nothing: it's LY compare. 
		// So what exactly is LY counting? LCDC Y-coordinate. 
	// So this should be, every 4 scanlines, we advance the scroll register by four scanlines. 
	// LY 0: LYC 0+4 = 4, SCY 0+4 = 4. 
	// LY 4: LYC 4+4 = 8, SCY scrolled by 4, so 4(+4)+4 = 12. 
	// LY 8: LYC 8+4 = 12, SCY 12(+4)+4 = 20. 
	// That's halfway down the first tile, halfway down the second tile, halfway down the third tile... 
		// so why is it fucky? Or... is it? 
	// It's definitely a little fucky, with the top row being taller... and also sometimes tearing. 
	// Okay. Replaced that with an absolute scroll value calculation. How is it still not the tops of tiles? 
}

void my_vblank_isr() { 
	LYC_REG = 0; 
//	SCY_REG = -4; 		// Politely warns about overflow, but I know it's 251 or whatever. 
	SCY_REG = 0;
//	SCX_REG = 0; 
	sy = 0; 
}

const uint8_t scroller_text[] = "This is a text scroller demo for GBDK-2020. You can use ideas, that are "\
"shown in this demo, to make different parallax effects, scrolling of tilemaps which are larger than 32x32 "\
"tiles and TEXT SCROLLERS, of course! Need to write something else to make this text longer than 256 characters. "\
"The quick red fox jumps over the lazy brown dog. 0123456789.          ";

const uint8_t* scroller_next_char = scroller_text;
uint8_t* scroller_vram_addr;
uint16_t base, limit;

uint8_t* vram_pointer; 



uint8_t outbyte, angle, distance, input; 		// Scratch variables 
uint8_t rotation = 0; 		// Game state



void main() {
	printf( "Scrolling %d chars", sizeof( scroller_text ) - 1 );

	set_bkg_data(0xFC, 0x04, std_data);
//	set_bkg_data(0x00, 0x04, std_data); 		// Debug
	set_bkg_data(0x00, 0x04, gradient_data); 		// Debug  



	// Ditch this for right now because it's a performance impact. I assume. 
	// Actually, this every-single-scanline thing is a valuable benchmark: the worst-case scenario. 
	// If it somehow does not wreck performance then we can go wild. 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
//		add_LCD( half_tile_isr );
//		add_VBL( my_vblank_isr ); 		// Two hard problems. 
//		set_interrupts( VBL_IFLAG | LCD_IFLAG );
		set_interrupts( VBL_IFLAG );
	}


	scroller_vram_addr = get_bkg_xy_addr( 20, SCROLL_POS );
	set_vram_byte( scroller_vram_addr, *scroller_next_char - 0x20 );

	base = (uint16_t) scroller_vram_addr & 0xffe0;
	limit = base + 0x20;

	while ( 1 ) {
		scroller_x++;
#if 0 		// These are so much nicer than /* */. They nest! 
		// Supports binary literals! Already better than Open Watcom. 
//		if ( ( scroller_x & 0x07 ) == 0 ) {
		if ( ( scroller_x & 0b00000111 ) == 0 ) {
			// next letter
			scroller_next_char++;
			if ( *scroller_next_char == 0 ) {
				scroller_next_char = scroller_text;
			}
			
			// next vram position
			scroller_vram_addr++;
			if ( scroller_vram_addr == (uint8_t*) limit ) {
				scroller_vram_addr = (uint8_t *) base;
			}
			
			// put next char
			// Gonna bet set_vram_byte is very safe and therefore dog-slow. 
//			set_vram_byte( scroller_vram_addr, *scroller_next_char - 0x20 );
		}
#endif

		// Okay. Start at 0,0. Draw 20 or 21 tiles. Repeat for 18 or 19 rows. 
		// Just testing speed - so we want to check for the end of the string, but don't -need- to. 
		// God, it is always the simple shit that's the worst.
			// I have a Y loop and an X loop. 
			// The X loop previously worked alright - printing a run of characters onto the screen, badly. 
			// Quality didn't matter: proof of concept. 
			// But now it just draws one column of characters. 
			// Put pointer placement in the y loop, dumbass. 
		// Okay - already a performance issue. This takes three refreshes to update. 
		// Surely I can just throw bytes into VRAM addresses. 
			// Severely overthinking this: *vram_pointer = *scroll_next_char. 
			// Still 30 Hz. And obviously buggy, because of VRAM access limits. 
			// Ignoring vblank and just constantly throwing bytes is visibly a bit faster. 
			// Do we really care about the bugs? If we're always drawing, 
				// we don't mind some missing tiles. They'll get got. 
		// Accurate framerate requires some vblank counting. (Fuck hblanks, just average.) 
		// Skip all this for a moment and draw a number. 
		// Nah, fuck it, get correct behavior first. 
		// Make it work - make it fast - make it pretty. In that order. 

		// Input is with joypad(). 
		scroller_next_char = scroller_text + scroller_x; 		// Limited to 256 because scroller_x is uint8_t. 
//		rotation += 1; 
		input = joypad(); 
		if( input & J_LEFT ) { rotation -= 10; } 
		if( input & J_RIGHT ) { rotation += 10; } 
		for( uint8_t y = 0; y < 19; y++ ) { 
			vram_pointer = get_bkg_xy_addr( 0, y );
			for( uint8_t x = 0; x < 20; x++ ) { 
//				*(vram_pointer++) = *(scroller_next_char++) - 0x20; 

//				set_vram_byte( vram_pointer, *scroller_next_char - 0x20 );
//				set_vram_byte( vram_pointer, x + 20*y );
				
//				set_vram_byte( vram_pointer, (uint8_t) distance_table[ x + 20*y] + scroller_x );
//				outbyte = distance_table[ x + 20*y] + angle_table[ x + 20*y] % 128 + scroller_x;
				distance = distance_table[ x + 20*y] + scroller_x;  
				outbyte = distance; 
//				outbyte += ( angle_table[ x + 20*y] / 2 ) % 2; 		// Oh wow, division and/or modulo is slow as hell. 
//				outbyte += angle_table[ x + 20*y] >> 4; 
//				if( angle_table[ x + 20*y] >> 5 & 0x1 ) { outbyte += 80; }
				angle = angle_table[ x + 20*y] + rotation; 
				if( angle >> 5 & 0x1 ) { outbyte += 80; }  
//				outbyte %= 128; 
//				if( distance & 0x10 ) { outbyte += 128; } 		// Bit busy for now.

//				outbyte = outbyte & 0b11000000;
//				outbyte = outbyte >> 6; 
				outbyte = distance >> 4; 
				
//				if( ( distance & 0b11100 ) == 0 ) { outbyte = 255; }  

				set_vram_byte( vram_pointer, outbyte );
				scroller_next_char++; 
				vram_pointer++; 

			}
		}

		wait_vbl_done();		// Why does this wait for vblank to finish instead of start? 
//		wait_vbl_start(); 		// Worth a shot. DNE. 
		// https://gbdk-2020.github.io/gbdk-2020/docs/api/gb_8h.html
		// Why the fuck is there no function to halt until vblank STARTS?
		// Surely it's not complicated. There's a start-of-vblank interrupt enabled by default. 
	}
}













