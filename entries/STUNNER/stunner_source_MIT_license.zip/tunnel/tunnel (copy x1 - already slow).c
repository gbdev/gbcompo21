#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>

#include <gb/bgb_emu.h>

// C99 comment test. Oh, thank god. 
// Anyway - Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Notably, this code initially uses an interrupt every scanline, which is undesirable, 
		// since we need all the cycles we can get for some indirection-heavy rendering. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 

const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
const uint8_t * scanline_offsets = scanline_offsets_tbl;

#define SCROLL_POS 15
#define SCROLL_POS_PIX_START (SCROLL_POS * 8) - 1
#define SCROLL_POS_PIX_END ((SCROLL_POS + 1) * 8) - 1

uint8_t scroller_x = 0;

void scanline_isr() {
	switch ( LYC_REG ) {
		case 0: 
			SCX_REG = 0;
			LYC_REG = SCROLL_POS_PIX_START;
			break;
		case SCROLL_POS_PIX_START:
			SCX_REG = scroller_x;
			LYC_REG = SCROLL_POS_PIX_END;
			break;
		case SCROLL_POS_PIX_END:
			SCX_REG = LYC_REG = 0;
			break;
	}
}

const uint8_t scroller_text[] = "This is a text scroller demo for GBDK-2020. You can use ideas, that are "\
"shown in this demo, to make different parallax effects, scrolling of tilemaps which are larger than 32x32 "\
"tiles and TEXT SCROLLERS, of course! Need to write something else to make this text longer than 256 characters. "\
"The quick red fox jumps over the lazy brown dog. 0123456789.          ";

const uint8_t* scroller_next_char = scroller_text;
uint8_t* scroller_vram_addr;
uint16_t base, limit;

uint8_t* vram_pointer; 

void main() {
	printf( "Scrolling %d chars", sizeof( scroller_text ) - 1 );

/*
	// Ditch this for right now because it's a performance impact. I assume. 
	// Actually, this every-single-scanline thing is a valuable benchmark: the worst-case scenario. 
	// If it somehow does not wreck performance then we can go wild. 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
		add_LCD( scanline_isr );
		set_interrupts( VBL_IFLAG | LCD_IFLAG );
	}
*/

	scroller_vram_addr = get_bkg_xy_addr( 20, SCROLL_POS );
	set_vram_byte( scroller_vram_addr, *scroller_next_char - 0x20 );

	base = (uint16_t) scroller_vram_addr & 0xffe0;
	limit = base + 0x20;

	while ( 1 ) {
		scroller_x++;
		// Supports binary literals! Already better than Open Watcom. 
//		if ( ( scroller_x & 0x07 ) == 0 ) {
		if ( ( scroller_x & 0b00000111 ) == 0 ) {
			// next letter
			scroller_next_char++;
			if ( *scroller_next_char == 0 ) {
				scroller_next_char = scroller_text;
			}
			
			// next vram position
			scroller_vram_addr++;
			if ( scroller_vram_addr == (uint8_t*) limit ) {
				scroller_vram_addr = (uint8_t *) base;
			}
			
			// put next char
			// Gonna bet set_vram_byte is very safe and therefore dog-slow. 
//			set_vram_byte( scroller_vram_addr, *scroller_next_char - 0x20 );
		}

		// Okay. Start at 0,0. Draw 20 or 21 tiles. Repeat for 18 or 19 rows. 
		// Just testing speed - so we want to check for the end of the string, but don't -need- to. 
		// God, it is always the simple shit that's the worst.
			// I have a Y loop and an X loop. 
			// The X loop previously worked alright - printing a run of characters onto the screen, badly. 
			// Quality didn't matter: proof of concept. 
			// But now it just draws one column of characters. 
			// Put pointer placement in the y loop, dumbass. 
		// Okay - already a performance issue. This takes three refreshes to update. 
		scroller_next_char = scroller_text + scroller_x; 		// Debug 
		for( uint8_t y = 0; y < 19; y++ ) { 
			vram_pointer = get_bkg_xy_addr( 0, y );
			for( uint8_t x = 0; x < 21; x++ ) { 
				set_vram_byte( vram_pointer, *scroller_next_char - 0x20 );
				scroller_next_char++; 
				vram_pointer++; 
			}
		}
		wait_vbl_done();		// Why does this wait for vblank to finish instead of start? 
	}
}













