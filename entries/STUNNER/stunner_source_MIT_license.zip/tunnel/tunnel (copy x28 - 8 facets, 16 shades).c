#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>		// For e.g. abs()

#include <gb/bgb_emu.h>

// C99 comment test. Oh, thank god. 
// Anyway - Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Notably, this code initially uses an interrupt every scanline, which is undesirable, 
		// since we need all the cycles we can get for some indirection-heavy rendering. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 
// Hang on, I think this does do minimal scanline interrupts. 
	// It's not just a comparator. It sets LYC_REG - which is the switch() variable.

/*
// Banged this out in JS console because GBDK has no trig library. 
for( j = 0; j < 1; j++ ) { 
n = 0; d = 0; p = 0; z = 0; t += 1; screen = ""; xmax = 20; ymax = 32;
for( sy = 0; sy < ymax; sy++ ) { screen += "\n"; 
for( sx = 0; sx < xmax; sx++ ) { 
x = sx - ( (ymax/xmax) * xmax - 1 ) / 2; y = sy - (ymax-1)/2; y *= -1; 
d = Math.hypot( x * 20 / xmax, y * 18 / ymax ); 
z = 128/(d+0.5);
if( x > 0  && y > 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) } 
else if ( x < 0 && y > 0 ) { n = parseInt( 180 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
else if ( x < 0 && y < 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) + 180 }
else if ( x > 0 && y < 0 ) { n = parseInt( 360 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
p = n % 120  > 120/2; 
p = p ^ ( z % 10 > 5 ); 
screen += parseInt( n * 256 / 360 ) + ", " ; }  } console.log( screen ); }
*/

// These might become un-const so we can modify them on-the-fly. 
// And they might be better off as one table with interleaved elements because consecutive reads are cheaper. 
// For now, clarity is key. 
const uint8_t distance_table[] = 
/* 		// Original take, but with central 254 block -> 128s
{ 14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 128, 128, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 128, 128, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14 };
*/


		// Z > 1, avoiding extremey distant middle pixels. 
{ 13, 13, 14, 15, 16, 16, 17, 18, 18, 18, 18, 18, 18, 17, 16, 16, 15, 14, 13, 13, 
13, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 13, 
14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 
15, 16, 17, 18, 20, 22, 23, 25, 26, 27, 27, 26, 25, 23, 22, 20, 18, 17, 16, 15, 
15, 16, 18, 20, 22, 24, 26, 29, 31, 32, 32, 31, 29, 26, 24, 22, 20, 18, 16, 15, 
16, 17, 19, 21, 23, 26, 30, 33, 37, 39, 39, 37, 33, 30, 26, 23, 21, 19, 17, 16, 
16, 18, 20, 22, 25, 29, 33, 39, 45, 50, 50, 45, 39, 33, 29, 25, 22, 20, 18, 16, 
16, 18, 20, 23, 26, 31, 37, 45, 57, 69, 69, 57, 45, 37, 31, 26, 23, 20, 18, 16, 
17, 18, 21, 23, 27, 32, 39, 50, 69, 105, 105, 69, 50, 39, 32, 27, 23, 21, 18, 17, 
17, 18, 21, 23, 27, 32, 39, 50, 69, 105, 105, 69, 50, 39, 32, 27, 23, 21, 18, 17, 
16, 18, 20, 23, 26, 31, 37, 45, 57, 69, 69, 57, 45, 37, 31, 26, 23, 20, 18, 16, 
16, 18, 20, 22, 25, 29, 33, 39, 45, 50, 50, 45, 39, 33, 29, 25, 22, 20, 18, 16, 
16, 17, 19, 21, 23, 26, 30, 33, 37, 39, 39, 37, 33, 30, 26, 23, 21, 19, 17, 16, 
15, 16, 18, 20, 22, 24, 26, 29, 31, 32, 32, 31, 29, 26, 24, 22, 20, 18, 16, 15, 
15, 16, 17, 18, 20, 22, 23, 25, 26, 27, 27, 26, 25, 23, 22, 20, 18, 17, 16, 15, 
14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 
13, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 13, 
13, 13, 14, 15, 16, 16, 17, 18, 18, 18, 18, 18, 18, 17, 16, 16, 15, 14, 13, 13 };


/*
		// Formula with hypot() accounting for xmax and ymas.
{ 9, 10, 10, 11, 12, 12, 13, 13, 14, 14, 14, 14, 13, 13, 12, 12, 11, 10, 10, 9, 
10, 10, 11, 12, 13, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 13, 12, 11, 10, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 22, 24, 25, 25, 24, 22, 20, 18, 16, 15, 13, 12, 11, 
12, 13, 14, 16, 18, 20, 23, 26, 29, 31, 31, 29, 26, 23, 20, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 29, 37, 48, 61, 61, 48, 37, 29, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 106, 106, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 106, 106, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 29, 37, 48, 61, 61, 48, 37, 29, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 20, 23, 26, 29, 31, 31, 29, 26, 23, 20, 18, 16, 14, 13, 12, 
11, 12, 13, 15, 16, 18, 20, 22, 24, 25, 25, 24, 22, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 10, 11, 12, 13, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 13, 12, 11, 10, 10, 
9, 10, 10, 11, 12, 12, 13, 13, 14, 14, 14, 14, 13, 13, 12, 12, 11, 10, 10, 9 };
*/

/*
		// 32x20 version for 6-scanline-tall tile compression.
{ 9, 10, 10, 11, 11, 12, 12, 13, 13, 13, 13, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
9, 10, 11, 11, 12, 13, 13, 14, 14, 14, 14, 14, 14, 13, 13, 12, 11, 11, 10, 9, 
10, 10, 11, 12, 12, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 12, 12, 11, 10, 10, 
10, 11, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 15, 14, 13, 12, 11, 11, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 11, 12, 13, 14, 16, 17, 18, 19, 19, 19, 19, 18, 17, 16, 14, 13, 12, 11, 10, 
11, 12, 13, 14, 15, 17, 18, 20, 21, 21, 21, 21, 20, 18, 17, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 19, 21, 23, 24, 24, 23, 21, 19, 18, 16, 14, 13, 12, 11, 
11, 12, 14, 15, 17, 19, 21, 23, 25, 26, 26, 25, 23, 21, 19, 17, 15, 14, 12, 11, 
11, 13, 14, 16, 18, 20, 23, 25, 28, 30, 30, 28, 25, 23, 20, 18, 16, 14, 13, 11, 
12, 13, 14, 16, 18, 21, 24, 28, 32, 35, 35, 32, 28, 24, 21, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 50, 50, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 29, 38, 50, 64, 64, 50, 38, 29, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 86, 86, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 119, 119, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 119, 119, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 86, 86, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 29, 38, 50, 64, 64, 50, 38, 29, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 50, 50, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 21, 24, 28, 32, 35, 35, 32, 28, 24, 21, 18, 16, 14, 13, 12, 
11, 13, 14, 16, 18, 20, 23, 25, 28, 30, 30, 28, 25, 23, 20, 18, 16, 14, 13, 11, 
11, 12, 14, 15, 17, 19, 21, 23, 25, 26, 26, 25, 23, 21, 19, 17, 15, 14, 12, 11, 
11, 12, 13, 14, 16, 18, 19, 21, 23, 24, 24, 23, 21, 19, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 17, 18, 20, 21, 21, 21, 21, 20, 18, 17, 15, 14, 13, 12, 11, 
10, 11, 12, 13, 14, 16, 17, 18, 19, 19, 19, 19, 18, 17, 16, 14, 13, 12, 11, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 11, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 15, 14, 13, 12, 11, 11, 10, 
10, 10, 11, 12, 12, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 12, 12, 11, 10, 10, 
9, 10, 11, 11, 12, 13, 13, 14, 14, 14, 14, 14, 14, 13, 13, 12, 11, 11, 10, 9, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 13, 13, 13, 13, 12, 12, 11, 11, 10, 10, 9 }; 
*/

/*
		// Aspect ratio correction. (Still fucky.)
{ 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 17, 19, 20, 22, 22, 22, 22, 20, 19, 17, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 20, 21, 23, 24, 24, 23, 21, 20, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 23, 24, 26, 26, 24, 23, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 14, 15, 17, 19, 21, 24, 26, 27, 27, 26, 24, 21, 19, 17, 15, 14, 12, 11, 
11, 13, 14, 16, 17, 20, 22, 25, 28, 30, 30, 28, 25, 22, 20, 17, 16, 14, 13, 11, 
12, 13, 14, 16, 18, 20, 23, 27, 30, 33, 33, 30, 27, 23, 20, 18, 16, 14, 13, 12, 
12, 13, 14, 16, 18, 21, 25, 29, 33, 36, 36, 33, 29, 25, 21, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 30, 36, 40, 40, 36, 30, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 23, 27, 32, 39, 45, 45, 39, 32, 27, 23, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 51, 51, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 24, 29, 37, 47, 59, 59, 47, 37, 29, 24, 20, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 30, 38, 52, 70, 70, 52, 38, 30, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 84, 84, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 104, 104, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 124, 124, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 124, 124, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 104, 104, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 84, 84, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 30, 38, 52, 70, 70, 52, 38, 30, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 20, 24, 29, 37, 47, 59, 59, 47, 37, 29, 24, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 51, 51, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 23, 27, 32, 39, 45, 45, 39, 32, 27, 23, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 30, 36, 40, 40, 36, 30, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 21, 25, 29, 33, 36, 36, 33, 29, 25, 21, 18, 16, 14, 13, 12, 
12, 13, 14, 16, 18, 20, 23, 27, 30, 33, 33, 30, 27, 23, 20, 18, 16, 14, 13, 12, 
11, 13, 14, 16, 17, 20, 22, 25, 28, 30, 30, 28, 25, 22, 20, 17, 16, 14, 13, 11, 
11, 12, 14, 15, 17, 19, 21, 24, 26, 27, 27, 26, 24, 21, 19, 17, 15, 14, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 23, 24, 26, 26, 24, 23, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 20, 21, 23, 24, 24, 23, 21, 20, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 17, 19, 20, 22, 22, 22, 22, 20, 19, 17, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11 }; 
*/

const uint8_t angle_table[] = 

{ 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 44, 40, 36, 34, 32, 29, 
100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 41, 37, 34, 32, 29, 27, 
103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 39, 34, 32, 28, 26, 24, 
105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 35, 32, 28, 25, 22, 21, 
109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 32, 27, 24, 21, 19, 17, 
113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 26, 22, 19, 17, 15, 14, 
117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 20, 17, 14, 12, 11, 9, 
121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 12, 10, 8, 7, 7, 5, 
125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 4, 3, 2, 2, 2, 2, 
130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 251, 251, 252, 253, 253, 253, 
133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 242, 244, 246, 247, 248, 249, 
137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 234, 238, 240, 242, 243, 245, 
142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 228, 232, 235, 237, 239, 241, 
145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 224, 227, 231, 233, 236, 237, 
149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 219, 224, 226, 229, 232, 233, 
152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 216, 220, 224, 226, 228, 231, 
155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 213, 217, 220, 224, 226, 228, 
157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 211, 214, 218, 221, 224, 226 }; 


/*
		// 32x20 version for compressed display:
{ 95, 93, 90, 87, 84, 81, 77, 73, 69, 65, 61, 57, 53, 49, 46, 42, 39, 36, 34, 32, 
96, 94, 91, 88, 86, 82, 78, 74, 70, 66, 61, 56, 52, 48, 44, 41, 38, 35, 32, 30, 
98, 96, 93, 90, 87, 83, 79, 75, 71, 66, 61, 56, 51, 47, 43, 39, 36, 34, 31, 29, 
99, 97, 94, 91, 88, 84, 81, 76, 71, 66, 61, 56, 51, 46, 42, 38, 35, 32, 29, 27, 
100, 98, 96, 93, 90, 86, 81, 77, 71, 66, 61, 55, 49, 45, 40, 36, 33, 30, 28, 26, 
103, 100, 98, 95, 91, 88, 83, 78, 72, 66, 60, 54, 49, 43, 39, 35, 32, 29, 26, 24, 
104, 103, 100, 97, 93, 90, 85, 79, 73, 66, 60, 53, 47, 41, 36, 33, 29, 27, 24, 22, 
106, 104, 102, 99, 96, 92, 87, 81, 74, 67, 59, 52, 45, 39, 34, 31, 27, 24, 22, 20, 
108, 107, 104, 102, 98, 94, 89, 83, 76, 68, 59, 51, 43, 37, 32, 28, 24, 22, 19, 18, 
110, 109, 107, 104, 101, 97, 92, 86, 78, 68, 58, 49, 41, 34, 29, 25, 22, 19, 17, 16, 
113, 111, 110, 108, 104, 100, 96, 89, 80, 69, 57, 46, 37, 31, 26, 22, 19, 17, 15, 13, 
115, 114, 113, 110, 108, 104, 100, 93, 83, 71, 56, 43, 34, 27, 22, 19, 16, 14, 12, 11, 
118, 117, 115, 114, 112, 109, 104, 98, 88, 72, 54, 39, 29, 22, 17, 14, 12, 11, 9, 8, 
120, 120, 119, 118, 116, 113, 110, 104, 94, 76, 51, 32, 22, 17, 13, 10, 9, 7, 7, 6, 
123, 123, 122, 121, 120, 119, 117, 113, 104, 83, 43, 22, 14, 9, 7, 6, 5, 4, 4, 3, 
126, 125, 125, 125, 125, 125, 123, 122, 119, 104, 22, 7, 4, 3, 2, 2, 1, 1, 1, 0, 
128, 129, 129, 129, 130, 130, 131, 132, 135, 150, 232, 247, 250, 251, 253, 253, 253, 253, 253, 254, 
131, 132, 132, 133, 134, 135, 137, 142, 150, 171, 211, 232, 241, 245, 247, 248, 249, 250, 251, 251, 
134, 135, 135, 137, 138, 141, 145, 150, 160, 179, 204, 222, 232, 238, 241, 244, 246, 247, 248, 248, 
136, 137, 139, 140, 142, 145, 150, 157, 167, 182, 200, 216, 226, 232, 237, 240, 242, 243, 245, 246, 
139, 140, 142, 144, 147, 150, 155, 162, 171, 184, 199, 211, 221, 228, 232, 236, 238, 241, 242, 243, 
141, 143, 145, 147, 150, 154, 159, 165, 174, 185, 197, 208, 217, 224, 228, 232, 236, 238, 239, 241, 
144, 145, 147, 150, 153, 157, 162, 169, 177, 186, 196, 206, 214, 220, 225, 229, 232, 235, 237, 238, 
146, 147, 150, 152, 156, 160, 165, 171, 179, 187, 196, 204, 211, 217, 222, 226, 230, 232, 235, 236, 
148, 150, 152, 155, 159, 162, 167, 173, 180, 187, 195, 202, 209, 215, 220, 224, 227, 230, 232, 234, 
150, 152, 155, 157, 161, 164, 169, 175, 181, 188, 194, 201, 207, 213, 218, 221, 225, 228, 231, 232, 
152, 154, 157, 160, 163, 167, 171, 177, 182, 188, 194, 200, 206, 211, 216, 219, 223, 226, 228, 231, 
154, 156, 158, 161, 164, 168, 173, 177, 183, 189, 194, 199, 205, 209, 214, 218, 221, 224, 226, 228, 
155, 157, 160, 163, 166, 170, 174, 179, 184, 189, 194, 199, 204, 209, 212, 216, 219, 222, 225, 227, 
157, 159, 162, 164, 167, 171, 175, 179, 184, 189, 194, 199, 203, 207, 211, 215, 218, 221, 224, 226, 
158, 160, 163, 166, 169, 172, 176, 180, 184, 189, 194, 198, 202, 206, 210, 214, 216, 219, 222, 224, 
160, 162, 164, 167, 170, 174, 177, 181, 185, 189, 193, 197, 201, 205, 209, 212, 215, 218, 221, 223 }; 
*/

/*
		// Aspect ratio correction, because 32x20 is not remotely square:
{ 96, 94, 93, 91, 89, 88, 86, 83, 81, 79, 77, 75, 72, 70, 67, 64, 62, 59, 56, 54, 
96, 96, 93, 92, 91, 88, 87, 85, 83, 81, 78, 76, 73, 70, 67, 64, 62, 59, 56, 54, 
98, 97, 96, 93, 92, 90, 88, 86, 84, 81, 79, 76, 73, 71, 68, 65, 61, 59, 56, 53, 
100, 98, 97, 96, 93, 92, 90, 88, 85, 83, 80, 77, 74, 71, 68, 65, 61, 59, 55, 52, 
101, 100, 98, 97, 96, 93, 91, 89, 87, 84, 81, 78, 75, 72, 68, 65, 61, 58, 54, 51, 
103, 102, 100, 98, 97, 96, 93, 91, 88, 86, 83, 80, 76, 73, 69, 65, 61, 57, 54, 50, 
105, 103, 102, 100, 99, 97, 96, 93, 91, 88, 85, 81, 78, 73, 69, 66, 61, 57, 53, 49, 
107, 105, 104, 103, 101, 100, 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 
109, 108, 106, 105, 103, 102, 100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 
111, 110, 109, 108, 106, 105, 103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 
113, 113, 111, 110, 109, 108, 105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 
115, 115, 114, 113, 112, 110, 109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 
118, 118, 117, 116, 115, 114, 113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 
120, 120, 120, 119, 118, 118, 117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 
123, 123, 123, 123, 122, 121, 121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 
126, 126, 125, 125, 125, 125, 125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 
128, 128, 129, 129, 129, 129, 130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 
131, 131, 132, 132, 132, 133, 133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 
134, 134, 135, 135, 136, 137, 137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 
136, 137, 137, 138, 139, 140, 142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 
139, 140, 140, 141, 142, 144, 145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 
141, 142, 143, 144, 145, 147, 149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 
143, 145, 145, 147, 148, 150, 152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 
145, 147, 148, 149, 151, 152, 155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 
147, 149, 150, 152, 153, 155, 157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 
150, 151, 152, 154, 155, 157, 160, 162, 164, 167, 169, 173, 177, 181, 185, 189, 194, 197, 201, 206, 
152, 152, 154, 156, 157, 160, 161, 164, 166, 169, 172, 174, 178, 182, 185, 189, 193, 197, 201, 204, 
153, 155, 156, 157, 160, 161, 163, 165, 167, 170, 173, 176, 179, 182, 186, 189, 193, 196, 200, 203, 
155, 156, 157, 160, 161, 162, 164, 167, 169, 172, 174, 177, 180, 183, 187, 189, 193, 196, 199, 202, 
157, 157, 160, 161, 162, 164, 166, 168, 170, 173, 175, 178, 181, 184, 187, 189, 193, 196, 199, 201, 
158, 160, 161, 162, 164, 166, 167, 169, 172, 174, 177, 179, 182, 184, 187, 190, 192, 195, 198, 201, 
160, 160, 162, 164, 165, 167, 169, 171, 173, 175, 177, 179, 182, 184, 187, 190, 192, 195, 198, 200 }; 
*/

/* 
I fucking hate dealing with bitmasks in hex, but binary is so verbose. 

0000 = 0
0001 = 1
0010 = 2
0011 = 3

0100 = 4
0101 = 5
0110 = 6
0111 = 7

1000 = 8
1001 = 9
1010 = A
1011 = B

1100 = C
1101 = D
1110 = E
1111 = F

*/

const unsigned char gradient_data[] = { 

	/* 0xFF to 0x00, presumably white to black */
	/* 0b1010 = A, 0b0101 = 5 */
	// Black. Black / dark. Dark. Dark / light. Light. Light / white. White. 
	// Currently have 13 colors via simple dithering in 4-pixel patterns. Need a few more for easy power-of-two 16. 
	// Could just stuff some duplicate darks in there, for later? Dark is probably where we want more detail. 

	// BB/BB
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 		// Black: 1/1

	// BB/BD
	0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 
	0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 		// Again

	// BD/BD
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// 1/1 + 0/1
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// Again 

	// BD/DD
	0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 
	0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 		// Again 

	// DD/DD
	0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF, 		// Dark: 0/1

	// DD/DL
	0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,

	// DL/DL
	0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA,  	// 0/1 + 1/0 

	// DL/LL
	0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 

	// LL/LL
	0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00, 		// Light: 1/0

	// LL/LW
	0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 

	// LW/LW
	0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 	// 1/0 + 0/0

	// LW/WW
	0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 

	// WW/WW
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 		// White: 0/0
	// This needs to not go white-white.
	// Good answers? Dunno. Just mix with black for now. 

//	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 		// White again

	// BW/BW
	0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA 
		// Black+white

};

const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
const uint8_t * scanline_offsets = scanline_offsets_tbl;

#define SCROLL_POS 15
#define SCROLL_POS_PIX_START (SCROLL_POS * 8) - 1
#define SCROLL_POS_PIX_END ((SCROLL_POS + 1) * 8) - 1

uint8_t scroller_x = 0;

const uint8_t scroller_text[] = "This is a text scroller demo for GBDK-2020. You can use ideas, that are "\
"shown in this demo, to make different parallax effects, scrolling of tilemaps which are larger than 32x32 "\
"tiles and TEXT SCROLLERS, of course! Need to write something else to make this text longer than 256 characters. "\
"The quick red fox jumps over the lazy brown dog. 0123456789.          ";

// Some of these are redundant holdovers from the original text_scroller.c code. I forget which. 
const uint8_t* scroller_next_char = scroller_text;
uint8_t* scroller_vram_addr;
uint16_t base, limit;

uint8_t* vram_pointer; 


// Tube stuff
uint8_t outbyte, angle, distance, input; 		// Scratch variables 
int8_t rotation = 11; 		// Game state
int8_t rotation_impulse = 10;
// FPS stuff
uint16_t line_count = 0; 		// This frame 
uint16_t running_average = 1024; 		// Over time - nonzero initial value






// Interrupt functions

uint8_t sy = 0; 

void half_tile_isr() { 
	// Okay: SCY_REG is a -global- scroll register. It is not "which scanline are we on, right now."
	// It changes which scanline is at the logical top of the screen. 
	// So we can't just sy*8 to go, "next scanline, start drawing from tile row sy."
	// This kinda-sorta makes sense, but it is a tremendous pain in the ass for comprehension, 
		// when mixed with LYC_REG needing a strict objective "where are we NOW?" number. 
	// TL;DR LYC to sy*i and SCY to k where i+k = 8. 
	LYC_REG = sy * 5;    
	SCY_REG += 3; 
//	SCX_REG += 1; 		// Tilting for a turn effect? Eh. 
	sy++; 

	// Debug, making row heights crystal clear:
//	SCX_REG += 128; 

	// So why the fuck is the top row still 7 pixels? Whatever. 
	// I'd have to switch to the window to get 4px-tall tiles. 
	// Or: naive 4px rows, plus a narrow hud at the bottom. linear map, maybe. 
	// Or: 5px rows, and we only waste one scanline. But the dithering might mismatch. (Yeah, it does.) 
	// Dithering could be handled by alternating SCY_REG increments. 

	line_count += 4; 		// FPS guff 
}

void my_vblank_isr() { 
	LYC_REG = 1; 
	SCY_REG = 0;
//	SCX_REG = -16; 
	sy = 1; 
	line_count += 144; 		// FPS tracking. Not 154 because the scanline version doesn't count vblank. 
	line_count += 10; 		// Account for all scanlines. Probably. Might be missing a few anyway. 
}






// Main functionality 

void main() {
//	const uint8_t* angle_table_split = &angle_table[16*20]; 
//	const uint8_t* distance_table_split = &distance_table[16*20]; 
	printf( "Scrolling %d chars", sizeof( scroller_text ) - 1 ); // Need a printf for GBDK to include text characters. 

	// Load tile data to CHR-RAM
	set_bkg_data(0x00, 0x08, gradient_data);
	set_bkg_data(128, 128, gradient_data);  

	// Compression to 4-scanline-high tiles has tolerable performance impact. 
	// It's rendering all those tiles that kills us. 
	// We might go for diagonal tiles and skip scanline shenanigans altogether. 
	// In which case: we do still need VBL_IFLAG. (Or is that just for wait_vbl_done?) 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
//		add_LCD( half_tile_isr );
		add_VBL( my_vblank_isr ); 		// Two hard problems. 
//		set_interrupts( VBL_IFLAG | LCD_IFLAG );
		set_interrupts( VBL_IFLAG );
	}

	// FPS / HUD
	init_win( 6 ); 		// All white, probably. 
//	move_win( 130, 132 ); 		// Lower right corner. X, Y. 
	move_win( 8, 132 ); 		// 8px discrepancy because sprites need to scroll offscreen. Whatever. 
	SHOW_WIN; 		// Equivalent to LCDC_REG|=0x20U

	while ( 1 ) {
		// Book-keeping
		scroller_x++;

		// Surely I can just throw bytes into VRAM addresses. 
			// Severely overthinking this: *vram_pointer = *scroll_next_char. 
			// Ignoring vblank and just constantly throwing bytes is visibly a bit faster. 
			// Do we really care about the bugs? If we're always drawing, 
				// we don't mind some missing tiles. They'll get got. 
		// Accurate framerate requires some vblank counting. (Fuck hblanks, just average.) 
		// Make it work - make it fast - make it pretty. In that order. 

		// Input
		input = joypad(); 
//		if( input & J_LEFT ) { rotation -= 10; } 
//		if( input & J_RIGHT ) { rotation += 10; } 

		if( input & J_LEFT ) { rotation_impulse -= 10; } 		// 10 is good. Maybe a bit squirrely. 
		if( input & J_RIGHT ) { rotation_impulse += 10; } 
		rotation += rotation_impulse; 
		rotation_impulse -= rotation_impulse / 2;
		if( rotation_impulse <= 3 ) { rotation_impulse = 0; } 
		// We should really only push this in the direction of gravity. 
		// It's probably fine. 
		// ... why can you go further right than left? God dammit. 

		// Numeric limits are unnecessary when the impulse is being halved. 
		// Buuut we might need to do this just in case "over the top" results in wild loops. 
//		if( rotation_impulse > 10 ) { rotation_impulse = 40; } 
//		if( rotation_impulse < -10 ) { rotation_impulse = -40; } 

		// Rotation impulse has to change based on rotation, so you can go "over the top." 
		// Durr, over the top, it should speed up. 
		// Okay, that kinda works, but it feels bad right now. Super fast come back around the other side. 
		// Need some limitations on rotation speed, even when falling back down the far side. 
		// And maybe disable up-the-wall controls until you're back down? 
		// Use of negatives might be completely the wrong idea, because it is more hassle to deal with signs. 
		// "Physics" should probably separate gravity (and its direction) from rotation_impulse. 
		// We might never bring the camera over the top. It could be better, overall, to let the car move independently. 
		// Should almost give the car (and/or camera) a proper left/right velocity. Less guesswork, more book-keeping. 

		// Physics
//		rotation -= rotation >> 2; 
		rotation -= rotation / 4; 		// Be safe. 

//		const int8_t slide = rotation >> 2; 
//		rotation -= abs( slide ) > 20 ? 20 : slide; 

//		rotation -= rotation > 0 ? 1 : -1; 
		if( rotation > 0 ) { rotation -= 1; } 
		if( rotation < 0 ) { rotation += 1; }
		// Why does it still balance off-center? 
//		rotation = 1; 
		// It's... centered on 1? The fuck. 

		// Rendering 
		for( uint8_t y = 0; y < 18; y++ ) { 		// 18 naively, 29-32 compressed. 15 for debug. 
			vram_pointer = get_bkg_xy_addr( 0, y );
			for( uint8_t x = 0; x < 20; x++ ) { 
//				const uint16_t index = x + 20*y; 		
					// Add benchmarking before trying this. It's not a guaranteed improvement.

//				set_vram_byte( (vram_pointer++), x + y*16 ); continue; 		// DISPLAY ALL TILES

				distance = distance_table[ x + 20*y ] + 2*scroller_x;  
				angle = angle_table[ x + 20*y] + rotation + 17; 		// 22.5 degree tweak. 17, not 16? The fuck. 

//				if( angle >> 5 & 0x1 ) { outbyte ^= 0x02; }
				outbyte = ( angle >> 5 ); 		// Faux lighting from upper-left. Super good, super easy. 
//				outbyte += ( ( distance - 2 ) & 0x40 ) >> 6; 		// Reasonable pipe segments. &0x20>>5 also works. 
//				outbyte += ( angle - 64 - 8 ) >> 4; 	// Can I do dark top / light bottom, as a bidirectional gradient? Punt. 
//				outbyte = ( angle >> 4 ); 		// 16 shades (1) obviously isn't fake polygons and (2) isn't aligned to +17. 
					// Or I guess it is exactly as aligned, but previously, we wanted the midpoint in the center of 1/8th. 
				outbyte = outbyte << 1; 		// 8 shades for 8 facets, but brighter? Iffy. 
				outbyte += 1; 
//				outbyte += rotation >> 4; 		// Smooth enough, but not -good.- 
				// Get some cheap division into six slices. Doesn't need to be perfect. 
				// 0.1666. 1/8 + 1/32 is within 0.010, like 6%. +1/128 is within 0.0026. 
					// 1/4 - 1/8 is within 0.042. 1/4 - 1/16 is within 0.021. 
					// Could also hit 1/3 or 2/3 and then shift down. 
					// ( 1/2 - 1/8 ) / 2 is within 0.021. Same gimmick above. 
//				outbyte = ( angle >> 2 ) - ( angle >> 3 ); 
//				outbyte = angle / 6; 

/*
				// Achieve a gradient.
				outbyte = ( angle >> 5 ) & 0x1; 		// Alternating binary around the tube. 
				outbyte ^= ( distance >> 5 ) & 0x2; 		// Toggle that binary down the tube? 
				outbyte += distance >> 3; 		// Well, that is... certainly something. 
*/

				// Distance rings. 
				// Experimenting - no cleanup yet. 
				if( ( distance & 0b11100 ) == 0 ) { 
//					if( angle - 17 > 128 ) { 	// Does not rise to the midline on the right-hand side. 
							// I should really just tweak the angle table to get rid of this +/- 16/17. Right? 
					if( angle - 17 > 128 || angle - 17 < 0  ) { 		// Why does <0 work for uint8_t? Whatever. 
						outbyte = 2; 
	//					outbyte -= angle > 128 - 32 ? 1 : 0; 		// Cheap tweak for top part?
	//					outbyte = ( angle + 16 >> 5 );			// Halfway between? Ehhh. 
	//					outbyte = ( angle + 16 >> 6 ) + 1; 		// Darker! Still grey/grey on top. Meh. 
//						outbyte = ( angle + 16 + 32 >> 5 ); 		// Not solid, loosely matches lighting. 
							// Still looks kinda like a feature - like a lip or a choke. Which is undesirable.
	//					outbyte ^= angle >> 7;  		// Suggestive of ribs on the bottom, but... no. 
	/*
						if( outbyte == 2 || outbyte == 3 ) { outbyte ^= 0x1; } 
						outbyte += 3; 		// Average with underlying color? Oh wow that looks good. 
						outbyte /= 2; 
	*/
					}
				}  
				

				// Omnipresent bottom path. 
				// 270-ish degrees, so 192-ish.
				// Maybe only near distance rings / distance struts? Gaps near the middle of each pipe segment. 
				// Arguably unnecessary if we have more consistent shading. 
//				if( angle > 192+8 && angle < 192+24 ) { outbyte = 2; } 

//				outbyte %= 8; 
				outbyte &= 0x0F; 		// 16 shades (at present)
				outbyte |= 0x80; 		// ... placed halfway up the tile list. 

				// Gonna bet set_vram_byte is very safe and therefore dog-slow. (Yep.)
				set_vram_byte( vram_pointer, outbyte );
				scroller_next_char++; 
				vram_pointer++; 

				// Direct writing is faster - e.g. 4.2 FPS vs 3.5 - but the line count is higher. What? 
//				*(vram_pointer++) = outbyte; 		// Still no. Super janky. 

			}
		}

		// Print framerate. Fine performance can be tracked by updating during hblank routine, if needed / applicable. 
		// printf is useless because you can't point it at the right place. 
		// Numeral sprites start at 16. 
		const uint16_t this_frame = line_count; 
		line_count = 0; 
//		running_average += this_frame; 
//		running_average /= 2; 
		running_average = ( running_average << 3 ) - running_average + this_frame; 
		running_average = running_average >> 3; 

//		const uint8_t fps = 60 * running_average / 144;
//		const uint8_t fps = 144 * 60 / this_frame; 
		// Always the basics. I want: frames per second. I have: how many scanlines this frame took. 
		// So time / frames, yeah? But that result looks backwards, given the initial value of running_average. 
		// And it's, like... this_frame = 144 should be 60 Hz. 
		// Yeah, 60 * this_frame / 144 -should- be correct. 
		// 60 / 17, yeah, 4-ish FPS. Our performance just plain sucks. 
		// Except I'm getting sensible results while doing nothing to correct the fixed-point display. 
		// TL;DR this is almost certainly wrong. 

		// FPS is frame count over time. 
		// Our frame count is 1.
		// Time is some number of scanlines. 
		// this_frame == 144 would be 60 Hz. 
		// this_frame = 288 would be 30 Hz.
		// So yeah, 60 * 144 / n = 60, for n = 144, and 60 * 144 / n = 30, for n = 288. 
		// So 60 * 144 / this_frame. 
		// Ah, but we're getting like... 3. So it's showing up as 00.3. 
		// But we overflow if we do 10*60*144 in uint16_t. 
		// GBDK does not appear to support uint32_t. 
		// Good lord, do I have to do long division manually here? 
		// Fuck it, just divide this_frame by 10. 
		// Y'know I could just show line count. Or both, both would work. 

		const uint16_t fps = ( 60 * 144 ) / ( running_average / 10 ); 

		vram_pointer = get_win_xy_addr( 0, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 10) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  14 ); 		// Decimal point. 
		set_vram_byte( ( vram_pointer++ ),  ( (fps ) % 10 ) + 16 );

		// Display raw line_count as well, because why not. 
		vram_pointer = get_win_xy_addr( 6, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (this_frame / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (this_frame / 10) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (this_frame ) % 10 ) + 16 );

		// We don't want to wait unless we're hitting 60 Hz, which, no. 
//		wait_vbl_done();	
	}
}













