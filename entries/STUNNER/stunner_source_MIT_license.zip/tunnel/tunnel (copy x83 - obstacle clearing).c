#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>		// For e.g. abs()
//#include <types.h> 	// For e.g. fixed? galaxy.c doesn't use this. WTF. 

#include <gb/bgb_emu.h>

// Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Notably, this code initially uses an interrupt every scanline, which is undesirable, 
		// since we need all the cycles we can get for some indirection-heavy rendering. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 


//	set_sprite_prop( 0, 0x00 );
	// https://gbdk-2020.github.io/gbdk-2020/docs/api/gb_8h.html#a99ea3252469e3614e977cce2aa1d06f7
	// Sprite property bits. 7: priority, 0 is behind BG. 6: vertical flip. 5: horizontal flip. 4: DMG OBJ palette 0/1. 
		// 3: GBC sprite bank. 2/1/0: GBC palette. 
//	set_sprite_tile( 0, 132 ); 		// Sprite number 0 to 39, CHR-RAM tile number 0 to... 256? GBDK might fudge it to 128. 
		// No, I strongly suspect GBDK accurately reflects the hardware and makes sprite tile 0 = BG tile 128. (Yep.)
		// So I should probably re-aim set_sprite_data. (Did.)
		// Oh why the fuck is it warning about overflow for 128+3? Is it signed? 
		// No - just more stupidity with macros. The actual value is fine. 
//	move_sprite( 0, 160/2, 144/2);



const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
const uint8_t * scanline_offsets = scanline_offsets_tbl;

#define SCROLL_POS 15
#define SCROLL_POS_PIX_START (SCROLL_POS * 8) - 1
#define SCROLL_POS_PIX_END ((SCROLL_POS + 1) * 8) - 1

uint8_t scroller_x = 0;

const uint8_t scroller_text[] = "This is a text scroller demo for GBDK-2020. You can use ideas, that are "\
"shown in this demo, to make different parallax effects, scrolling of tilemaps which are larger than 32x32 "\
"tiles and TEXT SCROLLERS, of course! Need to write something else to make this text longer than 256 characters. "\
"The quick red fox jumps over the lazy brown dog. 0123456789.          ";

// Some of these are redundant holdovers from the original text_scroller.c code. I forget which. 
//const uint8_t* scroller_next_char = scroller_text;
uint8_t* scroller_vram_addr;
uint16_t base, limit;

uint8_t* vram_pointer; 


// Tube stuff
uint8_t outbyte, angle, screen_distance, distance, input, jitter; 		// Rendering scratch variables 
uint8_t scx, scy; 		// Vertical sync / vsync buffers for SCX/SCY_REG

int8_t gravity; 		// Physics scratch 
int8_t rotation = 11; 		// Game state
int8_t rotation_impulse = 10; 		// Input accumulator
int8_t velocity = 0; 		// Necessary for momentum
int16_t curve_x = 0; 		// Curve offset vectors - goofy sampling gimmick
int16_t curve_y = 0; 
uint8_t tube_color[256]; 		// Might make this multi-dimensional. 
	// E.g. tube_color[2][256] for alternating patterns, 
		// or straight-up using this to encode our level designs. 
	// Some map could be sections 0, 0, 0, 7, 3, and that'd be normal shit followed by cutouts or whatever. 
// Eventually need centripital force variable. Though curve info may suffice. (If all tracks are level.) 
uint8_t controls_locked; 		// Boolean. Over-the-top lock. 

// Obstacles
#define MAX_OBSTACLES 32
// Distances should maybe be 16-bit? Or fixed-point, if I can get GBDK to play nice with fixed-point. 
struct obstacle { 
	uint8_t type; 		// 0 for nothing, other values for enemies, barriers, etc. 
	uint8_t location; 		// Distance, basically. Not an ideal name. 
	int8_t orientation; 		// Rotation. Objective placement around the pipe. 
};
struct obstacle obstacles[ MAX_OBSTACLES ]; 
uint8_t hit = 0; 		// Collision indicator, i-frame timer
uint8_t severity = 0; 		// Strength of collision - damage dealt 
uint8_t invincible = 0; 		// Flag for i-frames, and potentially a powerup timer 

// FPS stuff
uint16_t line_count = 0; 		// This frame 
uint16_t running_average = 1024; 		// Over time - nonzero initial value
uint16_t field_count = 1; 		// Number of whole frames to hand-wave, for variable framerate
uint16_t field_overflow = 0; 		// Leftover scanlines, to roll over into whole frames 





/*
// Banged this out in JS console because GBDK has no trig library. 
for( j = 0; j < 1; j++ ) { 
n = 0; d = 0; p = 0; z = 0; t += 1; screen = ""; xmax = 32; ymax = 32;
for( sy = 0; sy < ymax; sy++ ) { screen += "\n"; 
for( sx = 0; sx < xmax; sx++ ) { 
x = ( sx - ( xmax - 1 ) / 2 ); y = ( sy - (ymax-1)/2 ); y *= -1; 
d = Math.hypot( x * 20 / xmax, y * 18 / ymax ); 
z = 128/(d+0.5);
if( x > 0  && y > 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) } 
else if ( x < 0 && y > 0 ) { n = parseInt( 180 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
else if ( x < 0 && y < 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) + 180 }
else if ( x > 0 && y < 0 ) { n = parseInt( 360 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
p = n % 120  > 120/2; 
p = p ^ ( z % 10 > 5 ); 
screen += parseInt( n * 256 / 360 ) + ", " ; }  } console.log( screen ); }
*/

// Might be better off as one table with interleaved elements because consecutive reads are cheaper. 
// Dither these. 
const uint8_t distance_table[] = 
		// 32x32 version - wide, so we can pan, and at least theoretically tall and y-sheared. 
{ 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9, 
9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10, 9, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 14, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 
10, 11, 11, 12, 12, 13, 13, 14, 15, 15, 16, 16, 17, 17, 18, 18, 18, 18, 17, 17, 16, 16, 15, 15, 14, 13, 13, 12, 12, 11, 11, 10, 
10, 11, 11, 12, 13, 13, 14, 15, 15, 16, 17, 18, 18, 19, 19, 19, 19, 19, 19, 18, 18, 17, 16, 15, 15, 14, 13, 13, 12, 11, 11, 10, 
11, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20, 21, 21, 21, 21, 21, 21, 20, 19, 18, 17, 16, 15, 15, 14, 13, 12, 12, 11, 11, 
11, 11, 12, 13, 14, 14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 24, 24, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 14, 13, 12, 11, 11, 
11, 12, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 20, 18, 17, 16, 15, 14, 13, 12, 12, 11, 
11, 12, 13, 14, 14, 15, 17, 18, 19, 21, 23, 25, 26, 28, 29, 30, 30, 29, 28, 26, 25, 23, 21, 19, 18, 17, 15, 14, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 17, 19, 20, 22, 24, 27, 29, 32, 34, 35, 35, 34, 32, 29, 27, 24, 22, 20, 19, 17, 16, 15, 14, 13, 12, 11, 
12, 12, 13, 14, 15, 16, 18, 20, 21, 24, 26, 29, 33, 36, 40, 41, 41, 40, 36, 33, 29, 26, 24, 21, 20, 18, 16, 15, 14, 13, 12, 12, 
12, 13, 13, 14, 16, 17, 18, 20, 22, 25, 28, 32, 37, 42, 47, 51, 51, 47, 42, 37, 32, 28, 25, 22, 20, 18, 17, 16, 14, 13, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 23, 26, 30, 35, 41, 49, 58, 65, 65, 58, 49, 41, 35, 30, 26, 23, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 24, 27, 31, 37, 44, 56, 72, 91, 91, 72, 56, 44, 37, 31, 27, 24, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 18, 19, 21, 24, 27, 32, 38, 47, 61, 86, 139, 139, 86, 61, 47, 38, 32, 27, 24, 21, 19, 18, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 18, 19, 21, 24, 27, 32, 38, 47, 61, 86, 139, 139, 86, 61, 47, 38, 32, 27, 24, 21, 19, 18, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 24, 27, 31, 37, 44, 56, 72, 91, 91, 72, 56, 44, 37, 31, 27, 24, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 23, 26, 30, 35, 41, 49, 58, 65, 65, 58, 49, 41, 35, 30, 26, 23, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 13, 14, 16, 17, 18, 20, 22, 25, 28, 32, 37, 42, 47, 51, 51, 47, 42, 37, 32, 28, 25, 22, 20, 18, 17, 16, 14, 13, 13, 12, 
12, 12, 13, 14, 15, 16, 18, 20, 21, 24, 26, 29, 33, 36, 40, 41, 41, 40, 36, 33, 29, 26, 24, 21, 20, 18, 16, 15, 14, 13, 12, 12, 
11, 12, 13, 14, 15, 16, 17, 19, 20, 22, 24, 27, 29, 32, 34, 35, 35, 34, 32, 29, 27, 24, 22, 20, 19, 17, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 14, 15, 17, 18, 19, 21, 23, 25, 26, 28, 29, 30, 30, 29, 28, 26, 25, 23, 21, 19, 18, 17, 15, 14, 14, 13, 12, 11, 
11, 12, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 20, 18, 17, 16, 15, 14, 13, 12, 12, 11, 
11, 11, 12, 13, 14, 14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 24, 24, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 14, 13, 12, 11, 11, 
11, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20, 21, 21, 21, 21, 21, 21, 20, 19, 18, 17, 16, 15, 15, 14, 13, 12, 12, 11, 11, 
10, 11, 11, 12, 13, 13, 14, 15, 15, 16, 17, 18, 18, 19, 19, 19, 19, 19, 19, 18, 18, 17, 16, 15, 15, 14, 13, 13, 12, 11, 11, 10, 
10, 11, 11, 12, 12, 13, 13, 14, 15, 15, 16, 16, 17, 17, 18, 18, 18, 18, 17, 17, 16, 16, 15, 15, 14, 13, 13, 12, 12, 11, 11, 10, 
10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 14, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10, 9, 
9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9 }; 

const uint8_t angle_table[] = 
		// 32x32 version for panning and/or y-shearing. 
{ 96, 94, 93, 91, 89, 88, 86, 83, 81, 79, 77, 75, 72, 70, 67, 64, 62, 59, 56, 54, 51, 49, 47, 45, 43, 41, 39, 37, 36, 34, 32, 32, 
96, 96, 93, 92, 91, 88, 87, 85, 83, 81, 78, 76, 73, 70, 67, 64, 62, 59, 56, 54, 51, 49, 46, 44, 41, 39, 38, 36, 34, 33, 32, 30, 
98, 97, 96, 93, 92, 90, 88, 86, 84, 81, 79, 76, 73, 71, 68, 65, 61, 59, 56, 53, 50, 47, 45, 42, 40, 38, 36, 34, 33, 32, 29, 29, 
100, 98, 97, 96, 93, 92, 90, 88, 85, 83, 80, 77, 74, 71, 68, 65, 61, 59, 55, 52, 49, 46, 44, 41, 39, 36, 34, 33, 32, 29, 28, 27, 
101, 100, 98, 97, 96, 93, 91, 89, 87, 84, 81, 78, 75, 72, 68, 65, 61, 58, 54, 51, 48, 45, 42, 39, 37, 35, 33, 32, 29, 28, 27, 25, 
103, 102, 100, 98, 97, 96, 93, 91, 88, 86, 83, 80, 76, 73, 69, 65, 61, 57, 54, 50, 46, 44, 41, 38, 36, 33, 32, 29, 28, 26, 24, 24, 
105, 103, 102, 100, 99, 97, 96, 93, 91, 88, 85, 81, 78, 73, 69, 66, 61, 57, 53, 49, 45, 41, 39, 36, 34, 32, 29, 27, 26, 24, 23, 22, 
107, 105, 104, 103, 101, 100, 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 44, 40, 36, 34, 32, 29, 27, 25, 24, 22, 21, 19, 
109, 108, 106, 105, 103, 102, 100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 41, 37, 34, 32, 29, 27, 24, 23, 21, 20, 19, 17, 
111, 110, 109, 108, 106, 105, 103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 39, 34, 32, 28, 26, 24, 22, 20, 19, 17, 17, 15, 
113, 113, 111, 110, 109, 108, 105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 35, 32, 28, 25, 22, 21, 19, 17, 16, 15, 14, 13, 
115, 115, 114, 113, 112, 110, 109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 32, 27, 24, 21, 19, 17, 16, 14, 13, 12, 12, 11, 
118, 118, 117, 116, 115, 114, 113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 26, 22, 19, 17, 15, 14, 12, 11, 10, 9, 9, 8, 
120, 120, 120, 119, 118, 118, 117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 20, 17, 14, 12, 11, 9, 9, 8, 7, 7, 6, 6, 
123, 123, 123, 123, 122, 121, 121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 12, 10, 8, 7, 7, 5, 5, 4, 4, 4, 3, 3, 
126, 126, 125, 125, 125, 125, 125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 4, 3, 2, 2, 2, 2, 1, 1, 1, 1, 0, 0, 
128, 128, 129, 129, 129, 129, 130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 251, 251, 252, 253, 253, 253, 253, 253, 253, 253, 254, 254, 
131, 131, 132, 132, 132, 133, 133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 242, 244, 246, 247, 248, 249, 249, 250, 251, 251, 251, 251, 
134, 134, 135, 135, 136, 137, 137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 234, 238, 240, 242, 243, 245, 246, 246, 247, 248, 248, 248, 
136, 137, 137, 138, 139, 140, 142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 228, 232, 235, 237, 239, 241, 242, 243, 244, 245, 246, 246, 
139, 140, 140, 141, 142, 144, 145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 224, 227, 231, 233, 236, 237, 238, 240, 241, 242, 243, 243, 
141, 142, 143, 144, 145, 147, 149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 219, 224, 226, 229, 232, 233, 236, 237, 238, 239, 241, 241, 
143, 145, 145, 147, 148, 150, 152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 216, 220, 224, 226, 228, 231, 233, 234, 236, 237, 238, 239, 
145, 147, 148, 149, 151, 152, 155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 213, 217, 220, 224, 226, 228, 230, 231, 233, 234, 236, 237, 
147, 149, 150, 152, 153, 155, 157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 211, 214, 218, 221, 224, 226, 228, 229, 231, 232, 233, 235, 
150, 151, 152, 154, 155, 157, 160, 162, 164, 167, 169, 173, 177, 181, 185, 189, 194, 197, 201, 206, 209, 213, 216, 219, 221, 224, 225, 227, 228, 230, 231, 233, 
152, 152, 154, 156, 157, 160, 161, 164, 166, 169, 172, 174, 178, 182, 185, 189, 193, 197, 201, 204, 208, 211, 214, 216, 219, 221, 224, 225, 226, 228, 230, 231, 
153, 155, 156, 157, 160, 161, 163, 165, 167, 170, 173, 176, 179, 182, 186, 189, 193, 196, 200, 203, 206, 209, 212, 215, 217, 219, 221, 224, 225, 226, 228, 229, 
155, 156, 157, 160, 161, 162, 164, 167, 169, 172, 174, 177, 180, 183, 187, 189, 193, 196, 199, 202, 205, 208, 211, 213, 216, 218, 220, 221, 224, 225, 226, 228, 
157, 157, 160, 161, 162, 164, 166, 168, 170, 173, 175, 178, 181, 184, 187, 189, 193, 196, 199, 201, 204, 207, 209, 212, 214, 216, 218, 220, 221, 224, 225, 226, 
158, 160, 161, 162, 164, 166, 167, 169, 172, 174, 177, 179, 182, 184, 187, 190, 192, 195, 198, 201, 204, 206, 209, 211, 213, 215, 216, 219, 220, 221, 224, 224, 
160, 160, 162, 164, 165, 167, 169, 171, 173, 175, 177, 179, 182, 184, 187, 190, 192, 195, 198, 200, 203, 205, 207, 209, 211, 214, 216, 217, 219, 221, 222, 224 }; 

// Trig shit. 
// Sine / cosine table, using the obvious gimmick of a 90-degree offset to overlap them. 
/* JS: 
JSON.stringify( 
	new Array( 256 * 1.5 )
		.fill(0).map( (v,i,a) => Math.floor( 
			127 * Math.cos( Math.PI * i / 256.0 ) 
		) ) 
).split(',').join(', ')
*/
/*
const int8_t cos[] = 
{ 127, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 125, 125, 125, 125, 124, 124, 124, 123, 123, 123, 122, 122, 121, 121, 121, 120, 120, 119, 119, 118, 117, 117, 116, 116, 115, 114, 114, 113, 112, 112, 111, 110, 109, 108, 108, 107, 106, 105, 104, 103, 102, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 91, 90, 89, 88, 87, 86, 85, 84, 82, 81, 80, 79, 78, 76, 75, 74, 73, 71, 70, 69, 67, 66, 65, 63, 62, 61, 59, 58, 57, 55, 54, 52, 51, 50, 48, 47, 45, 44, 42, 41, 39, 38, 36, 35, 33, 32, 30, 29, 27, 26, 24, 23, 21, 20, 18, 17, 15, 13, 12, 10, 9, 7, 6, 4, 3, 1, 0, -2, -4, -5, -7, -8, -10, -11, -13, -14, -16, -18, -19, -21, -22, -24, -25, -27, -28, -30, -31, -33, -34, -36, -37, -39, -40, -42, -43, -45, -46, -48, -49, -51, -52, -53, -55, -56, -58, -59, -60, -62, -63, -64, -66, -67, -68, -70, -71, -72, -74, -75, -76, -77, -79, -80, -81, -82, -83, -85, -86, -87, -88, -89, -90, -91, -92, -94, -95, -96, -97, -98, -99, -100, -101, -102, -103, -103, -104, -105, -106, -107, -108, -109, -109, -110, -111, -112, -113, -113, -114, -115, -115, -116, -117, -117, -118, -118, -119, -120, -120, -121, -121, -122, -122, -122, -123, -123, -124, -124, -124, -125, -125, -125, -126, -126, -126, -126, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -125, -125, -125, -124, -124, -124, -123, -123, -122, -122, -122, -121, -121, -120, -120, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -113, -112, -111, -110, -109, -109, -108, -107, -106, -105, -104, -103, -103, -102, -101, -100, -99, -98, -97, -96, -95, -94, -92, -91, -90, -89, -88, -87, -86, -85, -83, -82, -81, -80, -79, -77, -76, -75, -74, -72, -71, -70, -68, -67, -66, -64, -63, -62, -60, -59, -58, -56, -55, -53, -52, -51, -49, -48, -46, -45, -43, -42, -40, -39, -37, -36, -34, -33, -31, -30, -28, -27, -25, -24, -22, -21, -19, -18, -16, -14, -13, -11, -10, -8, -7, -5, -4, -2 }; 

const int8_t* sin = &cos[ 128 ]; 
*/

// Precomputed division table, because that is weirdly expensive.
// May not get used - but like trig, it's come up enough to include, just in case. 
/*
const uint8_t divide256by[] = 
// Rounding down:
// JSON.stringify( new Array( 256 ).fill(0).map( (v,i,a) => Math.floor( -0.5 + 256 / i ) ) ).split(',').join(', ');
{ 255, 255, 127, 84, 63, 50, 42, 36, 31, 27, 25, 22, 20, 19, 17, 16, 15, 14, 13, 12, 12, 11, 11, 10, 10, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
*/

// Big dumb table(s) for sprite origins. 
// Got it down to one: quadrants are mirrored, and one quarter-turn of cosine is sine's quarter-turn, backwards. 
// Bizarrely, the limiting factor is syntax highlighting for this fat nested array literal. 
/*
JSON.stringify( 
new Array( angle_count = 16 ).fill(0).map( (v,angle,a) => 
new Array( distance_count = 64 ).fill(0).map( (value,distance,arr) => Math.floor( 
8.0 * ( 32.0 / 20.0 ) * 127.0 / ( 256.0 * ( 1.0 - ( ( distance + distance_count ) / (2*distance_count) ) ) )
* Math.sin( angle / angle_count * 0.5*Math.PI )
) ) ) 
).replace( /,/g, ', ' ).replace( /\[/g, '{' ).replace( /\]/g, '}' )

JSON.stringify( 
new Array( angle_count = 16 ).fill(0).map( (v,angle,a) => 
new Array( distance_count = 64 ).fill(0).map( (value,distance,arr) => Math.floor( 
8.0 * ( 32.0 / 20.0 ) * 127.0 / ( 256.0 * ( 1.0 - ( ( distance + distance_count ) / (2*distance_count) ) ) )
* Math.sin( angle / angle_count * 0.5*Math.PI )
) ).map( v => v > 127 ? 127 : v ) ) 
).replace( /,/g, ', ' ).replace( /\[/g, '{' ).replace( /\]/g, '}' )
// This is still the tiniest bit off and it's going to drive me crazy if I don't move on. 
*/
const int8_t sin_from_polar[ 16 ][ 64 ] = 
// 16x64 angle x distance
{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 6, 6, 7, 7, 8, 9, 11, 13, 15, 19, 26, 39, 79}, {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 8, 8, 9, 9, 10, 11, 12, 13, 14, 15, 17, 19, 22, 26, 31, 39, 52, 79, 127}, {3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 11, 11, 12, 13, 13, 14, 15, 16, 18, 19, 21, 23, 26, 29, 33, 39, 47, 58, 78, 117, 127}, {4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 13, 14, 14, 15, 16, 17, 18, 19, 20, 22, 23, 25, 28, 31, 34, 38, 44, 51, 62, 77, 103, 127, 127}, {5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 27, 29, 31, 34, 38, 42, 47, 54, 63, 76, 95, 127, 127, 127}, {7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 18, 18, 19, 20, 21, 22, 23, 25, 26, 28, 30, 32, 34, 37, 41, 45, 50, 56, 64, 75, 90, 112, 127, 127, 127}, {8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 19, 19, 20, 21, 22, 23, 24, 25, 27, 28, 30, 32, 34, 36, 39, 42, 46, 51, 57, 64, 73, 85, 103, 127, 127, 127, 127}, {8, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 17, 17, 18, 19, 19, 20, 21, 22, 22, 23, 24, 26, 27, 28, 30, 31, 33, 35, 38, 41, 44, 47, 52, 57, 63, 71, 82, 95, 114, 127, 127, 127, 127}, {9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 15, 15, 16, 16, 16, 17, 17, 18, 19, 19, 20, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 34, 36, 39, 41, 44, 48, 52, 57, 62, 69, 78, 89, 104, 125, 127, 127, 127, 127}, {10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 24, 25, 25, 27, 28, 29, 30, 32, 33, 35, 37, 39, 42, 45, 48, 51, 56, 61, 67, 75, 84, 96, 112, 127, 127, 127, 127, 127}, {11, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 23, 24, 25, 26, 27, 28, 29, 31, 32, 34, 35, 37, 39, 42, 44, 47, 51, 55, 59, 65, 71, 79, 89, 102, 119, 127, 127, 127, 127, 127}, {11, 11, 12, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 15, 15, 15, 15, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 20, 21, 22, 22, 23, 24, 25, 25, 26, 27, 28, 30, 31, 32, 34, 35, 37, 39, 41, 44, 46, 50, 53, 57, 62, 68, 75, 83, 93, 107, 125, 127, 127, 127, 127, 127}, {12, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20, 21, 21, 22, 22, 23, 24, 25, 25, 26, 27, 28, 29, 31, 32, 33, 35, 37, 38, 40, 43, 45, 48, 51, 55, 59, 64, 70, 77, 86, 97, 111, 127, 127, 127, 127, 127, 127}, {12, 12, 12, 13, 13, 13, 13, 13, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20, 20, 21, 22, 22, 23, 24, 24, 25, 26, 27, 28, 29, 30, 31, 33, 34, 36, 37, 39, 41, 44, 46, 49, 53, 56, 61, 66, 72, 79, 88, 99, 113, 127, 127, 127, 127, 127, 127}, {12, 12, 13, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 23, 23, 24, 25, 26, 26, 27, 28, 29, 31, 32, 33, 35, 36, 38, 40, 42, 44, 47, 50, 53, 57, 62, 67, 73, 80, 89, 101, 115, 127, 127, 127, 127, 127, 127}};



// Sprite data

/* 
I fucking hate dealing with bitmasks in hex, but binary is so verbose. 

0000 = 0
0001 = 1
0010 = 2
0011 = 3

0100 = 4
0101 = 5
0110 = 6
0111 = 7

1000 = 8
1001 = 9
1010 = A
1011 = B

1100 = C
1101 = D
1110 = E
1111 = F

*/

const unsigned char gradient_data[] = { 

	/* 0xFF to 0x00, presumably white to black */
	/* 0b1010 = A, 0b0101 = 5 */
	// Black. Black / dark. Dark. Dark / light. Light. Light / white. White. 
	// Currently have 13 colors via simple dithering in 4-pixel patterns. Need a few more for easy power-of-two 16. 
	// Could just stuff some duplicate darks in there, for later? Dark is probably where we want more detail. 

	// BB/BB
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 		// Black: 1/1

	// BB/BD
	0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 		// Pips
	0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 		// BB/BB

	// BD/BD
	// B is 1/1, D is 0/1
	0b01010101, 0xFF, 
	0b11101110, 0xFF, 
	0b01010101, 0xFF, 
	0b10111011, 0xFF,

	0b01010101, 0xFF, 
	0b11101110, 0xFF,
	0b01010101, 0xFF, 
	0b10111011, 0xFF,
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// BD/BD 

	// BD/DD
/*
0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 

0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 
*/
	0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 		// BD/DD 

	// DDDD DDDD / BDDD BDDD / DDDD DDDD / DDBD DDBD 
	// Or should it be DDDB / DBDD? Argh. 
	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF, 

	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF,  

	// DD/DD
	0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF, 		// Dark: 0/1

	// DD/DL
	0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,

	// DL/DL
	0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA,  	// 0/1 + 1/0 

	// DL/LL
	0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 

	// LL/LL
	0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00, 		// Light: 1/0

	// LL/LW
	0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 

	// LW/LW
	0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 	// 1/0 + 0/0

	// LW/WW
	0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 

	// WW/WW
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 		// White: 0/0
	// This needs to not go white-white.
	// Good answers? Dunno. Just mix with black for now. 

//	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 		// W			uint8_t hit = 0; e again

	// BW/BW
	0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA 
		// Black+white

};





// Interrupt functions

uint8_t sy = 0; 

void half_tile_isr() { 
	// Okay: SCY_REG is a -global- scroll register. It is not "which scanline are we on, right now."
	// It changes which scanline is at the logical top of the screen. 
	// So we can't just sy*8 to go, "next scanline, start drawing from tile row sy."
	// This kinda-sorta makes sense, but it is a tremendous pain in the ass for comprehension, 
		// when mixed with LYC_REG needing a strict objective "where are we NOW?" number. 
	// TL;DR LYC to sy*i and SCY to k where i+k = 8. 
	LYC_REG = sy * 5;    
	SCY_REG += 3; 
//	SCX_REG += 1; 		// Tilting for a turn effect? Eh. 
	sy++; 

	// Debug, making row heights crystal clear:
//	SCX_REG += 128; 

	// So why the fuck is the top row still 7 pixels? Whatever. 
	// I'd have to switch to the window to get 4px-tall tiles. 
	// Or: naive 4px rows, plus a narrow hud at the bottom. linear map, maybe. 
	// Or: 5px rows, and we only waste one scanline. But the dithering might mismatch. (Yeah, it does.) 
	// Dithering could be handled by alternating SCY_REG increments. 

	line_count += 4; 		// FPS guff 
}

void hud_isr() { 
	HIDE_SPRITES; 
} 

void my_vblank_isr() { 
//	LYC_REG = 1; 
//	SCY_REG = 0; 		// Stop doing this if we're not fucking with tilemap compression. 
//	SCX_REG = -16; 
//	sy = 1; 

	// Vsync frame swap, if applicable:
	// SCX_REG = scx; 
	// SCY_REG = scy; 

	// Enable sprites, since we turn them off over the HUD. 
	SHOW_SPRITES; 

	line_count += 144; 		// FPS tracking. Not 154 because the scanline version doesn't count vblank. 
	line_count += 10; 		// Account for all scanlines. Probably. Might be missing a few anyway. 

	// Take input from joystick(), add it to some input-buffer array, and increment array counter. 
	// Alternate C approach: write to *input_buffer and then increment it. field_count should match. 
		// Ehhh. Too easy to get mismatches. Track the thing directly; stray bytes are cheap. 
}


// Globals as fake arguments for draw_tile 
uint8_t x, y, xplus; 
int8_t bend_x = 0; 
int8_t bend_y = 0; 

void draw_tile();


















// Main functionality 

void main() {
	printf( "Loading..." ); // Need a printf for GBDK to include text characters. 

	// Load tile data to CHR-RAM
	set_bkg_data(0x00, 0x08, gradient_data);
	set_bkg_data(128, 128, gradient_data);  

	// Sprite data, nonsense for now 
	// 40 hardware sprites. 10 per line. Worth remembering. 
	set_sprite_data( 128, 128, gradient_data ); 		// [ BG tiles { BG & Sprite tiles ] Sprite tiles } - so sprite's 0 = BG's 128. 

	SHOW_SPRITES; 
	// Hey, there we go. 
//	SPRITES_8x8; 	// 8x16 default? Weird choice. 
	SPRITES_8x16; 		// We need this so 4x4 sprites take 8 slots instead of 16. 

	// Fill tube_color because division by six is weirdly expensive. 
	// "Anything that only happens once is free."
	// Weirdly difficult to get a loop of 256. 
	// tube_color[] may remain variable so that we can fuck with it. 
		// Though we could just declare 'int8_t* tube' and point it at e.g. tube_type[8][256]. 
		// Probably better to just use two and amortize the next one while using this one. Do one entry per frame. 
	const uint8_t sides[] = { 2, 0, 1, 2, 3, 4, 2, 0 }; 		// 8 instead of 6 because modulo is acting weird. 
	for( uint8_t n = 255; n > 0; n-- ) { 		// Divide into sixths. 
		const uint8_t side = n / 43 + 1; 	// To simplify dealing with non-uniform gradients. 
		tube_color[n] = sides[ side ]; 		// 0..5. 6*43 is 258. 

		// Faux subsampling? 0..5 x2 -> 0..10, and use an in-between color right near the boundary. 
		// "Anti-aliasing." Three colors per side, or just two? Three fits but may be overkill. 
		// Keep dead code for now; we're gonna mix things up during play. 
		tube_color[n] *= 2; 
//		if( n % 43 > 40 ) { tube_color[n]++; } 
//		if( n % 43 < 2 ) { tube_color[n]--; } 
		// Wow, that's nice. 
//		if( n % 43 > 40 ) { tube_color[n] += sides[ ( side + 1 ) % 6 ]; tube_color[n] /= 2; } 
//		if( n % 43 < 2 ) { tube_color[n] += sides[ ( side - 1 ) % 6 ]; tube_color[n] /= 2; } 
		if( n % 43 > 40 ) { 		// Why is anti-aliasing uneven? This is only 41, 42, but the other's only 0, 1. 
											// The bottom facet's diagonals are noticeably askew. 
											// ... maybe just because it's 4->2 instead of 3? Ehh, not really.  
			if( sides[ side + 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}
		else if( n % 43 < 2 ) { 
			if( sides[ side - 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}

		// This setup loop should also handle most of the tube-color stuff. 
		// So e.g. add 3 to every thing for a fairly naive sawtooth gradient that looks about right. 
		// But ideally I'd like to make the bottom white(ish), the upper-right dark, 
			// and the lower-right about as dim as the upper-left. 
		tube_color[n] += 3; 

		tube_color[n] += 128; 		// Tiles in the middle. (Letters at the front.) 
			// I could use a bit to indicate boundaries.
			// Really I could use several, we're only encoding 16 shades so far. 
			// Masking is cheap and it'd let us substitute rotation-aware diagonals. 
	}
	// Then set tube_color[0] if it's not supposed to be black. 
	tube_color[0] = tube_color[1]; 		// Easy hack. 

	// Compression to 4-scanline-high tiles has tolerable performance impact. 
	// It's rendering all those tiles that kills us. 
	// We might go for diagonal tiles and skip scanline shenanigans altogether. 
	// In which case: we do still need VBL_IFLAG. (Or is that just for wait_vbl_done?) 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
		LYC_REG = 144 - 16; 		// HUD
//		add_LCD( half_tile_isr );
		add_LCD( hud_isr );
		add_VBL( my_vblank_isr ); 		// Two hard problems. 
		set_interrupts( VBL_IFLAG | LCD_IFLAG );
//		set_interrupts( VBL_IFLAG );
	}

	// FPS / HUD - using window 
	init_win( 6 ); 		// All white, probably. 
	move_win( 7, 128 ); 		// Coordinates start one tile/sprite offscreen. (144-16) throws a warning. Shrug. 
	SHOW_WIN; 		// Equivalent to LCDC_REG|=0x20U

	// Initial game state
	curve_x = 0; 
	curve_y = 0; 
		// Multiplicative solution means only small numbers matter. 

	int8_t pan_x = 0; 		// Debug - nope, now a nudge value for collision effect
	int8_t pan_y = 0; 

	// Debug: many random chunks of debris. 
	// ... how does this fuck up the background? 
	// I suspect we're pushing up against the 32 KB no-bankswitching limit, but GBDK just rolls with it. 
	// Did I fuck up filling tube_color? Or accessing it? Bizarre it worked fine before, if so. 
	// Might be a RAM issue? Stack pushing down into main RAM. Bizarre that it's stable, if so. 
	// And it only happens if I define obstacles[] past somewhere between 10-20. 
	for( int8_t k = 0; k < 20; k++ ) { 
		obstacles[ k ].type = 1; 	
		obstacles[ k ].location =  ( 255 /  10 ) * k;  
		obstacles[ k ].orientation = 30*k;
	}

	// Make it work - make it fast - make it pretty. In that order. 
	while ( 1 ) {
		// Book-keeping
//		scroller_x++; 		// Debug for collision / scaling - go slowly
//		scroller_x += field_count; 		

		// Input
		input = joypad(); 		// Replace with buffer(s)
//		input = running_input(); 

		// Controls & Physics
		for( int8_t rounds = field_count; rounds > 0; rounds-- ) { 		// Not "tics" because I keep typing "ticks". 
			scroller_x++; 		// Test every position, since we're doing tics. 

			// Physics
			// Fuck it, just make the lower sides slide your ass down.
			if( ! ( input && ( J_LEFT || J_RIGHT ) ) ) { rotation_impulse = 0; } 		// Added force drops to zero instantly. 
			else {
				if( input & J_LEFT ) { 
					rotation_impulse -= 1; 
					if( rotation_impulse < -5 ) { rotation_impulse = -3; } 
				} 
				if( input & J_RIGHT ) { 
					rotation_impulse += 1; 			
					if( rotation_impulse > 5 ) { rotation_impulse = 3; } 
				} 
			}
			// Bit squirrelly at 10 FPS, but it'll do for now. 
			velocity += rotation_impulse; 


			const uint8_t side = ( (int8_t) rotation ) / 43 + 1; 
				// Uh, how does the signed / unsigned thing work here? 
				// I'd rather not need to shift to 16-bit to get that right. 
				// If this works out like [], the top is sides 0-1-2, and the bottom is 3-4-5, with 4 being level. 
			if( side == 3 ) { velocity += 1; } 
			if( side == 5 ) { velocity -= 1; } 

			// Double fuck it. Conditionals. 
			// And lock controls when going over the top. 
				// Going over? Set boolean. Boolean checked? Check for when you're back on the bottom half. 
			// How fast is over the top? 25-ish is the limit for jostling back and forth, trying to get a run-up. 27, tops. 
			// Run-up from the opposite edge of the bottom facet: 17-ish. 
			// Starting from a astandstill at the edge of this facet? 7-ish. 
			// Oh god I'm not sure you should be able to go over in a curve. 
				// Like, if forces push you away, toward the outside, you can build speed toward the midpoint cutoff -
					// but realistically it would keep you there.
				// For smooth "round" gravity, this was going to be a non-issue, because you'd just change the zero point. 

			// Most of this should be DRY-er. It helps keep things consistent. 
			if( rotation < -64 && velocity < 0 ) { 
				if( abs( velocity ) > 25 ) { 
					controls_locked = 1; 		// No proper bools. 
				} 
				else { 
	//				velocity = 0; 
					velocity -= velocity / 2; 
					velocity -= -2; 
				}
			} 
			if( rotation > 64 && velocity > 0 ) { 
				if( abs( velocity ) > 25 ) { 
					controls_locked = 1; 		// No proper bools. 
				} 
				else {
	//				velocity = 0; 
					velocity -= velocity / 2; 
					velocity -= 2; 
				}
			} 
			if( rotation < -21 ) { velocity += 2; } 
			if( rotation > 21 ) { velocity -= 2; } 

			// Sudden loss of speed when you go over the top?
			// Once again - works great in one direction, fucked up in the other direction. Fuck's sake. 
			if( controls_locked && rotation < -(127-21) && velocity > 0 ) { velocity = velocity / 2; } 
			if( controls_locked && rotation > (127-21) && velocity < 0 ) { velocity = velocity / 2; } 

			// Unlock condition is: in bottom half, headed toward zero. 
			if( controls_locked && rotation > -64 && velocity > 0 ) { 
				velocity -= velocity / 2; 
				controls_locked = 0; 
			} 
			if( controls_locked && rotation < 64 && velocity > 0 ) { 
				velocity -= velocity / 2; 
				controls_locked = 0; 
			} 

	//		velocity = velocity > 30 ? 30 : velocity; 
	//		velocity = velocity < -30 ? -30 : velocity; 
				// Debug-ish limit on speed, to make endless looping at least happen less on its own, 
					// and also so you can't hold one direction while going over and spin like a moron. 
				// Oh goody, and we're back to being asymmetrical. Fuck you. 

	//		rotation += velocity; 

			// Jank-ass basic controls for testing graphics: 
			if( input & J_LEFT ) { rotation -= 1; } 		// 4 is too high for variable framerate. 
			if( input & J_RIGHT ) { rotation += 1; } 

			// Friction AFTER movement, so I can add 1 and not get instantly zeroed out. 
			// You can still get stuck in a pendulum loop after going over the top. 
				// Oh, probably just because we never unlock controls. (Which brings back "ramp" gravity.) 
			if( ! controls_locked ) { 
				if( velocity > 0 ) { velocity--; } 
				if( velocity < 0 ) { velocity++; } 
			} 

			// Collision for obstacles
			for( int8_t j = 0; j < MAX_OBSTACLES; j++ ) { 
				if( obstacles[ j ].type == 0 ) { continue; } 
				// Implicit else:
				const uint8_t obstacle_distance = obstacles[ j ].location - scroller_x; 
				const int8_t obstacle_rotation = obstacles[ j ].orientation + rotation; 

				// Remove obstacles that should be past and offscreen. 
				if( obstacle_distance < 3 ) { 
					obstacles[ j ].type = 0; 
					continue; 
				} 

				// If we're doing dead hit versus glancing blow, rotation +/- 8 versus +/- 16 seems about right. 
				if( ! invincible &&
					obstacle_distance < 10+2 && obstacle_distance > 10-2 && 		// +/- 2 seems about right. Wider, though. 
					obstacle_rotation < 16 && obstacle_rotation > -16 ) 
				{
					hit = 10; 
					invincible = hit; 
				} 
			} 
			if( hit ) { 
				// More serious use of this will set "you got smacked" flag, and trigger i-frames and animation. 
//				pan_x = 20; 
				hit--; 
				if( hit ) { 
					pan_x = ( hit & 0x02 ) * 2 - 4; 		// Oscillate between +/- 4
					pan_y = hit & 0x01; 		// Oscillate between +/- 1
				} else { 
					pan_x = pan_y = 0; 		// Reset when done hurting
					invincible = 0; 		// If there's a power-up for this, beware of no-hamr collisions turning it off. 
				}
			} 

		} 		// Physics / controls for-loop 



		// Curve test
//		if( input & J_UP ) { curve_x += 1; } 
//		if( input & J_DOWN ) { curve_x -= 1; } 
		if( input & J_B ) { pan_x += 5; } 
		if( input & J_A ) { pan_x -= 5; } 

		// Y-shear test
/*
		if( input & J_UP ) { ystart--; } 
		if( input & J_DOWN ) { ystart++; } 
		if( input & J_B ) { xstart--; } 
		if( input & J_A ) { xstart++; } 
*/
		#define WIDTH 32
		#define HEIGHT 32		// Possibly 18 or 20


		// Screen placement
		// Use fine hardware scrolling, you ding-dong. 
		const int8_t half_rotation = rotation / 2; 

		// "Evelyn" keeps barking about these.
		// Possibly because we're currently ignoring physics?
		int8_t scroll_x = -half_rotation; 		// Much cleaner. 
		if( rotation > 64 ) { scroll_x = -64 + half_rotation; } 		// Past the horizon, reverse back toward 0. 
		if( rotation < -64 ) { scroll_x = 64 + half_rotation; } 

		int8_t scroll_y = ( abs( half_rotation ) >> 2 );  		// Don't reverse Y when upside-down. 
		// Nudge screen upward when crossing panel edges? Prior notes:
			// Make xstart follow rotation, so the camera tracks a car going up the wall. 
				// I'm okay with the chunky motion up and down, because it kinda matches where your car hits an angled wall. 
			// (Though sloppy correlation is fine because I do like the coincidental transition between facets.) 


		// Debug - no sliding around while dorking with curves:
//		scroll_x = scroll_y = 0; 
		scroll_y += pan_y; 
		scroll_x += pan_x; 

		// The simple fix is to always render 32x18. That'll at least let us figure out if we're tracking sensibly. Perf later. 
		// Setting SCX/SCY_REG eventually has to go in the vblank interrupt, for when we do double-buffering and vsync. 
		uint8_t scx = scroll_x + 8*((32-20)/2); 		// Okay, sure. 8x for bytes, not bits. 
		uint8_t scy = scroll_y + 8*(32-18)/2 + 32; 		// Jumble of constants is to center the screen. (And offset Y.) 
		SCX_REG = scx; 		// This indirection (scx -> SCX_REG) might be redundant. It was intended for ystart etc. 
		SCY_REG = scy; 

		// Rendering 
		// Simplify panning: the logical screen is always 32x32 tiles. We just try not to draw what we can't see. 
		// The stupid version of this is to check x and y in each loop and "continue" if they're fully offscreen. 


		// Displacement curves don't work. 
		// I'm gonna try reordering how we draw tiles, so we can pretend we're drawing rectangles, 
			// e.g. 32x32, then 31x31, and so on, with the center point moving between each ring of tiles. 
		// Niavely: for ring = 32..0. Choose offset in whole tiles. (Might be end_offset / 32. Might be offset += per_ring.)
			// for y=ring, x=(32-ring)..ring, draw a row.
			// for y=ring+1..(32-(ring+1)), draw x=(32-ring) and x=ring. 
			// for y=(32-ring), x=(32-ring..ring), draw a row. 

//		jitter = scroller_x; 
		// Note: for-y and for-y loops don't use WIDTH / HEIGHT because we're still only drawing 20x18. 
		// "Evelyn" keeps barking about this: 
		const int8_t ystart = scy / 8; 
		const int8_t xstart = scx / 8; 
		const int8_t ystop = ystart + 17; 
		const int8_t xstop = xstart + 21;  
			// Screen is 18 tiles tall. +1 for overlap... except we're kinda covering up the bottom with some HUD stuff. 
			// Yeah, place the window to cover up two rows. We get a whole extra frame per second. 

		// Alternate for-loop head, for displacement curves:
		bend_x = 0; 
		bend_y = 0;  
			// Past 7, you get very sudden inclusion of overflow. (May still be reversal past 5.) 
//		xplus = 1; 		// Every tile on top / bottom of ring, skip from first to last elsewhere. 
/*
		const int8_t x_radius = abs( 16 - xstart ); 
		const int8_t y_radius = abs( 16 - ystart ); 
//		const int8_t ringstart = abs( 16 - xstart );
		const int8_t ringstart = x_radius > y_radius ? x_radius : y_radius;  		// Incorrect. Durr, also compare stops. 

*/
		// This is where offset rotation would go:
		// int8_t rot_curve_x = sin[ curve_x * some constant ]; then cos[] for rot_curve_y

		int8_t ringstart = abs( 16 - xstart );
		if( ringstart < abs( 16 - xstop ) ) { ringstart = abs( 16 - xstop ); } 
		if( ringstart < abs( 16 - ystart ) ) { ringstart = abs( 16 - ystart ); } 
		if( ringstart < abs( 16 - ystop ) ) { ringstart = abs( 16 - ystop ); } 
			// Narrow down to visible area. 
			// Could instead always do 16x16 and then fill in other rows / columns? 
				// We'd have to make sure bending is only +/- 1, at most, at the edge of 16x16. 
			// "Use a table" works, because xstop and xstart are a fixed distance apart. 
			// Could avoid recalculating ringstart if xstart and ystart haven't changed, but... meh. 
			// Better to always do it and just optimize the dodgy chain of conditionals. Elegance that bitch. 

		// An alternate (old) codepath for 'no curve' would be welcome. 
		// Half bars and half brackets? For speed. 
		for( int8_t ring = ringstart; ring > 0; ring-- ) { 		// 16 is the entire tilemap. And slow. 
	//		uint8_t ring=0; {		// Debug 
			bend_x += curve_x; 		// Should probably be more like scroll_x / 32. 
			bend_y += curve_y; 

			// Top bar
			y = 16 - ring; 
			xplus = 1; 		// Next tile over (on both rows)
			if( y >= ystart ) { 		// Compiler warns of "promotion to int." If that's 16-bit, fix this. 
				vram_pointer = get_bkg_xy_addr( 16 - ring, y );
				for( x = 16 - ring; x < 16 + ring; x += xplus ) { draw_tile(); } 
			}

			// Bottom bar 
			y = 16 + ring - 1; 
			if( y < ystop ) { 
				vram_pointer = get_bkg_xy_addr( 16 - ring, y );
				for( x = 16 - ring; x < 16 + ring; x += xplus ) { draw_tile(); } 
			}

			// Left bracket
			x = 16 - ring; 
			xplus = 32; 		// Next tile down (on both columns)
			if( x >= xstart ) { 
				vram_pointer = get_bkg_xy_addr( x, 16 - ring + 1 );
				for( y = 16 - ring + 1; y < 16 + ring - 1; y++ ) { draw_tile(); }
			}

			// Right bracket
			x = 16 + ring - 1; 
			if( x < xstop ) { 
				vram_pointer = get_bkg_xy_addr( x, 16 - ring + 1 );
				for( y = 16 - ring + 1; y < 16 + ring - 1; y++ ) { draw_tile(); }	
			} 

		} 		// for ring






		// Sprite stuff

		// BG coordinate system is scrolled to center tilemap, more or less. 
		// Might remove +4s so larger sprites don't have to account for it. 
		const int8_t center_x = 128 - scx + 4; 
		const int8_t center_y = -scy - 128 + 8+4;  		// This +8 makes no sense, but whatever. 

//		if( input & J_UP ) { distance_sample--; } 
//		if( input & J_DOWN ) { distance_sample++; } 


		// Player sprite
		// Eventually: pick sprite based on turning direction etc. 
		// Eventually: cover projectile somewhere below this. 
		const uint8_t px = center_x; 
		const uint8_t py = center_y + 8*8; 

		set_sprite_prop( 0, 0x00 ); 
		set_sprite_tile( 0, 134 ); 
		move_sprite( 0, px - 16, py ); 

		set_sprite_prop( 1, 0x00 ); 
		set_sprite_tile( 1, 134 ); 
		move_sprite( 1, px - 8, py ); 

		set_sprite_prop( 2, 0x00 ); 
		set_sprite_tile( 2, 134 ); 
		move_sprite( 2, px, py ); 

		set_sprite_prop( 3, 0x00 ); 
		set_sprite_tile( 3, 134 ); 
		move_sprite( 3, px + 8, py ); 



//		obstacles[ 0 ].type = 1; 

//		obstacles[ 1 ].type = 1;
//		obstacles[ 1 ].orientation = -43; 		// Negative is counter-clockwise, apparently. 


		// Obstacle-oriented sprite generation. 
		// MAX_OBSTACLES likely to be 32, so we always have some sprites left over for the player and so on. 
		// Make up some kind of struct / class / typedef on-the-fly, and backfill it above. 
		// Haha, forgot to clean up unused sprites. 
		// Alright, we absolutely want 8x16 sprites. Two close objects would otherwise clobber available sprites. 
		int8_t free_sprite = 8; 		// Lowest available sprite. 8 is a wild guess for the player's needs.  
		for( uint8_t ob = 0; ob < MAX_OBSTACLES && free_sprite < 40; ob++ ) { 	// Can't draw if no sprites are free. 
			// If this obstacle exists, and is within visible range, draw it. 
			// scroller_x logic felt backwards because distance is backwards. The table is fucky.  
				// Changed distance_sample so that obstacle_distance is distance from camera. 
//			const uint8_t obstacle_distance = scroller_x - obstacles[ ob ].location;
			const uint8_t obstacle_distance = obstacles[ ob ].location - scroller_x; 
			const int8_t obstacle_rotation = obstacles[ ob ].orientation + rotation; 
			if( obstacles[ ob ].type 		// Might instead be .type, where 0 is empty and anything else is some enemy or barrier. 
				&& obstacle_distance < 64 		// Should be obstacle.position - scroller_x. 
//				&& obstacle_distance > 5
			) { 
				// Gotta position the obstacle in screen-space before we can exclude offscreen obstacles. 
				// Change quadrant's values to match sprite-flipping properties. 
					// I.e. 0x40 if it's in the upper half, and 0x20 if we flip left/right from default. 
				int8_t quadrant = 0; 		// Default: upper left. 
					if( abs( obstacle_rotation ) < 64 ) { quadrant = 1; } 		// +1 if lower. (Rotation 0 is the bottom.) 
					if( obstacle_rotation < 0 ) { quadrant += 2; } 		// +2 if left? I think? Coordinate systems are agony. 

				const int8_t distance_sample = 64 - ( obstacle_distance & 0x3F ); 
				const int8_t d_rotation_sample = abs( obstacle_rotation % 64 ) / 4;

				int8_t osx, osy; 
				switch( quadrant ) { 		// 90-degree sine table, so cosine is sine backwards. 16 angles per quadrant. 
					case 0: 		// Upper left. 
					osx = center_x - sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ];
					osy = center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					break; 

					case 1: 		// Lower right. 
					osx = center_x - sin_from_polar[ d_rotation_sample ][ distance_sample ];
					osy = center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ];
					break; 

					case 2:		// Upper right. Despite all logic. 
					osx = center_x + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ]; 
					osy = center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					break; 

//					case 3:		// Lower left. 
					default:		// Silences compiler warning 84: "may be used before initialization."
					osx = center_x + sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					osy = center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ]; 
					break; 
				}

				// Mildly questionable pattern: 'exit early if it's bad,' rather and 'do the rest if it's good.' 
				// "Warning 94: comparison is always false due to limited range of data type." 
				// Ah, signed can't be more than +127. 
				// What a pain in the ass it is to fit a range from 0-160 inside 0-255. 
				// I guess subtract it down to some middle value, then check abs(that)? Shift range to +/- 80-ish. 
				// Obstacles disappearing early might be a math/logic error here. 
				// -16 gets shunted to 16, so just osx_abs>160+16 means 0..160. 
				const uint8_t osx_abs = osx + 16; 
				const uint8_t osy_abs = osy + 16; 
				if( osx_abs > ( 160 + 16 + 16 ) || osy_abs > ( 144 + 16 + 16 ) ) { 		// 16 on either side. Whoops. 
//				if( osx < ( 0 - 16 ) || osx > ( 160 + 16 ) || 
//					osy < ( 0 - 16 ) || osy > ( 144 + 16 ) ) { 
					continue; 
				}

				// Count on all obstacles being roughly the same size, for simplicity. 
				// Scale to 1x1, 2x2, 3x3, or 4x4 according to distance. 
				// 4x4 would be at maximum proximity, which is like 10 units. Possibly more, since we're not seeing all 32x32. 
				// Yeah, it's about 20. So "full scale" would be n/20=4, ergo 80. 
				// Bad answer: division. Good answer: table. Sensible answer: there's only four sizes; chain conditionals. 
				// 80/n=3, n = 26. 80/n=2, n = 40. Anything further is 1x1. (May get fudged for rounding.) 
				// The options are 15-20, 20-26, 26-40, and 40-127. 
				// 4x4 looks too big, too soon. Adjust cutoffs accordingly. 
				// 80/n = 1.5, n = 53. 2.5, n = 32. 3.5, n = 23. 4.5, n = 18. 

				// set_sprite_prop's second parameter: 0x40 for upside-down, 0x20 flip left/right, 0x10 second palette. 
				// DEBUG: &&0 on some conditionals so we always go for 1x1. 
				// Unsure how to handle lack of free sprites. 
					// I don't want to check if free_sprite < 40 for every one I add. 
					// I don't think they'll wrap around? Like if I assign some region as shadow OAM, it'll go past 40. 
					// Which means I could just allocate 64 sprites, and if the last one drawn needs 16 sprites,
						// but there's only 1 available, we'll just throw bytes into WRAM that never make it to VRAM. Shrug. 
				// Okay... this is backwards. Did not see that coming. 
				// The swap to 2x2 feels weirdly close. Maybe draw things at distance=64..127 with constant offset?
					// Like a ring barely off-center, so you know something's coming in a given facet. 
					// Ideally with some spritework for finer scaling. E.g. one 2x2-pixel blob up to an 8x8-pixel blob. 
				// Oh god. Finer scaling by overlapping sprites? 
					// Requires treating them as one size larger, and changing spacing. 
					// Otherwise you need an art style  where gaps look normal. 
				// Larger sprites should be offset a little higher, so the bases look well-placed. 
					// Mostly an issue with "3x3" sprites actually being 3x2. 
				const uint8_t cutoffs[] = { 20, 26, 40 }; 		// Separations for four phases. 
//				const uint8_t cutoffs[] = { 18, 32, 53 }; 		// Ehhh. 
//				const uint8_t cutoffs[] = { 10, 20, 30 }; 		// Oh just eyeball it. 
				if( obstacle_distance < cutoffs[1]  ) { 
					if( obstacle_distance < cutoffs[0] ) { 		// Closest, 4x4

						// Top row
						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 16, osy - 16 ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 8, osy - 16 ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx, osy - 16 ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx + 8, osy - 16 ); 

						// Bottom row
						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 16, osy ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 8, osy ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx, osy ); 

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx + 8, osy ); 

					} else { 		// Second closest, 3x3
						// Woof, 3x3 with 8x16 sprites is going to be wasteful. 
						// Either we fudge things to 24x16 for three sprites - or we burn another three sprites as half-full. 
						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 12, osy - 12 ); 		

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 4, osy - 12 ); 	

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx + 4, osy - 12 ); 	

						// Bottom row? 
						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 12, osy - 4 ); 		

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 4, osy - 4 ); 	

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx + 4, osy - 4 ); 	

					}
				} else {
					if( obstacle_distance < cutoffs[2] ) { 		// Third closest, 2x2

						// 8x16 sprites. One's x=-8 to x=0, other's x=0 to x=8. 
						// Ah fuck, we'd have to swap these if the h-flip property is set. 
						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx - 8, osy - 8 ); 		

						set_sprite_prop( free_sprite, 0x00 ); 
						set_sprite_tile( free_sprite, 132 ); 
						move_sprite( free_sprite++, osx, osy - 8 ); 

					} else { 		// Fourth closest, 1x1
						// Sprite flipping is conditional on quadrant, which we've already calculated. 
						// Oh: we could probably match that value to this. The switch-case literls are arbitrary. 
						// 8x16 sprites are still treated as 8x8. Their origin is unchanged. So: -4,-4. 
						set_sprite_prop( free_sprite, 0x00 ); 		// Debug, no flipping yet. 
						set_sprite_tile( free_sprite, 132 );		// Debug, just off-black. 
						move_sprite( free_sprite++, osx - 4, osy - 4 ); 		// Increment to next sprite. 
					}
				}

			}
		} 

		// Clear unused sprites: 
		for( uint8_t c = free_sprite; c < 40; c++ ) { 
			move_sprite( c, 0, 150 ); 		// Betting 150 beats 0,0 because OAM search will never get tripped up by it. 
		} 


/*
		// This should probably go over objects, not sprites. 
		// Regeneration every frame avoids dealing with variable-length elements - since sprites scale. 
		for( uint8_t s = 0; s < 1; s++ ) { 
			// Remove sprites past the near cutoff, which would be z=5 or something. 
			// Ignore sprites too far in the distance. 
			// Could skip direct sprite-list tracking and generate as many as possible every frame...
				// but performance will likely suffer. 

			int8_t quadrant = 0; 		// No performance difference for changing this variable's scope. 
				if( abs( rotation ) < 64 ) { quadrant = 1; } 
				if( rotation < 0 ) { quadrant += 2; } 

			// Sprite data, nonsense for now 
			// 40 hardware sprites. 10 per line. Worth remembering. 
//			set_sprite_data( 128, 128, gradient_data ); 		// [ BG tiles { BG & Sprite tiles ] Sprite tiles } - so sprite's 0 = BG's 128. 
			set_sprite_prop( s, 0x00 ); 		// 0x40 to flip vertically, 0x20 to flip horizontally, 0x10 to swap palettes. 
			set_sprite_tile( s, 132 ); 		// Sprite number 0 to 39, CHR-RAM tile number 0 to... 256? GBDK might fudge it to 128. 
				// No, I strongly suspect GBDK accurately reflects the hardware and makes sprite tile 0 = BG tile 128. (Yep.)
				// So I should probably re-aim set_sprite_data. (Did.)
				// Oh why the fuck is it warning about overflow for 128+3? Is it signed? 
				// No - just more stupidity with macros. The actual value is fine. 
//			move_sprite( 0, 160/2, 144/2);

			const int8_t distance_sample = ( scroller_x + 8*s ) & 0x3F; 
			const int8_t d_rotation_sample = abs( rotation % 64 ) / 4;

			switch( quadrant ) {
				case 0: 		// Upper left. 
				move_sprite( s, 		// +cos, -sin
					center_x - sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ], 
					center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ] 
				); break; 

				case 1: 		// Lower right. 
				move_sprite( s, 		// -cos, +sin
					center_x - sin_from_polar[ d_rotation_sample ][ distance_sample ], 
					center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ] 
				); break; 

				case 2:		// Upper right. Why right? Fuck you, that's why. 
				move_sprite( s, 		// -sin, -cos
					center_x + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ], 
					center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ] 
				); break; 

				case 3:		// Lower left. 
				move_sprite( s, 		// +cos, +sin
					center_x + sin_from_polar[ d_rotation_sample ][ distance_sample ], 
					center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ] 
				); break; 
			} 
		} 
*/



		// Print framerate. Fine performance can be tracked by updating during hblank routine, if needed / applicable. 
		// printf is useless because you can't point it at the right place. 
		// Numeral sprites start at 16. 
		// Oh of course these have a meaningful impact on framerate. Possibly just because of division. 
		const uint16_t this_frame = line_count; 
		line_count = 0; 

//		running_average = ( running_average << 3 ) - running_average + this_frame; 
//		running_average = running_average >> 3; 
		// Longer average:
//		running_average = ( running_average << 4 ) - running_average + this_frame; 
//		running_average = running_average >> 4; 
		// Longer. 
		running_average = ( running_average << 5 ) - ( running_average >> 1 ) + ( this_frame >> 1 ); 
		running_average = running_average >> 5; 

		const uint16_t fps = ( 60 * 144 ) / ( running_average / 10 ); 

		vram_pointer = get_win_xy_addr( 0, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 10) % 10 ) + 16 );
 		set_vram_byte( ( vram_pointer++ ),  14 ); 		// Decimal point. 
		set_vram_byte( ( vram_pointer++ ),  ( (fps ) % 10 ) + 16 );

		// Display raw line_count as well, because why not. 
		// (Or whatever else I want to track.)
		// field_count, rotation, 
		vram_pointer = get_win_xy_addr( 6, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (rotation / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (rotation / 10) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (rotation ) % 10 ) + 16 );


		// Variable framerate: divide line count by 144. 
			// And possibly modulo by 144? Rollover would keep things more accurate. 
//		field_count = this_frame / 144; 
		field_count = ( this_frame + field_overflow ) / 144; 		// field_overflow from previous render
		field_overflow = this_frame % 144; 

		field_count = 1; 		// Debug - go slowly

		// We don't want to wait unless we're hitting 60 Hz, which, no. 
		// Well, maybe for double-buffering. (That should still be at the start of vblank... not the end.)
//		wait_vbl_done();	
	}
}






void draw_tile() { 
	int8_t effective_x = x + ( bend_x >> 3 ); 
	int8_t effective_y = y;// + ( bend_x >> 3 ); 
	if( effective_x > 32 ) { effective_x = 32; } 
//				if( effective_x < 0 ) { effective_x = 0; } 		// Hmm.

	// DRY: use variable for sampling shenanigans. (Eventually for Y as well.)
	// Is const faster? Yeah, wow: 6.4 FPS with a reused global variable, 6.6 with const distance, 6.8 for both. 
		// Presumably thanks to informing the compiler it's just a scratch value. 
	const uint8_t distance = distance_table[ effective_x + 32 * effective_y ] + scroller_x;
	const uint8_t angle = angle_table[ effective_x + 32 * effective_y ] + rotation;// + 17; 

	// Different tube patterns: 
//				if( angle >> 5 & 0x1 ) { outbyte ^= 0x02; }
//				outbyte = ( angle >> 5 ); 		// Faux lighting from upper-left. Super good, super easy. 
//				outbyte += ( ( distance - 2 ) & 0x40 ) >> 6; 		// Reasonable pipe segments. &0x20>>5 also works. 
//				outbyte += ( angle - 64 - 8 ) >> 4; 	// Can I do dark top / light bottom, as a bidirectional gradient? Punt. 
//				outbyte = ( angle >> 4 ); 		// 16 shades (1) obviously isn't fake polygons and (2) isn't aligned to +17. 
		// Or I guess it is exactly as aligned, but previously, we wanted the midpoint in the center of 1/8th. 

	// Get some cheap division into six slices. Doesn't need to be perfect. 
	// Use a table. Duh. 
	outbyte = tube_color[ angle ]; 
//				outbyte += distance >> 4;  		// Ooh, that's a nice spiral. 
		// Even Manhattan-distance deformation look pretty nice with this. 

//				outbyte += distance >> 3; 		// Debug: plain rings for clear distance. 

	// Distance rings. 
	// Soft rings, now that we have smoother shades and faux anti-aliasing. 
	// Eventually mix up splits-and-struts versus rings-and-path. 
		// Maybe also classic checkerboard. Cosmetic variety. 
	if( ( distance & 0b110000 ) == 0 ) { 		// 0b10000 is much thicker. 0b110000, so they're further apart?
//					outbyte += 2; 
//					if( angle > 128+21 && angle < 256 - 21  ) { 		// Hex, end short of midpoint
			outbyte -= ( distance & 0b00001111 ) >> 2; 		// Oh that's nice. 
//					}
	}

	// Omnipresent bottom path. 
	// Diagonals? Angle + distance. Eh. Kinda works, but it feels spiral-y. 
	const uint8_t diagonal = angle - 4*43; 
	if( diagonal < 43 ) { outbyte += distance & 0b1100 ? 0 : 1; } 

	// That or-equals 0x80 could be worked around by rearranging CHR-RAM or modifying tube_color. 
	outbyte &= 0x0F; 		// 16 shades (at present)
	outbyte |= 0x80; 		// ... placed halfway up the tile list. 

	// Gonna bet set_vram_byte is very safe and therefore dog-slow. (Yep.)
	// With more going on, I'm not sure this has a meaningful impact performance. 
	set_vram_byte( vram_pointer, outbyte );
//					scroller_next_char++; 
//				vram_pointer++; 
	vram_pointer += xplus; 
} 










