#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>		// For e.g. abs()

#include <gb/bgb_emu.h>

// C99 comment test. Oh, thank god. 
// Anyway - Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Notably, this code initially uses an interrupt every scanline, which is undesirable, 
		// since we need all the cycles we can get for some indirection-heavy rendering. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 
// Hang on, I think this does do minimal scanline interrupts. 
	// It's not just a comparator. It sets LYC_REG - which is the switch() variable.

/*
// Banged this out in JS console because GBDK has no trig library. 
for( j = 0; j < 1; j++ ) { 
n = 0; d = 0; p = 0; z = 0; t += 1; screen = ""; xmax = 20; ymax = 32;
for( sy = 0; sy < ymax; sy++ ) { screen += "\n"; 
for( sx = 0; sx < xmax; sx++ ) { 
x = sx - ( (ymax/xmax) * xmax - 1 ) / 2; y = sy - (ymax-1)/2; y *= -1; 
d = Math.hypot( x * 20 / xmax, y * 18 / ymax ); 
z = 128/(d+0.5);
if( x > 0  && y > 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) } 
else if ( x < 0 && y > 0 ) { n = parseInt( 180 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
else if ( x < 0 && y < 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) + 180 }
else if ( x > 0 && y < 0 ) { n = parseInt( 360 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
p = n % 120  > 120/2; 
p = p ^ ( z % 10 > 5 ); 
screen += parseInt( n * 256 / 360 ) + ", " ; }  } console.log( screen ); }
*/

// These might become un-const so we can modify them on-the-fly. 
// And they might be better off as one table with interleaved elements because consecutive reads are cheaper. 
// For now, clarity is key. 
const uint8_t distance_table[] = 
/* 		// Original take, but with central 254 block -> 128s
{ 14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 128, 128, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 21, 23, 27, 32, 39, 50, 70, 113, 128, 128, 113, 70, 50, 39, 32, 27, 23, 21, 18, 
18, 20, 23, 26, 31, 37, 47, 61, 84, 113, 113, 84, 61, 47, 37, 31, 26, 23, 20, 18, 
18, 20, 22, 25, 29, 34, 41, 50, 61, 70, 70, 61, 50, 41, 34, 29, 25, 22, 20, 18, 
17, 19, 21, 24, 27, 31, 36, 41, 47, 50, 50, 47, 41, 36, 31, 27, 24, 21, 19, 17, 
17, 18, 20, 22, 25, 28, 31, 34, 37, 39, 39, 37, 34, 31, 28, 25, 22, 20, 18, 17, 
16, 17, 19, 21, 23, 25, 27, 29, 31, 32, 32, 31, 29, 27, 25, 23, 21, 19, 17, 16, 
15, 16, 18, 19, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 19, 18, 16, 15, 
14, 15, 16, 18, 19, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 19, 18, 16, 15, 14, 
14, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 14 };
*/


		// Z > 1, avoiding extremey distant middle pixels. 
{ 13, 13, 14, 15, 16, 16, 17, 18, 18, 18, 18, 18, 18, 17, 16, 16, 15, 14, 13, 13, 
13, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 13, 
14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 
15, 16, 17, 18, 20, 22, 23, 25, 26, 27, 27, 26, 25, 23, 22, 20, 18, 17, 16, 15, 
15, 16, 18, 20, 22, 24, 26, 29, 31, 32, 32, 31, 29, 26, 24, 22, 20, 18, 16, 15, 
16, 17, 19, 21, 23, 26, 30, 33, 37, 39, 39, 37, 33, 30, 26, 23, 21, 19, 17, 16, 
16, 18, 20, 22, 25, 29, 33, 39, 45, 50, 50, 45, 39, 33, 29, 25, 22, 20, 18, 16, 
16, 18, 20, 23, 26, 31, 37, 45, 57, 69, 69, 57, 45, 37, 31, 26, 23, 20, 18, 16, 
17, 18, 21, 23, 27, 32, 39, 50, 69, 105, 105, 69, 50, 39, 32, 27, 23, 21, 18, 17, 
17, 18, 21, 23, 27, 32, 39, 50, 69, 105, 105, 69, 50, 39, 32, 27, 23, 21, 18, 17, 
16, 18, 20, 23, 26, 31, 37, 45, 57, 69, 69, 57, 45, 37, 31, 26, 23, 20, 18, 16, 
16, 18, 20, 22, 25, 29, 33, 39, 45, 50, 50, 45, 39, 33, 29, 25, 22, 20, 18, 16, 
16, 17, 19, 21, 23, 26, 30, 33, 37, 39, 39, 37, 33, 30, 26, 23, 21, 19, 17, 16, 
15, 16, 18, 20, 22, 24, 26, 29, 31, 32, 32, 31, 29, 26, 24, 22, 20, 18, 16, 15, 
15, 16, 17, 18, 20, 22, 23, 25, 26, 27, 27, 26, 25, 23, 22, 20, 18, 17, 16, 15, 
14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 
13, 14, 15, 16, 17, 18, 19, 20, 20, 21, 21, 20, 20, 19, 18, 17, 16, 15, 14, 13, 
13, 13, 14, 15, 16, 16, 17, 18, 18, 18, 18, 18, 18, 17, 16, 16, 15, 14, 13, 13 };


/*
		// Formula with hypot() accounting for xmax and ymas.
{ 9, 10, 10, 11, 12, 12, 13, 13, 14, 14, 14, 14, 13, 13, 12, 12, 11, 10, 10, 9, 
10, 10, 11, 12, 13, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 13, 12, 11, 10, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 22, 24, 25, 25, 24, 22, 20, 18, 16, 15, 13, 12, 11, 
12, 13, 14, 16, 18, 20, 23, 26, 29, 31, 31, 29, 26, 23, 20, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 29, 37, 48, 61, 61, 48, 37, 29, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 106, 106, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 106, 106, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 29, 37, 48, 61, 61, 48, 37, 29, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 20, 23, 26, 29, 31, 31, 29, 26, 23, 20, 18, 16, 14, 13, 12, 
11, 12, 13, 15, 16, 18, 20, 22, 24, 25, 25, 24, 22, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 10, 11, 12, 13, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 13, 12, 11, 10, 10, 
9, 10, 10, 11, 12, 12, 13, 13, 14, 14, 14, 14, 13, 13, 12, 12, 11, 10, 10, 9 };
*/

/*
		// 32x20 version for 6-scanline-tall tile compression.
{ 9, 10, 10, 11, 11, 12, 12, 13, 13, 13, 13, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
9, 10, 11, 11, 12, 13, 13, 14, 14, 14, 14, 14, 14, 13, 13, 12, 11, 11, 10, 9, 
10, 10, 11, 12, 12, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 12, 12, 11, 10, 10, 
10, 11, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 15, 14, 13, 12, 11, 11, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 11, 12, 13, 14, 16, 17, 18, 19, 19, 19, 19, 18, 17, 16, 14, 13, 12, 11, 10, 
11, 12, 13, 14, 15, 17, 18, 20, 21, 21, 21, 21, 20, 18, 17, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 19, 21, 23, 24, 24, 23, 21, 19, 18, 16, 14, 13, 12, 11, 
11, 12, 14, 15, 17, 19, 21, 23, 25, 26, 26, 25, 23, 21, 19, 17, 15, 14, 12, 11, 
11, 13, 14, 16, 18, 20, 23, 25, 28, 30, 30, 28, 25, 23, 20, 18, 16, 14, 13, 11, 
12, 13, 14, 16, 18, 21, 24, 28, 32, 35, 35, 32, 28, 24, 21, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 50, 50, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 29, 38, 50, 64, 64, 50, 38, 29, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 86, 86, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 119, 119, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 119, 119, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 86, 86, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 29, 38, 50, 64, 64, 50, 38, 29, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 50, 50, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 31, 37, 41, 41, 37, 31, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 21, 24, 28, 32, 35, 35, 32, 28, 24, 21, 18, 16, 14, 13, 12, 
11, 13, 14, 16, 18, 20, 23, 25, 28, 30, 30, 28, 25, 23, 20, 18, 16, 14, 13, 11, 
11, 12, 14, 15, 17, 19, 21, 23, 25, 26, 26, 25, 23, 21, 19, 17, 15, 14, 12, 11, 
11, 12, 13, 14, 16, 18, 19, 21, 23, 24, 24, 23, 21, 19, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 17, 18, 20, 21, 21, 21, 21, 20, 18, 17, 15, 14, 13, 12, 11, 
10, 11, 12, 13, 14, 16, 17, 18, 19, 19, 19, 19, 18, 17, 16, 14, 13, 12, 11, 10, 
10, 11, 12, 13, 14, 15, 16, 17, 17, 18, 18, 17, 17, 16, 15, 14, 13, 12, 11, 10, 
10, 11, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 15, 14, 13, 12, 11, 11, 10, 
10, 10, 11, 12, 12, 13, 14, 15, 15, 15, 15, 15, 15, 14, 13, 12, 12, 11, 10, 10, 
9, 10, 11, 11, 12, 13, 13, 14, 14, 14, 14, 14, 14, 13, 13, 12, 11, 11, 10, 9, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 13, 13, 13, 13, 12, 12, 11, 11, 10, 10, 9 }; 
*/

/*
		// Aspect ratio correction. (Still fucky.)
{ 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 17, 19, 20, 22, 22, 22, 22, 20, 19, 17, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 20, 21, 23, 24, 24, 23, 21, 20, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 23, 24, 26, 26, 24, 23, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 14, 15, 17, 19, 21, 24, 26, 27, 27, 26, 24, 21, 19, 17, 15, 14, 12, 11, 
11, 13, 14, 16, 17, 20, 22, 25, 28, 30, 30, 28, 25, 22, 20, 17, 16, 14, 13, 11, 
12, 13, 14, 16, 18, 20, 23, 27, 30, 33, 33, 30, 27, 23, 20, 18, 16, 14, 13, 12, 
12, 13, 14, 16, 18, 21, 25, 29, 33, 36, 36, 33, 29, 25, 21, 18, 16, 14, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 30, 36, 40, 40, 36, 30, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 23, 27, 32, 39, 45, 45, 39, 32, 27, 23, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 51, 51, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 24, 29, 37, 47, 59, 59, 47, 37, 29, 24, 20, 17, 15, 13, 12, 
12, 14, 15, 17, 20, 24, 30, 38, 52, 70, 70, 52, 38, 30, 24, 20, 17, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 84, 84, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 104, 104, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 124, 124, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 42, 63, 124, 124, 63, 42, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 41, 61, 104, 104, 61, 41, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 18, 21, 25, 31, 40, 57, 84, 84, 57, 40, 31, 25, 21, 18, 15, 14, 12, 
12, 14, 15, 17, 20, 24, 30, 38, 52, 70, 70, 52, 38, 30, 24, 20, 17, 15, 14, 12, 
12, 13, 15, 17, 20, 24, 29, 37, 47, 59, 59, 47, 37, 29, 24, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 20, 23, 28, 34, 43, 51, 51, 43, 34, 28, 23, 20, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 23, 27, 32, 39, 45, 45, 39, 32, 27, 23, 19, 17, 15, 13, 12, 
12, 13, 15, 17, 19, 22, 26, 30, 36, 40, 40, 36, 30, 26, 22, 19, 17, 15, 13, 12, 
12, 13, 14, 16, 18, 21, 25, 29, 33, 36, 36, 33, 29, 25, 21, 18, 16, 14, 13, 12, 
12, 13, 14, 16, 18, 20, 23, 27, 30, 33, 33, 30, 27, 23, 20, 18, 16, 14, 13, 12, 
11, 13, 14, 16, 17, 20, 22, 25, 28, 30, 30, 28, 25, 22, 20, 17, 16, 14, 13, 11, 
11, 12, 14, 15, 17, 19, 21, 24, 26, 27, 27, 26, 24, 21, 19, 17, 15, 14, 12, 11, 
11, 12, 13, 15, 16, 18, 20, 23, 24, 26, 26, 24, 23, 20, 18, 16, 15, 13, 12, 11, 
11, 12, 13, 14, 16, 18, 20, 21, 23, 24, 24, 23, 21, 20, 18, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 16, 17, 19, 20, 22, 22, 22, 22, 20, 19, 17, 16, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 21, 20, 19, 18, 16, 15, 14, 13, 12, 11 }; 
*/

const uint8_t angle_table[] = 

{ 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 44, 40, 36, 34, 32, 29, 
100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 41, 37, 34, 32, 29, 27, 
103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 39, 34, 32, 28, 26, 24, 
105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 35, 32, 28, 25, 22, 21, 
109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 32, 27, 24, 21, 19, 17, 
113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 26, 22, 19, 17, 15, 14, 
117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 20, 17, 14, 12, 11, 9, 
121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 12, 10, 8, 7, 7, 5, 
125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 4, 3, 2, 2, 2, 2, 
130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 251, 251, 252, 253, 253, 253, 
133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 242, 244, 246, 247, 248, 249, 
137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 234, 238, 240, 242, 243, 245, 
142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 228, 232, 235, 237, 239, 241, 
145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 224, 227, 231, 233, 236, 237, 
149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 219, 224, 226, 229, 232, 233, 
152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 216, 220, 224, 226, 228, 231, 
155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 213, 217, 220, 224, 226, 228, 
157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 211, 214, 218, 221, 224, 226 }; 


/*
		// 32x20 version for compressed display:
{ 95, 93, 90, 87, 84, 81, 77, 73, 69, 65, 61, 57, 53, 49, 46, 42, 39, 36, 34, 32, 
96, 94, 91, 88, 86, 82, 78, 74, 70, 66, 61, 56, 52, 48, 44, 41, 38, 35, 32, 30, 
98, 96, 93, 90, 87, 83, 79, 75, 71, 66, 61, 56, 51, 47, 43, 39, 36, 34, 31, 29, 
99, 97, 94, 91, 88, 84, 81, 76, 71, 66, 61, 56, 51, 46, 42, 38, 35, 32, 29, 27, 
100, 98, 96, 93, 90, 86, 81, 77, 71, 66, 61, 55, 49, 45, 40, 36, 33, 30, 28, 26, 
103, 100, 98, 95, 91, 88, 83, 78, 72, 66, 60, 54, 49, 43, 39, 35, 32, 29, 26, 24, 
104, 103, 100, 97, 93, 90, 85, 79, 73, 66, 60, 53, 47, 41, 36, 33, 29, 27, 24, 22, 
106, 104, 102, 99, 96, 92, 87, 81, 74, 67, 59, 52, 45, 39, 34, 31, 27, 24, 22, 20, 
108, 107, 104, 102, 98, 94, 89, 83, 76, 68, 59, 51, 43, 37, 32, 28, 24, 22, 19, 18, 
110, 109, 107, 104, 101, 97, 92, 86, 78, 68, 58, 49, 41, 34, 29, 25, 22, 19, 17, 16, 
113, 111, 110, 108, 104, 100, 96, 89, 80, 69, 57, 46, 37, 31, 26, 22, 19, 17, 15, 13, 
115, 114, 113, 110, 108, 104, 100, 93, 83, 71, 56, 43, 34, 27, 22, 19, 16, 14, 12, 11, 
118, 117, 115, 114, 112, 109, 104, 98, 88, 72, 54, 39, 29, 22, 17, 14, 12, 11, 9, 8, 
120, 120, 119, 118, 116, 113, 110, 104, 94, 76, 51, 32, 22, 17, 13, 10, 9, 7, 7, 6, 
123, 123, 122, 121, 120, 119, 117, 113, 104, 83, 43, 22, 14, 9, 7, 6, 5, 4, 4, 3, 
126, 125, 125, 125, 125, 125, 123, 122, 119, 104, 22, 7, 4, 3, 2, 2, 1, 1, 1, 0, 
128, 129, 129, 129, 130, 130, 131, 132, 135, 150, 232, 247, 250, 251, 253, 253, 253, 253, 253, 254, 
131, 132, 132, 133, 134, 135, 137, 142, 150, 171, 211, 232, 241, 245, 247, 248, 249, 250, 251, 251, 
134, 135, 135, 137, 138, 141, 145, 150, 160, 179, 204, 222, 232, 238, 241, 244, 246, 247, 248, 248, 
136, 137, 139, 140, 142, 145, 150, 157, 167, 182, 200, 216, 226, 232, 237, 240, 242, 243, 245, 246, 
139, 140, 142, 144, 147, 150, 155, 162, 171, 184, 199, 211, 221, 228, 232, 236, 238, 241, 242, 243, 
141, 143, 145, 147, 150, 154, 159, 165, 174, 185, 197, 208, 217, 224, 228, 232, 236, 238, 239, 241, 
144, 145, 147, 150, 153, 157, 162, 169, 177, 186, 196, 206, 214, 220, 225, 229, 232, 235, 237, 238, 
146, 147, 150, 152, 156, 160, 165, 171, 179, 187, 196, 204, 211, 217, 222, 226, 230, 232, 235, 236, 
148, 150, 152, 155, 159, 162, 167, 173, 180, 187, 195, 202, 209, 215, 220, 224, 227, 230, 232, 234, 
150, 152, 155, 157, 161, 164, 169, 175, 181, 188, 194, 201, 207, 213, 218, 221, 225, 228, 231, 232, 
152, 154, 157, 160, 163, 167, 171, 177, 182, 188, 194, 200, 206, 211, 216, 219, 223, 226, 228, 231, 
154, 156, 158, 161, 164, 168, 173, 177, 183, 189, 194, 199, 205, 209, 214, 218, 221, 224, 226, 228, 
155, 157, 160, 163, 166, 170, 174, 179, 184, 189, 194, 199, 204, 209, 212, 216, 219, 222, 225, 227, 
157, 159, 162, 164, 167, 171, 175, 179, 184, 189, 194, 199, 203, 207, 211, 215, 218, 221, 224, 226, 
158, 160, 163, 166, 169, 172, 176, 180, 184, 189, 194, 198, 202, 206, 210, 214, 216, 219, 222, 224, 
160, 162, 164, 167, 170, 174, 177, 181, 185, 189, 193, 197, 201, 205, 209, 212, 215, 218, 221, 223 }; 
*/

/*
		// Aspect ratio correction, because 32x20 is not remotely square:
{ 96, 94, 93, 91, 89, 88, 86, 83, 81, 79, 77, 75, 72, 70, 67, 64, 62, 59, 56, 54, 
96, 96, 93, 92, 91, 88, 87, 85, 83, 81, 78, 76, 73, 70, 67, 64, 62, 59, 56, 54, 
98, 97, 96, 93, 92, 90, 88, 86, 84, 81, 79, 76, 73, 71, 68, 65, 61, 59, 56, 53, 
100, 98, 97, 96, 93, 92, 90, 88, 85, 83, 80, 77, 74, 71, 68, 65, 61, 59, 55, 52, 
101, 100, 98, 97, 96, 93, 91, 89, 87, 84, 81, 78, 75, 72, 68, 65, 61, 58, 54, 51, 
103, 102, 100, 98, 97, 96, 93, 91, 88, 86, 83, 80, 76, 73, 69, 65, 61, 57, 54, 50, 
105, 103, 102, 100, 99, 97, 96, 93, 91, 88, 85, 81, 78, 73, 69, 66, 61, 57, 53, 49, 
107, 105, 104, 103, 101, 100, 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 
109, 108, 106, 105, 103, 102, 100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 
111, 110, 109, 108, 106, 105, 103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 
113, 113, 111, 110, 109, 108, 105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 
115, 115, 114, 113, 112, 110, 109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 
118, 118, 117, 116, 115, 114, 113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 
120, 120, 120, 119, 118, 118, 117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 
123, 123, 123, 123, 122, 121, 121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 
126, 126, 125, 125, 125, 125, 125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 
128, 128, 129, 129, 129, 129, 130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 
131, 131, 132, 132, 132, 133, 133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 
134, 134, 135, 135, 136, 137, 137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 
136, 137, 137, 138, 139, 140, 142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 
139, 140, 140, 141, 142, 144, 145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 
141, 142, 143, 144, 145, 147, 149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 
143, 145, 145, 147, 148, 150, 152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 
145, 147, 148, 149, 151, 152, 155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 
147, 149, 150, 152, 153, 155, 157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 
150, 151, 152, 154, 155, 157, 160, 162, 164, 167, 169, 173, 177, 181, 185, 189, 194, 197, 201, 206, 
152, 152, 154, 156, 157, 160, 161, 164, 166, 169, 172, 174, 178, 182, 185, 189, 193, 197, 201, 204, 
153, 155, 156, 157, 160, 161, 163, 165, 167, 170, 173, 176, 179, 182, 186, 189, 193, 196, 200, 203, 
155, 156, 157, 160, 161, 162, 164, 167, 169, 172, 174, 177, 180, 183, 187, 189, 193, 196, 199, 202, 
157, 157, 160, 161, 162, 164, 166, 168, 170, 173, 175, 178, 181, 184, 187, 189, 193, 196, 199, 201, 
158, 160, 161, 162, 164, 166, 167, 169, 172, 174, 177, 179, 182, 184, 187, 190, 192, 195, 198, 201, 
160, 160, 162, 164, 165, 167, 169, 171, 173, 175, 177, 179, 182, 184, 187, 190, 192, 195, 198, 200 }; 
*/

/* 
I fucking hate dealing with bitmasks in hex, but binary is so verbose. 

0000 = 0
0001 = 1
0010 = 2
0011 = 3

0100 = 4
0101 = 5
0110 = 6
0111 = 7

1000 = 8
1001 = 9
1010 = A
1011 = B

1100 = C
1101 = D
1110 = E
1111 = F

*/

const unsigned char gradient_data[] = { 

	/* 0xFF to 0x00, presumably white to black */
	/* 0b1010 = A, 0b0101 = 5 */
	// Black. Black / dark. Dark. Dark / light. Light. Light / white. White. 
	// Currently have 13 colors via simple dithering in 4-pixel patterns. Need a few more for easy power-of-two 16. 
	// Could just stuff some duplicate darks in there, for later? Dark is probably where we want more detail. 

	// BB/BB
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 		// Black: 1/1

	// BB/BD
	0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 		// Pips
	0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 		// BB/BB

	// BD/BD
	// B is 1/1, D is 0/1
	0b01010101, 0xFF, 
	0b11101110, 0xFF, 
	0b01010101, 0xFF, 
	0b10111011, 0xFF,

	0b01010101, 0xFF, 
	0b11101110, 0xFF,
	0b01010101, 0xFF, 
	0b10111011, 0xFF,
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// BD/BD 

	// BD/DD
/*
0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 

0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 
*/
	0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 		// BD/DD 

	// DDDD DDDD / BDDD BDDD / DDDD DDDD / DDBD DDBD 
	// Or should it be DDDB / DBDD? Argh. 
	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF, 

	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF,  

	// DD/DD
	0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF, 		// Dark: 0/1

	// DD/DL
	0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,

	// DL/DL
	0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA,  	// 0/1 + 1/0 

	// DL/LL
	0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 

	// LL/LL
	0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00, 		// Light: 1/0

	// LL/LW
	0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 

	// LW/LW
	0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 	// 1/0 + 0/0

	// LW/WW
	0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 

	// WW/WW
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 		// White: 0/0
	// This needs to not go white-white.
	// Good answers? Dunno. Just mix with black for now. 

//	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 		// White again

	// BW/BW
	0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA 
		// Black+white

};

const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
const uint8_t * scanline_offsets = scanline_offsets_tbl;

#define SCROLL_POS 15
#define SCROLL_POS_PIX_START (SCROLL_POS * 8) - 1
#define SCROLL_POS_PIX_END ((SCROLL_POS + 1) * 8) - 1

uint8_t scroller_x = 0;

const uint8_t scroller_text[] = "This is a text scroller demo for GBDK-2020. You can use ideas, that are "\
"shown in this demo, to make different parallax effects, scrolling of tilemaps which are larger than 32x32 "\
"tiles and TEXT SCROLLERS, of course! Need to write something else to make this text longer than 256 characters. "\
"The quick red fox jumps over the lazy brown dog. 0123456789.          ";

// Some of these are redundant holdovers from the original text_scroller.c code. I forget which. 
const uint8_t* scroller_next_char = scroller_text;
uint8_t* scroller_vram_addr;
uint16_t base, limit;

uint8_t* vram_pointer; 


// Tube stuff
uint8_t outbyte, angle, screen_distance, distance, input, jitter; 		// Scratch variables 
int8_t rotation = 11; 		// Game state
int8_t rotation_impulse = 10; 		// Input accumulator
int16_t curve_x = 0; 		// Curve offset vectors - goofy sampling gimmick
int16_t curve_y = 0; 
uint8_t tube_color[256]; 		// Might make this multi-dimensional. 
	// E.g. tube_color[2][256] for alternating patterns, 
		// or straight-up using this to encode our level designs. 
	// Some map could be sections 0, 0, 0, 7, 3, and that'd be normal shit followed by cutouts or whatever. 
// Eventually need centripital force variable. Though curve info may suffice. (If all tracks are level.) 

// FPS stuff
uint16_t line_count = 0; 		// This frame 
uint16_t running_average = 1024; 		// Over time - nonzero initial value






// Interrupt functions

uint8_t sy = 0; 

void half_tile_isr() { 
	// Okay: SCY_REG is a -global- scroll register. It is not "which scanline are we on, right now."
	// It changes which scanline is at the logical top of the screen. 
	// So we can't just sy*8 to go, "next scanline, start drawing from tile row sy."
	// This kinda-sorta makes sense, but it is a tremendous pain in the ass for comprehension, 
		// when mixed with LYC_REG needing a strict objective "where are we NOW?" number. 
	// TL;DR LYC to sy*i and SCY to k where i+k = 8. 
	LYC_REG = sy * 5;    
	SCY_REG += 3; 
//	SCX_REG += 1; 		// Tilting for a turn effect? Eh. 
	sy++; 

	// Debug, making row heights crystal clear:
//	SCX_REG += 128; 

	// So why the fuck is the top row still 7 pixels? Whatever. 
	// I'd have to switch to the window to get 4px-tall tiles. 
	// Or: naive 4px rows, plus a narrow hud at the bottom. linear map, maybe. 
	// Or: 5px rows, and we only waste one scanline. But the dithering might mismatch. (Yeah, it does.) 
	// Dithering could be handled by alternating SCY_REG increments. 

	line_count += 4; 		// FPS guff 
}

void my_vblank_isr() { 
	LYC_REG = 1; 
	SCY_REG = 0;
//	SCX_REG = -16; 
	sy = 1; 
	line_count += 144; 		// FPS tracking. Not 154 because the scanline version doesn't count vblank. 
	line_count += 10; 		// Account for all scanlines. Probably. Might be missing a few anyway. 
}






// Main functionality 

void main() {
//	const uint8_t* angle_table_split = &angle_table[16*20]; 
//	const uint8_t* distance_table_split = &distance_table[16*20]; 
	printf( "Scrolling %d chars", sizeof( scroller_text ) - 1 ); // Need a printf for GBDK to include text characters. 

	// Load tile data to CHR-RAM
	set_bkg_data(0x00, 0x08, gradient_data);
	set_bkg_data(128, 128, gradient_data);  

	// Fill tube_color because division by six is weirdly expensive. 
	// "Anything that only happens once is free."
	// Weirdly difficult to get a loop of 256. 
	const uint8_t sides[] = { 2, 0, 1, 2, 3, 4, 2, 0 }; 		// 8 instead of 6 because modulo is acting weird. 
	for( uint8_t n = 255; n > 0; n-- ) { 
//		tube_color[n] = n / 43 + 128; 		// Sixths. Honestly looks better than eighths. 
		const uint8_t side = n / 43 + 1; 	// To simplify dealing with non-uniform gradients. 
		tube_color[n] = sides[ side ]; 		// 0..5. 6*43 is 258. 
//		if( side == 5 ) { tube_color[n] = 2; } 		// Faux shading. 

		// Faux subsampling? 0..5 x2 -> 0..10, and use an in-between color right near the boundary. 
		// "Anti-aliasing." Three colors per side, or just two? Three fits but may be overkill. 
		tube_color[n] *= 2; 
//		if( n % 43 > 40 ) { tube_color[n]++; } 
//		if( n % 43 < 2 ) { tube_color[n]--; } 
		// Wow, that's nice. 
//		if( n % 43 > 40 ) { tube_color[n] += sides[ ( side + 1 ) % 6 ]; tube_color[n] /= 2; } 
//		if( n % 43 < 2 ) { tube_color[n] += sides[ ( side - 1 ) % 6 ]; tube_color[n] /= 2; } 
		if( n % 43 > 40 ) { 
			if( sides[ side + 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}
		if( n % 43 < 2 ) { 
			if( sides[ side - 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}

		// This setup loop should also handle most of the tube-color stuff. 
		// So e.g. add 3 to every thing for a fairly naive sawtooth gradient that looks about right. 
		// But ideally I'd like to make the bottom white(ish), the upper-right dark, 
			// and the lower-right about as dim as the upper-left. 
		tube_color[n] += 3; 

		tube_color[n] += 128; 		// Tiles in the middle. (Letters at the front.) 
			// I could use a bit to indicate boundaries.
			// Really I could use several, we're only encoding 16 shades so far. 
			// Masking is cheap and it'd let us substitute rotation-aware diagonals. 
	}
	// Then set tube_color[0] if it's not supposed to be black. 
	tube_color[0] = tube_color[1]; 		// Easy hack. 

	// Compression to 4-scanline-high tiles has tolerable performance impact. 
	// It's rendering all those tiles that kills us. 
	// We might go for diagonal tiles and skip scanline shenanigans altogether. 
	// In which case: we do still need VBL_IFLAG. (Or is that just for wait_vbl_done?) 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
//		add_LCD( half_tile_isr );
		add_VBL( my_vblank_isr ); 		// Two hard problems. 
//		set_interrupts( VBL_IFLAG | LCD_IFLAG );
		set_interrupts( VBL_IFLAG );
	}

	// FPS / HUD
	init_win( 6 ); 		// All white, probably. 
//	move_win( 130, 132 ); 		// Lower right corner. X, Y. 
	move_win( 8, 132 ); 		// 8px discrepancy because sprites need to scroll offscreen. Whatever. 
	SHOW_WIN; 		// Equivalent to LCDC_REG|=0x20U

	// Initial game state
	curve_x = 0; 		// 512 is a scientific wild-ass guess. 
	curve_y = 0; 
		// Uncertain fixed-point format. 		
		// But division's going to be with a number from 0..128, so...
		// No, hang on, the result needs to be in the range of like 0..10. Or less. 
		// Large results are probably fine because we can shift down and still benefit from accuracy. 

	while ( 1 ) {
		// Book-keeping
		scroller_x++;

		// Surely I can just throw bytes into VRAM addresses. 
			// Severely overthinking this: *vram_pointer = *scroll_next_char. 
			// Ignoring vblank and just constantly throwing bytes is visibly a bit faster. 
			// Do we really care about the bugs? If we're always drawing, 
				// we don't mind some missing tiles. They'll get got. 
		// Accurate framerate requires some vblank counting. (Fuck hblanks, just average.) 
		// Make it work - make it fast - make it pretty. In that order. 

		// Input
		input = joypad(); 
//		if( input & J_LEFT ) { rotation -= 10; } 
//		if( input & J_RIGHT ) { rotation += 10; } 

		if( input & J_LEFT ) { rotation_impulse -= 10; } 		// 10 is good. Maybe a bit squirrely. 
		if( input & J_RIGHT ) { rotation_impulse += 10; } 
		rotation += rotation_impulse; 
		rotation_impulse -= rotation_impulse / 2;
		if( rotation_impulse <= 3 ) { rotation_impulse = 0; } 
		// We should really only push this in the direction of gravity. 
		// It's probably fine. 
		// ... why can you go further right than left? God dammit. 

		// Numeric limits are unnecessary when the impulse is being halved. 
		// Buuut we might need to do this just in case "over the top" results in wild loops. 
//		if( rotation_impulse > 10 ) { rotation_impulse = 40; } 
//		if( rotation_impulse < -10 ) { rotation_impulse = -40; } 

		// Rotation impulse has to change based on rotation, so you can go "over the top." 
		// Durr, over the top, it should speed up. 
		// Okay, that kinda works, but it feels bad right now. Super fast come back around the other side. 
		// Need some limitations on rotation speed, even when falling back down the far side. 
		// And maybe disable up-the-wall controls until you're back down? 
		// Use of negatives might be completely the wrong idea, because it is more hassle to deal with signs. 
		// "Physics" should probably separate gravity (and its direction) from rotation_impulse. 
		// We might never bring the camera over the top. It could be better, overall, to let the car move independently. 
		// Should almost give the car (and/or camera) a proper left/right velocity. Less guesswork, more book-keeping. 

		// Physics
//		rotation -= rotation >> 2; 
		rotation -= rotation / 4; 		// Be safe. 

//		const int8_t slide = rotation >> 2; 
//		rotation -= abs( slide ) > 20 ? 20 : slide; 

//		rotation -= rotation > 0 ? 1 : -1; 
		if( rotation > 0 ) { rotation -= 1; } 
		if( rotation < 0 ) { rotation += 1; }
		// Why does it still balance off-center? 
//		rotation = 1; 
		// It's... centered on 1? The fuck. 

		if( input & J_UP ) { curve_x += 1; } 
		if( input & J_DOWN ) { curve_x -= 1; } 

		// Rendering 
		jitter = scroller_x; 
		for( uint8_t y = 0; y < 18; y++ ) { 		// 18 naively, 29-32 compressed. 15 for debug. 
			vram_pointer = get_bkg_xy_addr( 0, y );
			for( uint8_t x = 0; x < 20; x++ ) { 
//				const uint16_t index = x + 20*y; 		
					// Add benchmarking before trying this. It's not a guaranteed improvement.

//				set_vram_byte( (vram_pointer++), x + y*16 ); continue; 		// DISPLAY ALL TILES

//				distance = distance_table[ x + 20*y ] + 2*scroller_x;
//				angle = angle_table[ x + 20*y] + rotation + 17; 		// 22.5 degree tweak. 17, not 16? The fuck. 
				// Displacement: distance needs to be in plain screen-space, and angle is unused. 
				distance = distance_table[ x + 20*y ];   

				// Can I do curves by displacing a second sample, based on distance?
				// Basically have some X/Y displacement vector for this frame, 
					// scale from <0,0> up to that based on "distance", 
					// and resample <x,20*y> + that scaled vector. 
				// Distance scales nearly all the way from 0 to 128. (More like 13 to 105.) 
				// We could limit the scale further by subtracting from e.g. 200. 
				// Thus: no possibility of 512/1, or similarly too-large results. 
				// 512/(200-128) is 7. But 512/(200-10) is still 3.
				// Okay, it kinda-sorta works. <512,512> is a curve off to the upper-left. 
				// That vector needs to be rotated per-frame, before these x/y for-loops. 

				// Mapped it to up/down. Extreme curves look better than tight ones. 
				// Except the very middle is kinda stuck and the edges obviously wrap around. 
				// Basically I should intentionally stretch my data to fit the desired limits. 0..64, maybe. 
					// If that's slow - use another table. 
				// Edges need to stay put. They go from 13 to 18. 
				// Middle jumps 39, 50, 69, 105. Hence the weird middle bit. 
				// Hey, uh. Why were these unsigned? 

//				distance = distance >= 18 ? distance : 18; 
//				distance = distance <= 64 ? distance : 64; 
//				const uint16_t offset_x = curve_x / ( 200 - distance );
//				const uint16_t offset_y = curve_y / ( 200 - distance ); 
//				const uint16_t offset_x = curve_x / ( 512 - ( distance - 18 ) );  
//				const uint16_t offset_y = curve_y / ( 512 - ( distance - 18 ) ); 
//				const uint16_t offset_x = ( curve_x / ( 200 - distance ) ) >> 3;
//				const uint16_t offset_y = ( curve_y / ( 200 - distance ) ) >> 3; 
/*
				// Fuck this. Multiply instead? 
				distance = distance >= 18 ? distance - 18 : 0; 		// Saturate down to 0. Max should now be 87. 
//				distance = distance + distance >> 2; 		// Max 130, but whatever, we're 8-bit. 
//				distance = distance << 1: 		// Multiply by 2 to keep it under 256. 
				distance = distance >> 3; 		// Why shift up if we're gonna shift down? 

				int16_t offset_x = ( distance * curve_x ) >> 4; 
				int16_t offset_y = 0; 		// Debug 
*/
/*
				if( offset_x  < -10 ) { offset_x = -10; } 
				if( offset_x  > 10 ) { offset_x = 10; } 
				if( offset_x + x > 20 ) { offset_x = 20 - x; } 
				if( offset_x + x < 0 ) { offset_x = x; } 
*/

				// Shift down is so multiplication by very small offset vectors stay within 8-bit bounds. 
				// E.g. 87 >> 3 is 10, so we can go up to an offset of, like... 2. 
				// That multiplication will get us 20, which hang on we're just gonna reduce back down. 
				// So no, 87 >> 3 = 10 can be multiplied up to 25, and then needs to be shifted to below 20. 
				// Which would be >> 4 for division by 16. 
				// Oh dear god I keep forgetting 8-bit and signs are a nightmare. 
				// Well now. That is... immediately wrong, in a very sudden and creative way. 
				// distance >> 4 above helps a -bit- but doesn't fix the underlying what-the-fuckery. 
				// I've done little to limit staying within x/y boundaries. 
					// Which is probably why it sometimes looks like it's curving upwards, when we're only changing curve_x. 
					// But at least this looks -okay- with >>5 below and like two taps of the "up" key. 
					// Ah, had it +50 per press. Thought I undid that. 
				// Printed curve_x instead of scanline count.
					// 30-40 is about the limit, for distance>>4 and offset_x>>5. 
					// It still loops around and get screwy, even with offset_x limits below. 
					// 7 or 8 is the limit for distance>>3 and offset_x>>5, because it starts going backwards at the edges. 

				// Texturing with rings (outbyte = distance >> 3) makes it clear this might just be fucked. 
				// Like maybe there's a fundamental problem with the concept. 
				// The side "into" the curve, the inner edge, is okay-ish. 
				// The outer side is screwy because the vanishing point is super visible, right there, unmoving. 
				// At high speed and high deflection it's obvious we're just 
					// mapping the image of the tunnel onto the tunnel. 
				// The outer edge winds up with two locii and almost immediately has visible errors. 
					// The rings in particular gloop backwards when they get near the camera, at the vertical midpoint. 
				// Long story short - this is not a viable path method of faking a curve. 

				// So what do we do instead?
				// Using the distance table makes perfect sense, as this is fundamentally about 
					// concentric circles displaced further as you move away. 
				// Though there's maybe a nonlinear element to that as constant changes in angle or distance
					// should presumably suffer inverse-linear scaling. 
				// Basically we want the centerpoint to move. Which is difficult to do inversely because 
					// you're actually -sampling- the point where it should go. 
				// Possible easy fix - new table for a dome projection. 
				// If we're essentially mapping the image of a tube, we can map it onto something 
					// contiguous and smooth. 
				// Estimation of an ideal shape might be done by doing the actual work of 
					// projecting many curved cylinders in various directions, 
					// then averaging out the samples into some one-dimensional map. 
						// Because of course I've overlooked how this -only- uses distance. 
						// If we have some small range of distance values (or even simply distance indices) 
							// and a relatively small number of deflection steps, that can be a 128x20x 2-byte map, at worst. 
						// Potentially more like 20x10x 1-byte signed offset. 
					// Orrr I could take a wild stab at some square-root curve. 
				// Since speed's not an issue for testing's sake, I could just do sqrts here. (No function provided. Bluh.)
					// GBDK's lack of a math library is such a pain that I might contribute just to fix that. 
					// Including some compiler macros for like FAKE_DIV( x, y ) with shifts.
				// In the meantime: Manhattan distance? 

//				distance = abs( ( x - 10 ) + ( y - 9 ) ); 		// Jank Manhattan distance. Max 19. 
					// Oh wow. That's not correct, but it is wrong in a visually interesting way. 
//				distance = abs( x - 10 ) + abs( y - 9 ); 		// Haha, backwards. 
					// This does accidentally show off the another possibility: moving the camera off-center. 
					// It is a janky but dirt-cheap way to keep the center centered and move the edges. 
				distance = ( 10 - abs( x - 10 ) ) + ( 9 - abs( y - 9 ) ); 
					// That's correct Manhattan distance, and boy is it boring. 
					// There is no sense of the tunnel curving . No big surprise, in represpect. 
					// It's not a projection where offset changes with distance. 
					// It's just shifting the middle of the screen around, smoothly and linearly. 
					// Of course that's going to look like a naive movement of the vaninishing point. 
					// Now, with less jank, this might still be USABLE. It suffices to convey a change of direction. 
					// Adding all the rings and path-dots and such should convey the central concept. 
					// And it beats x-shearing (if barely) because the walls scale differently. 
					// But we could do that shit with quadrants and subsampling for-loops. 
						// (I.e., center of pipe to edge of screen, 0..80 by some fixed-point value, and >>3 to get x=0..10.) 
					// Six-sided tube makes this approach look bad because some edges are right on the horizon. 
					// Ooh, no, it works fine with more obvious segments. 

				// Spiral? Odd alternative, but hey, we're linear. Can we slowly change the distance and offset of some counter values, while drawing our pipe somewhat like an actual pipe? Avoiding the inverse projection shenanigans of sampling x/y to get whatever will -arrive- at x/y, by purely functional means. Instead: iterate. Probably still in pixel-order instead of geometry-order? But maybe not. Sub-pixel accuracy might let us do a spiral from an offset center and... god, trying to fill all tiles from that would be a pain. 
				// Other nonlinear orderings are feasible. Curve-aligned diagonals. Or if we're going that route, use the rotating fixed-distance background thing we want for the horizon. 
				// Treat as rectangular? Pretend we're drawing a square one of these and sample square 'rings.' (going to 20x20 or 18x8 if that makes comprehension easier.) like the rainbow-tunnel thing in titan overdrive 2. Sample some spans twice and skip others. 
				// Subdivide? e.g. draw 4x4 regions and shift them to be correct-ish locally. Hm. Doing things the hard way at a different scale still requires knowing how to do them correctly. 
				// What we're doing now works well enough locally - we just need it to be nonlinear. Ahhh, so maybe test distance -after- doing this transformation, and resample with a smaller shift if closer. Maybe recursively? Hopefully not, that sounds expensive. Should work with just distance-from-camera and distance-from sample. Close to camera but massively displaced needs more attention / correction than close to camera and nearly normal. 
				// Brain says there's some lookup-centric solution here, if we're only going to do curves in single-digit integers. Oh, for Manhattan distance! That was it. euclidian[10][9] or whatever. pass in x/y, get proper hypoteneuse. 
					// Fancier gimmicks seem untenable: array[20][18][5] is already split, because we're handling +/- 5. er, 4. because zero. and rotation would get weird in a hurry. 
					// Might want to average out with some other formula to get 0 at the edges. 

//				const uint16_t offset_x = curve_x / ( 200 - distance );
//				const uint16_t offset_y = curve_y / ( 200 - distance ); 

				int16_t offset_x = ( distance * curve_x ) >> 4; 
				int16_t offset_y = 0; 		// Debug 

/*
				if( offset_x  < -10 ) { offset_x = -10; } 
				if( offset_x  > 10 ) { offset_x = 10; } 
				if( offset_x + x > 20 ) { offset_x = 20 - x; } 
				if( offset_x + x < 0 ) { offset_x = x; } 
*/
				int8_t effective_x = x + offset_x; 
				if( effective_x >= 20 ) { effective_x = 19; } 		// Avoid wraparound. 
				if( effective_x < 0 ) { effective_x = 0; } 


//				distance = distance_table[ x + offset_x + 20 * ( y + offset_y ) ] + 2*scroller_x; 
//				angle = angle_table[ x + offset_x + 20 * ( y + offset_y ) ] + rotation + 17; 

				// DRY: use variable for sampling shenanigans. (Eventually for Y as well.)
//				distance = distance_table[ effective_x + 20 * ( y + offset_y ) ] + 2*scroller_x;
				screen_distance = distance_table[ effective_x + 20 * ( y + offset_y ) ];  
				distance = screen_distance + 2*scroller_x; 
				angle = angle_table[ effective_x + 20 * ( y + offset_y ) ] + rotation;// + 17; 

				// Incorporate jitter for sampling. 
//				distance += ( jitter + x << 3 + y << 4 ) & 0x3; 		// 2 bits "at random." Er. No effect? 
//				angle += ( jitter ^ x ^ y ) & 0x3; 		// Meh. 


//				if( angle >> 5 & 0x1 ) { outbyte ^= 0x02; }
				outbyte = ( angle >> 5 ); 		// Faux lighting from upper-left. Super good, super easy. 
//				outbyte += ( ( distance - 2 ) & 0x40 ) >> 6; 		// Reasonable pipe segments. &0x20>>5 also works. 
//				outbyte += ( angle - 64 - 8 ) >> 4; 	// Can I do dark top / light bottom, as a bidirectional gradient? Punt. 
//				outbyte = ( angle >> 4 ); 		// 16 shades (1) obviously isn't fake polygons and (2) isn't aligned to +17. 
					// Or I guess it is exactly as aligned, but previously, we wanted the midpoint in the center of 1/8th. 

//				outbyte = distance >> 3; 		// Debug: plain rings for clear distance. 

				// Get some cheap division into six slices. Doesn't need to be perfect. 
				// Use a table. Duh. 
				outbyte = tube_color[ angle ]; 
//				outbyte += distance >> 4;  		// Ooh, that's a nice spiral. 
					// Even Manhattan-distance deformation look pretty nice with this. 

				// Distance rings. 
				// Soft rings, now that we have smoother shades and faux anti-aliasing. 
				// Eventuall mix up splits-and-struts versus rings-and-path. 
					// Maybe also classic checkerboard. Cosmetic variety. 
				if( ( distance & 0b110000 ) == 0 ) { 		// 0b10000 is much thicker. 0b110000, so they're further apart?
//					outbyte += 2; 
//					if( angle > 128+21 && angle < 256 - 21  ) { 		// Hex, end short of midpoint
						outbyte -= ( distance & 0b00001111 ) >> 2; 		// Oh that's nice. 
//					}
				}

				// Omnipresent bottom path. 
				// 270-ish degrees, so 192-ish.
				// Maybe only near distance rings / distance struts? Gaps near the middle of each pipe segment. 
				// Arguably unnecessary if we have more consistent shading. 
				// Make this staccato. 
//				if( angle > 192-8 && angle < 192+7 && distance & 0x08 ) { outbyte = 2; } 
					// Honestly that's okay, but the undersampling is terrible when you're dead-center. 
					// A wider table would probably work. 
				// Diagonals? 
				const uint8_t diagonal = angle - 4*43; 
//				if( diagonal < 43 ) { outbyte += ( angle + distance ) & 0x20 ? 0 : 1; } 
//				if( ( angle - 4*43 ) < 43 ) { outbyte += ( angle + distance ) & 0x20 ? 0 : 1; }
					// Why the fuck does this do... whatever the fuck it's doing? Almost no effect, except very rarely. Why. 
					// ( angle - (4*43) ) < 43 ) is somehow not the same thing as diagonal = angle - 4*43, diagonal < 43. 
				if( diagonal < 43 ) { outbyte += distance & 0b1100 ? 0 : 1; } 

//				outbyte %= 8; 
				outbyte &= 0x0F; 		// 16 shades (at present)
//				if( outbyte > 0x0F ) { outbyte = 0x0F; } 		// Saturate. More expensive, but safer. 
					// This turns everything white, implying our initial numbers are higher than intended. 
				outbyte |= 0x80; 		// ... placed halfway up the tile list. 

				// Gonna bet set_vram_byte is very safe and therefore dog-slow. (Yep.)
				// With more going on, I'm not sure this has a meaningful impact performance. 
				set_vram_byte( vram_pointer, outbyte );
				scroller_next_char++; 
				vram_pointer++; 

				// Direct writing is faster - e.g. 4.2 FPS vs 3.5 - but the line count is higher. What? 
//				*(vram_pointer++) = outbyte; 		// Still no. Super janky. 

			}
		}

		// Print framerate. Fine performance can be tracked by updating during hblank routine, if needed / applicable. 
		// printf is useless because you can't point it at the right place. 
		// Numeral sprites start at 16. 
		const uint16_t this_frame = line_count; 
		line_count = 0; 
//		running_average += this_frame; 
//		running_average /= 2; 
		running_average = ( running_average << 3 ) - running_average + this_frame; 
		running_average = running_average >> 3; 

//		const uint8_t fps = 60 * running_average / 144;
//		const uint8_t fps = 144 * 60 / this_frame; 
		// Always the basics. I want: frames per second. I have: how many scanlines this frame took. 
		// So time / frames, yeah? But that result looks backwards, given the initial value of running_average. 
		// And it's, like... this_frame = 144 should be 60 Hz. 
		// Yeah, 60 * this_frame / 144 -should- be correct. 
		// 60 / 17, yeah, 4-ish FPS. Our performance just plain sucks. 
		// Except I'm getting sensible results while doing nothing to correct the fixed-point display. 
		// TL;DR this is almost certainly wrong. 

		// FPS is frame count over time. 
		// Our frame count is 1.
		// Time is some number of scanlines. 
		// this_frame == 144 would be 60 Hz. 
		// this_frame = 288 would be 30 Hz.
		// So yeah, 60 * 144 / n = 60, for n = 144, and 60 * 144 / n = 30, for n = 288. 
		// So 60 * 144 / this_frame. 
		// Ah, but we're getting like... 3. So it's showing up as 00.3. 
		// But we overflow if we do 10*60*144 in uint16_t. 
		// GBDK does not appear to support uint32_t. 
		// Good lord, do I have to do long division manually here? 
		// Fuck it, just divide this_frame by 10. 
		// Y'know I could just show line count. Or both, both would work. 

		const uint16_t fps = ( 60 * 144 ) / ( running_average / 10 ); 

		vram_pointer = get_win_xy_addr( 0, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 10) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  14 ); 		// Decimal point. 
		set_vram_byte( ( vram_pointer++ ),  ( (fps ) % 10 ) + 16 );

		// Display raw line_count as well, because why not. 
		vram_pointer = get_win_xy_addr( 6, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (curve_x / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (curve_x / 10) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (curve_x ) % 10 ) + 16 );

		// We don't want to wait unless we're hitting 60 Hz, which, no. 
//		wait_vbl_done();	
	}
}













