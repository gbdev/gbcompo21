#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>		// For e.g. abs()
//#include <types.h> 	// For e.g. fixed? galaxy.c doesn't use this. WTF. 

#include <gb/bgb_emu.h>

#include "tunnel_tables.h" 
#include "Export.c" 		// Game Boy Tile Designer output 
#include "Diagonals.c"

// Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 


//	set_sprite_prop( 0, 0x00 );
	// https://gbdk-2020.github.io/gbdk-2020/docs/api/gb_8h.html#a99ea3252469e3614e977cce2aa1d06f7
	// Sprite property bits. 7: priority, 0 is behind BG. 6: vertical flip. 5: horizontal flip. 4: DMG OBJ palette 0/1. 
		// 3: GBC sprite bank. 2/1/0: GBC palette. 
//	set_sprite_tile( 0, 132 ); 		// Sprite number 0 to 39, CHR-RAM tile number 0 to... 256? GBDK might fudge it to 128. 
		// No, I strongly suspect GBDK accurately reflects the hardware and makes sprite tile 0 = BG tile 128. (Yep.)
		// So I should probably re-aim set_sprite_data. (Did.)
		// Oh why the fuck is it warning about overflow for 128+3? Is it signed? 
		// No - just more stupidity with macros. The actual value is fine. 
//	move_sprite( 0, 160/2, 144/2);






uint8_t scroller_x = 0; 		// This accidentally became our player / camera position variable. 
	// It should maybe be 16-bit and it should definitely be "z" instead. 
uint8_t old_scroller_x = 0; 		// Previous value before incrementing, to trigger on overflow
uint8_t region_x = 0; 		// Incremented when scroller_x overflows. Should still maybe be 16-bit?
	// Renamed to reduce confusion with tube segments. 

uint8_t* vram_pointer; 



// Rendering stuff
uint8_t outbyte, angle, screen_distance, distance, input; 		// Rendering scratch variables 
uint8_t scx, scy; 		// Vertical sync / vsync buffers for SCX/SCY_REG
//uint8_t row_buffer[32]; 		// Intermediate main-RAM holdover for grouped VRAM writes. 
OAM_item_t sprite_array[ 64 ]; 		// Oversized sprite array, so we can be lazy about memory safety

// Tube stuff
//int8_t gravity; 		// Physics scratch 
int8_t rotation = 0; 		// Game state - initially 11 for testing
int8_t rotation_impulse = 10; 		// Input accumulator
int8_t velocity = 0; 		// Necessary for momentum
uint8_t tube_color[256]; 		// Might make this multi-dimensional. 
//uint8_t tube_multicolor[8][256]; 
uint8_t* this_tube; 
	// E.g. tube_color[2][256] for alternating patterns, 
		// or straight-up using this to encode our level designs. 
	// Some map could be sections 0, 0, 0, 7, 3, and that'd be normal shit followed by cutouts or whatever. 
// Eventually need centripital force variable. Though curve info may suffice. (If all tracks are level.) 
uint8_t controls_locked; 		// Boolean. Over-the-top lock. 
int8_t twist_factor; 		// Adjust sampled rotation based on distance. 
int8_t twist_degree; 		// The actual number to shift by.
	// This is game state because it's not used directly for rendering.
	// twist=distance>>0 is extreme, >>4 is nothing. 
	// And we have to do rotation +/- this distance factor. 

// Tube segment color (and possibly finer lighting) 
/*
int8_t ramp[] = { 0, 1, 2, 3, 2, 1, 0, -1 };
int8_t bright[] = { -1, -1, -1, -1, 0, 1, 3, 1 };  		// Oh right, subtraction. This is nearly fullbright. 
int8_t dark[] = { 3, 3, 3, 3, 2, 0, -1, 0 }; 		// Not pitch-black, because of facet colors. 
*/
//int8_t ramp[] = { 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 1, 1, 0, 0, -1, -1 };
int8_t ramp[] = { 0, 1, 2, 3, 2, 1, 0, -1 };
int8_t bright[] = { -1, -1, -1, -1, 0, 1, 3, 1 };  		// Oh right, subtraction. This is nearly fullbright. 
int8_t dark[] = { 3, 3, 3, 3, 2, 0, -1, 0 }; 		// Not pitch-black, because of facet colors. 
int8_t* segment_color = ramp; 

//int8_t segment_lighting[] = { 1, 4, 8, 16, 3, 2, 1, 1, }; 
int8_t segment_lighting[] = { 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 2, 1, 1 }; 		// 32 elements 

uint8_t health = 255; 		
uint8_t boost = 127; 		
int8_t you_died = 0; 

int8_t spoiler_already_on = 0; 
int8_t currently_boosting = 0; 

int8_t paused = 0; 



// Globals shifted from main() so I can use control-flow functions
	int8_t pan_x = 0; 		// Debug - nope, now a nudge value for collision effect
	int8_t pan_y = 0; 

	uint8_t speed_accumulator = 0; 
	uint8_t move_speed = 10; 		

	// Jank first-whack track bend variable. 
	int8_t curve_state = 0; 		// Desired twist_factor to adjust toward. 
	int8_t curve_twist_counter = 5; 		// Physics frames (60 Hz-ish) between changes to twist_factor. 

	// Centripital frame of reference, temporarily added / subtracted from rotation. 
	int8_t tilt = 0; 

	// Debug: default obstacle function(s). 
//	*fill_function[0] = &generic_debris; 




// Graphics setup 
// Default ship sprites: 0, 2, 8, A. 
// Damaged ship sprites: 4, 6, C, E. 
// Oh my god these are in a stupid order. 
unsigned char normal_ship[2][4] = { { 0, 2, 2, 0 }, { 0xA, 8, 8, 0xA } }; 		// Only difference is engine flare "animation"
unsigned char player_ship[2][4] = { { 0, 2, 2, 0 }, { 0xA, 8, 8, 0xA } }; 
	// DRY violation because "cannot assign values to arrays."
unsigned char damaged_ship[2][4] = { { 4, 6, 0xC, 0xE }, { 4, 6, 0xC, 0xE } }; 
unsigned char exploded_ship[2][4] = { { 0x10, 0x12, 0x13, 0x14 }, { 0x12, 0x13, 0x14, 0x10 } }; 		// Garbage stand-in 

const int8_t ship_bob[2][8] = { { 1, 1, 1, 0, -1, -1, -1, 0 }, { 1, 1, 0, 1, 1, 0, 0, 0 } }; 




// Level data
#define LEVEL_COUNT 10

//#define CURVE_MASK 0b11000000
#define CURVE_LEFT 0b10000000
#define CURVE_RIGHT 0b01000000
//uint8_t level = 0; 
//const uint8_t* regions[ 10 ]; 		// Will I have this many levels? Probably fucking not, but this costs nothing. 
//const uint8_t level_zero[] = { 0, CURVE_LEFT, 0, CURVE_LEFT, 0, CURVE_RIGHT, CURVE_LEFT }; 

typedef struct region_s {
	uint8_t curve; 			// Only -4..4, so this can easily become a special signal flag. 
		// Oh god, or I could mark length in some of the free bits. Short little whippy curves or long-ass segments. 
	uint8_t thing_a; 		// 2-bit density + 6-bit facet mask
	uint8_t thing_b; 
	uint8_t thing_c; 
//	uint8_t thing_d; 
} region_t; 

const region_t* regions[ LEVEL_COUNT ]; 		// Pointers to levels, defined as an array of region_t segments

uint8_t ob_density[4];
uint8_t ob_facets[4];

// Keep this because I want moving bombs or whatever. 
uint8_t level_obstacle_types[ LEVEL_COUNT ][ 4 ] = { 
	{ 0, 0, 0, 0 },  		// Ordinal 1 - dummy level
	{ 0x81, 0x84, 0, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 

	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
	{ 0x81, 0x84, 0x82, 0 }, 
}; 

const int8_t curve_to_twist[ 16 ] = { -4, -3, -2, -1, 0, 1, 2, 3, 4 }; 
#define CURVE_MASK 0x0F
/*
#define HARD_LEFT 0x01
#define LEFT 0x02
#define STRAIGHT 0x04
#define RIGHT 0x06
#define HARD_RIGHT 0x08
*/

// Fuck it, hard turns only. 
#define HARD_LEFT 0x01
#define LEFT 0x01
#define STRAIGHT 0x04
#define RIGHT 0x08
#define HARD_RIGHT 0x08


/*
// Could just take the top four bits and multiply them upward, but I'm not sure if I need more flag bits. 
// Eh - leave the top bit as a flag. Any extra info will go in the four "thing" bits. 
#define LENGTH_MASK 0b00110000
#define SHORT 0b00000000
#define MEDIUM 0b00010000
#define LONG 0b00100000
// So uint8_t curve is e.g. SHORT + HARD_LEFT
*/

#define DISTANCE_MASK 0b01110000
// And just shift-and-multiply from 0..8 to 16..256 or something
#define SHORT 0b00010000
#define MEDIUM 0b00110000
#define LONG 0b01110000

//const int8_t prevalence_to_density[4] = { 0xFF, 0x1F, 0x0F, 0x07 };
//const int8_t prevalence_to_density[4] = {  0x3F, 0x1F, 0x0F, 0x07 };
//const int8_t prevalence_to_density[4] = { 0x07, 0x0F, 0x1F, 0x3F }; 
	// 0x07? 0xFF? 
//const int8_t prevalence_to_density[4] = { 0x1F, 0x07, 0x03, 0x01 };
const int8_t prevalence_to_density[4] = { 0x1F, 0x0F, 0x07, 0x07 };
#define SPARSE 0b00
#define LIGHT 0b01
#define MIDDLING 0b10
#define DENSE 0b11
// Facets are easy to bitmask, so uint8_t thing_a is e.g. DENSE + 0b000101
#define FACET_MASK 0b11111100
#define TOP 0b11100000
#define BOTTOM 0b00011100
#define EVERYWHERE 0b11111100
#define PREVALENCE_MASK 0b00000011
const region_t level_one[] = {
	{ STRAIGHT + LONG, 0, SPARSE + BOTTOM, 0 }, 
	{ STRAIGHT + LONG, 0, DENSE + BOTTOM, 0 }, 
	{ HARD_RIGHT + LONG, 0, MIDDLING + BOTTOM, 0 }, 
	{ STRAIGHT + LONG, 0, MIDDLING + BOTTOM, 0 }, 
	{ HARD_LEFT + LONG, 0, 0, 0 }, 
	{ STRAIGHT + LONG, LIGHT + BOTTOM, 0, 0 }, 
	{ STRAIGHT + LONG, 0, 0, 0 }, 
	{ STRAIGHT + LONG, LIGHT + BOTTOM, 0, 0 }, 
	{ STRAIGHT + LONG, MIDDLING + BOTTOM, LIGHT + EVERYWHERE, 0 }, 
	{ STRAIGHT + LONG, 0, LIGHT + EVERYWHERE, 0 }, 
	{ STRAIGHT + LONG, LIGHT + BOTTOM, 0, 0 }, 
	{ STRAIGHT + LONG, MIDDLING + BOTTOM, 0, 0 }, 
	{ STRAIGHT + LONG, DENSE + BOTTOM, 0, 0 }, 
	{ HARD_RIGHT + LONG, 0, MIDDLING + BOTTOM, 0 }, 
	{ STRAIGHT + LONG, 0, MIDDLING + BOTTOM, 0 }, 
	{ HARD_LEFT + LONG, MIDDLING + BOTTOM, 0, 0 }, 
	{ HARD_RIGHT + LONG, MIDDLING + BOTTOM, 0, 0 }, 
	{ STRAIGHT + LONG, MIDDLING + BOTTOM, MIDDLING + TOP, 0 }, 
	{ HARD_LEFT + LONG, MIDDLING + BOTTOM, 0, 0 }, 
};


const region_t level_two[] = {
	{ STRAIGHT + LONG, DENSE + 0b000101, 0, 0 } 
};


// sizeof is fucking with me, so clunk clunk get it done, here is a list of level lengths: 
const uint8_t level_lengths[] = { 
	0, 19, 20, 20, 20, 
	20, 20, 20, 20, 20
}; 




// Forward movement
uint8_t accelerator = 0; 		// Fixed-point 5.3 version of move_speed. 
uint8_t max_speed = 112; 		// move_speed 14

// Cutouts 
uint8_t cutoff_distance; 

// Obstacles
#define MAX_OBSTACLES 255
// Distances should maybe be 16-bit? Or fixed-point, if I can get GBDK to play nice with fixed-point. 

// Note horrifying C syntax: this is typedef obstacle_t, equal to struct obstacle_s. 
// Doing this instead causes spikes in the apparent framerate... but not visible performance differences. 
// Nope, it's something else. God dammit. What have I done recently? 
	// Random array wasn't const. 
typedef struct obstacle_s { 
	uint8_t type; 		// 0 for nothing, other values for enemies, barriers, etc. 
//	uint8_t location; 		// Distance, basically. Not an ideal name. 
	int8_t orientation; 		// Rotation. Objective placement around the pipe. 
} obstacle_t;
obstacle_t obstacles[ 64 ]; 


uint8_t hit = 0; 		// Collision indicator, i-frame timer
uint8_t hit_shake = 0; 		// Framerate-dependent screen shake 
uint8_t severity = 0; 		// Strength of collision - damage dealt 

// FPS stuff
uint16_t line_count = 0; 		// This frame 
uint16_t running_average = 1024; 		// Over time - nonzero initial value
uint16_t field_count = 1; 		// Number of whole frames to hand-wave, for variable framerate
uint16_t field_overflow = 0; 		// Leftover scanlines, to roll over into whole frames 

// Random numbers come from a fixed table. Straight-up ripping off Doom for this one. 
uint8_t random_index = 0; 		// Could have more than one index, for determinism. 

// Debug stuff?
uint8_t obstacles_on = 0xFF; 
uint8_t side;		// Shouldn't be global, but needed for debug




/*
// Sound stuff
// (At the top only because I'm doing it late)
// https://gbdev.io/pandocs/Sound_Controller.html
// Noise channel as "sound length" and I'm not sure what that does. 
// "Sample" in this sense means a note. 
// Oh goddammit. Putting this at the top makes sprites fail to appear. 
	// That speaks to a deep and complicated memory safety that I am super not dealing with. 
typedef struct sample_s { 
	uint8_t sweep; 		// Tone sweep - e.g. FF10 - NR10 CH1 
	uint8_t envelope; 		// Volume sweep - e.g. FF12 - NR12 CH1
//	uint8_t duty; 		// Don't care. 
	uint16_t frequency; 		// Frequency is 11 bits, and the independent whole byte is the lower bits. FFS. 
		// May replace this with a janked-up fixed-point deal in order to access the bytes individually. 
		// But I'm more likely to mask off the top six bits and thro wit into FF13/14 - NR13/14. 
} sample_t; 

sample_t audio_buffer[4][64]; 	// 4 channels, 64 samples each
	// [channels][samples] to simplify sound effects that only use one channel. 

uint8_t audio_index = 0; 		// Which sample plays next
*/






// tunnel_tables.h data used to be here. 



// Interrupt functions

uint8_t sy = 0; 

// Input buffer(s) & book-keeping 
uint8_t joy_buffer[ 32 ]; 		// Two 15-frame buffers. Elements 0 and 16 are length counters. 
uint8_t jb_offset = 0; 		// 0 or 16. (Or I guess 1 or 17.) 
uint8_t last_input = 0; 		// Guess I only need one length counter, since field_count will match. Tolerable jank. 

void hud_isr() { 
	HIDE_SPRITES; 

	// May also get a musical stinger in. 
	// Basically we have a 1ms gap "for free" before the next vblank. 
	// Hopefully this lets us do little clicky sounds distinct from the otherwise-steady 60 Hz changes. 
//	play_next_samples(); 
		// Wherein we load audio_buffer[ 0..3 ][ audio_index ] to appropriate buffers, 
			// clearing each buffer value as we go, 
			// then increment audio_index. 
} 

void my_vblank_isr() { 
//	LYC_REG = 1; 
//	SCY_REG = 0; 		// Stop doing this if we're not fucking with tilemap compression. 
//	SCX_REG = -16; 
//	sy = 1; 

	// Vsync frame swap, if applicable:
	// SCX_REG = scx; 
	// SCY_REG = scy; 
	// Swap BG0 / BG1 for the main tilemap. (Window is always BG1.) 

	// Enable sprites, since we turn them off over the HUD. 
	SHOW_SPRITES; 

	line_count += 144; 		// FPS tracking. Not 154 because the scanline version doesn't count vblank. 
	line_count += 10; 		// Account for all scanlines. Probably. Might be missing a few anyway. 

	// Take input from joypad(), add it to some input-buffer array, and increment array counter. 
	if( last_input < 16 ) { 
		joy_buffer[ jb_offset + last_input ] = joypad(); 
		last_input++; 
	} 

	field_count++; 		// Rolling-shutter gimmick - run physics once for every vblank. 

	// Audio handling, since we trigger this every 60th of a second.
	// If there's an end-of-vblank call then we might use that instead. vblank is useful for moving data. 
	// And variable-length execution of the vblank ISR means music tempo is unsteady. 
	// Sooo maybe I make hud_isr() flip-flop LYC_REG between the middle and bottom of the screen. 

}






// Helper functions 

// Place a single tile
// Globals as fake arguments for draw_tile 
//uint8_t x, y, xplus;
int8_t x, y, xplus;  
int8_t bend_x = 0; 
int8_t bend_y = 0; 
int16_t row; 		// y*32 to avoid repetition
int16_t lookup; 		// x+y*32, which I can increment instead of doing x++
void draw_tile();
void draw_tile_generic();
void draw_tile_positive();
void draw_tile_negative();
void draw_tile_cutoff();

// Place a row of tiles
int8_t ystart;
int8_t xstart;
int8_t ystop;
int8_t xstop;
int8_t rolling_row = 0; 
//void draw_row( int8_t row );
void draw_row();

// Print decimal digits to the HUD
void debug_output( uint8_t variable, uint8_t xpos, uint8_t ypos );
void display_number( uint8_t number, uint8_t x ); 
void draw_text( char* string, uint8_t x, uint8_t y );

// Set up and move one hardware sprite (pick tile, set properties, position object) 
void place_sprite( uint8_t object, uint8_t properties, uint8_t graphic, uint8_t x, uint8_t y ); 

// Simplified collision for a distance-locked array of obstacles
void object_collision_redux( int8_t k ); 

// Obstacle data -> hardware sprites
uint8_t ob_index; 
uint8_t obstacle_distance; 
int8_t free_sprite; 
int8_t center_x; 
int8_t center_y; 
int8_t render_rotation; 
int8_t reset_render_variables = 1;
void render_sprite( ); 

// Obstacle-generating function(s). 
void place_obstacle( uint8_t type, uint8_t index, uint8_t density, uint8_t facet_mask ); 		// Multipurpose 
void generic_debris( uint8_t index );
void nothing( uint8_t index ) { } 		// Adds no obstacles. 
void bomb_obstacles( uint8_t index ); 
void side_pickups( uint8_t index ); 

// Array for obstacle-generating functions. 
//void (*fill_function)(uint8_t)[4];// = { &generic_debris, &nothing, &nothing, &nothing }; 
// Okay, the syntax for a function pointer array is some bullshit, 
	// so just have fill_function_a, fill_function_b, etc. 
// This is likely to get whacked down to just two functions. 
void (*fill_function_a)(uint8_t) = &generic_debris; 
void (*fill_function_b)(uint8_t) = &bomb_obstacles; 
void (*fill_function_c)(uint8_t) = &side_pickups; 
void (*fill_function_d)(uint8_t) = &nothing; 

// Masks for placing each thing within a level
//uint8_t prevalence_a, prevalence_b, prevalence_c, prevalence_d; 
//uint8_t facets_a, facets_b, facets_c, facets_d; 

/*
void level_obstacles( int8_t level ) { 
	switch( level ) { 
		default: 
			fill_function_a = &generic_debris; 
			fill_function_b = &bomb_obstacles; 
			fill_function_c = &side_pickups; 
			fill_function_d = &nothing; 
		break; 

		case 1: 
			fill_function_a = &generic_debris; 
			fill_function_b = &side_pickups; 
			fill_function_c = &nothing; 
			fill_function_d = &nothing; 
		break; 

		case 2:
			fill_function_a = &generic_debris; 
			fill_function_b = &side_pickups; 
			fill_function_c = &bomb_obstacles; 
			fill_function_d = &nothing; 
		break; 

		case 3:
			fill_function_a = &generic_debris; 
			fill_function_b = &bomb_obstacles; 
			fill_function_c = &nothing; 
			fill_function_d = &nothing;  
		break; 

		case 4:
			fill_function_a = &generic_debris; 
			fill_function_b = &generic_debris; 
			fill_function_c = &generic_debris; 
			fill_function_d = &nothing; 
		break; 

		case 5:
			fill_function_a = &bomb_obstacles; 
			fill_function_b = &bomb_obstacles; 
			fill_function_c = &bomb_obstacles; 
			fill_function_d = &nothing; 
		break; 
	} 
} 
*/


// Sound functions
void play_sound( uint8_t which ); 


// Manage player state
void damage( int8_t amount, int8_t direction ); 








const uint8_t rotation_to_side[ 32 ] = { 
	// Shift:
//	0, 0, 0, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 1, 1, 1, 		// 0..15 - 3-5-5-3
//	1, 1, 1, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 0, 0, 0			// -16..-1, two's complement

	// Divide and subtract: 
	1, 1, 1, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 0, 0, 0,			// -16..-1, two's complement
	0, 0, 0, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 1, 1, 1 		// 0..15 - 3-5-5-3
};
/*
const int8_t side_gravity[ 12 ] = { 
	0, 0, -4, 4, -24, 24, 		// Bottom, top, lower right, lower left, upper right, upper left. 
	0, 0, 0, 0, 0, 0		// No gravity when pressing B. 
};
*/
const int8_t side_gravity[] = { 
		// High speed
	0, 17, -4, 4, -24, 24, 		// Bottom, top, lower right, lower left, upper right, upper left. 
	0, 0, 0, 0, 0, 0,		// No gravity when pressing B. 
		// Low speed 
	0, 17, -4, 4, -24, 24, 
	0, 17, -1, 1, -17, 17, 		// Downforce less effective at low speed. Shove player off the top. 
};
/*
const int8_t side_friction[ 12 ] = {
	// Bottom, top, lower right, lower left, upper right, upper left. 
	2, 0, 2, 2, 2, 2, 		// No friction on top
	4, 0, 4, 4, 2, 2 			// B doubles friction along the bottom
};
*/
const int8_t side_friction[ ] = {
	// Bottom, top, lower right, lower left, upper right, upper left. 
		// High speed
	2, 0, 2, 2, 2, 2, 		// No friction on top
	4, 0, 4, 4, 2, 2, 			// B doubles friction along the bottom
		// Low speed
	2, 0, 2, 2, 2, 2, 		// No friction on top
	3, 0, 3, 2, 2, 2, 		// Less downforce at low speeds
		// Could be identical at any speed, honestly, but this table should match the size of side_gravity. 
};


// Twist functions
uint8_t angle_straight( uint8_t distance_sample ) { return angle_table[ lookup++ ] + render_rotation; } 

uint8_t angle_positive( uint8_t distance_sample ) { 
	return angle_table[ lookup++ ] + render_rotation + ( distance_sample >> twist_degree ); 
}

uint8_t angle_negative( uint8_t distance_sample ) { 
	return angle_table[ lookup++ ] + render_rotation - ( distance_sample >> twist_degree ); 
}

uint8_t (*angle_function)(uint8_t) = &angle_straight; 













// Control flow stuff
int8_t game_over = 0; 	
int8_t next_level = 1; 		// 1-ordinal because fuck you
uint16_t score = 0; 		// Pffft
uint16_t timer = 0; 		// Why not 

void main_menu(); 		// "Press Start"
void attract_screen(); 	// Idle demo 
void enter_level(); 		// Cutscene - optional 
void play_level(); 		// Actual gameplay 
void show_stats(); 	// Text over frozen screenshot


// Dummies
//void main_menu() {}
void attract_screen() {}
//void enter_level() {}
//void play_level() {}
//void show_stats() {}





// Main functionality 

void main() {


	// ---------- Pre-game setup ----------

//	printf( "Loading..." ); // Need a printf for GBDK to include text characters. 
	printf( " " ); 		// Prime the pump. 
	printf( "\n\n\n\n\n\n      STUNNER" );
	printf( "\n\n\n\n\n   Mindbleach Ltd" );
	printf( "\n      (C) 1991" ); 

	// Load tile data to CHR-RAM
//	set_bkg_data(0x00, 0x08, gradient_data);
	set_bkg_data( 0x60, 0x08, gradient_data );
	set_bkg_data(128, 128, gradient_data); 		// Overlaps with sprite data. 


	// Sprite data 
	// 40 hardware sprites. 10 per line. Worth remembering. 
	set_sprite_data( 128, 128, gradient_data ); 		// [ BG tiles { BG & Sprite tiles ] Sprite tiles } - so sprite's 0 = BG's 128. 

	set_sprite_data( 0, 128, gbtd_tiles );

//	set_bkg_data(128, 32, Diagonals); 


	// Set up palettes. 
	// BG can be boring. 
	// Sprites should be white-grey-black and then black-grey-white, for 1.0. Clunk clunk get it done. 
	// REG_BGP = DMG_PALETTE(DMG_BLACK, DMG_DARK_GRAY, DMG_LITE_GRAY, DMG_WHITE);
	// FF47_REG = 0xFF; 		// Nope. 
//	BGP_REG = 0xFF; 
//	OBP0_REG = DMG_PALETTE( DMG_BLACK, DMG_LITE_GRAY, DMG_WHITE, DMG_WHITE ); 
	// Also DMG_PALETTE doesn't work because go fuck yourself. 
//	OBP0_REG = 0b11010000; 		// Black, light, white, dontcare. 
//	OBP1_REG = 0b00101100; 		// White, dark, black, dontcare. 
	OBP0_REG = 0b11100000; 		// Black, light, white, dontcare. 
	OBP1_REG = 0b00011100; 		// White, dark, black, dontcare. 
	

	// 64-sprite array for 40 sprites, so we can go over by a fair amount and not clobber nearby memory. 
	// The alternative is losing potentially 15 sprites by checking free_sprite<40-16 before drawing another obstacle. 
	// This does not, as such, work. Poo. 
	SET_SHADOW_OAM_ADDRESS( &sprite_array ); 

	SHOW_SPRITES; 
	SPRITES_8x16; 		// We need this so 4x4 sprites take 8 slots instead of 16. 


	// Level data gets inserted into a pointer array to avoid some really hideous nested brace syntax. 
	regions[1] = level_one; 



	// Audio setup
	NR52_REG = 0x80; 		// Has to be first, because go fuck yourself. 

	NR50_REG = 0x77; 
	NR51_REG = 0xFF;
//	NR51_REG = 0xFFU; 
//	NR52_REG = 0x80U; 		// Enable audio 
//	NR50_REG = 0x77U; 		// Both ears to max volume 


	// Fill tube_color because division by six is weirdly expensive. 
	// "Anything that only happens once is free."
	// Oddly difficult to get a loop of 256. 
	// tube_color[] may remain variable so that we can fuck with it. 
		// Though we could just declare 'int8_t* tube' and point it at e.g. tube_type[8][256]. 
		// Probably better to just use two and amortize the next one while using this one. Do one entry per frame. 
//	const uint8_t sides[] = { 2, 0, 1, 2, 3, 4, 2, 0 }; 		// 8 instead of 6 because modulo is acting weird. 
//	const uint8_t sides[] = { 2, 3, 0, 2, 1, 4, 2, 3 }; 		
	const uint8_t sides[] = { 2, 1, 0, 2, 3, 4, 2, 1 }; 
	for( uint8_t n = 255; n > 0; n-- ) { 		// Divide into sixths. 
		const uint8_t side = n / 43 + 1; 	// To simplify dealing with non-uniform gradients. 
		tube_color[n] = sides[ side ]; 		// 0..5. 6*43 is 258. 

		// Faux subsampling? 0..5 x2 -> 0..10, and use an in-between color right near the boundary. 
		// "Anti-aliasing." Three colors per side, or just two? Three fits but may be overkill. 
		// Keep dead code for now; we're gonna mix things up during play. 
		tube_color[n] *= 2; 
//		if( n % 43 > 40 ) { tube_color[n]++; } 
//		if( n % 43 < 2 ) { tube_color[n]--; } 
		// Wow, that's nice. 
//		if( n % 43 > 40 ) { tube_color[n] += sides[ ( side + 1 ) % 6 ]; tube_color[n] /= 2; } 
//		if( n % 43 < 2 ) { tube_color[n] += sides[ ( side - 1 ) % 6 ]; tube_color[n] /= 2; } 
		if( n % 43 > 40 ) { 		// Why is anti-aliasing uneven? This is only 41, 42, but the other's only 0, 1. 
											// The bottom facet's diagonals are noticeably askew. 
											// ... maybe just because it's 4->2 instead of 3? Ehh, not really.  
			if( sides[ side + 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}
		else if( n % 43 < 2 ) { 
			if( sides[ side - 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}

		// Anti-aliasing should be swapped out almost entirely for diagonals. 
		// Not exactly fixed tile values, because of rotation, but: a bit flag and two-ish colors. 
		// Picking the right angled graphical tile from CHR-RAM is the drawing routine's problem. 

		// This setup loop should also handle most of the tube-color stuff. 
		// So e.g. add 3 to every thing for a fairly naive sawtooth gradient that looks about right. 
		// But ideally I'd like to make the bottom white(ish), the upper-right dark, 
			// and the lower-right about as dim as the upper-left. 
		tube_color[n] += 3; 

		tube_color[n] += 128; 		// Tiles in the middle. (Letters at the front.) 
			// I could use a bit to indicate boundaries.
			// Really I could use several, we're only encoding 16 shades so far. 
			// Masking is cheap and it'd let us substitute rotation-aware diagonals. 
	}
	// Then set tube_color[0] if it's not supposed to be black. 
	tube_color[0] = tube_color[1]; 		// Easy hack. 

/*
	// Mark diagonals where tube color changes. 
	for( uint8_t n = 0; n < 8; n++ ) { 
		for( uint16_t p = 0; p < 255; p++ ) { 
			tube_multicolor[ n ][ p ] = tube_color[ p ] - segment_color[ n ]; 
		} 
	} 
*/

/*
	// Multidimensional array instead of adding small values for tube segments? 
	for( uint16_t p = 0; p < 255; p++ ) { 
		if( tube_color[ p ] != tube_color[ (uint8_t) ( p + 1 ) ] ) { 
			tube_color[ p ] |= 0x40; 
			if( tube_color[ p+1 ] > tube_color[ p ] ) { 
				tube_color[ p ] |= 0x20; 
			}
		}
	}
*/ 

/*
	// Multiple arrays differing only by the hardcoded direction of diagonals. 
	for( uint8_t n = 0; n < 8; n++ ) { 
		for( uint16_t p = 0; p < 255; p++ ) { 
//			tube_multicolor[ n ][ p ] = tube_color[ p ] - segment_color[ n ]; 
			tube_multicolor[ n ][ p ] = tube_color[ p ]; 
			if( tube_color[ p ] != tube_color[ (uint8_t) ( p + 1 ) ] ) { 
				tube_multicolor[ n ][ p ] |= ( n << 4 ) & 0x7; 
			}
		} 
	} 
*/

/*
	// Alternate tube fill for multiplicative lighting. (And eventually, diagonals in post.) 
	// Sides go counterclockwise from upper-right:
//	const uint8_t sides[] = { 2, 1, 0, 2, 3, 4, 2, 1 }; 		// 8 instead of 6 because modulo is acting weird. Dark at the top.
	const uint8_t sides[] = { 1, 2, 0, 3, 2, 4, 1, 2 }; 		// Multiplicative lighting needs more facet contrast.  
	// 2 0 1
	// 3 4 2

	// 3 0 2
	// 2 4 1
	for( uint8_t n = 255; n > 0; n-- ) { 		// Divide into sixths. 
		const uint8_t side = n / 43 + 1; 	// To simplify dealing with non-uniform gradients. 
		tube_color[n] = sides[ side ]; 		// 0..5. 6*43 is 258. 

		tube_color[n] *= 3; 		// Can't quite *= 4 because we're going 0..4 -> 0..15. 
		tube_color[n] += 3; 		// Up from black a bit, so 0 stays special. 

	}
	tube_color[0] = tube_color[1]; 		// Easy hack for 0..255 issues. 
*/

	// Compression to 4-scanline-high tiles has tolerable performance impact. 
	// It's rendering all those tiles that kills us. 
	// We might go for diagonal tiles and skip scanline shenanigans altogether. 
	// In which case: we do still need VBL_IFLAG. (Or is that just for wait_vbl_done?) 
	// VBL is back so we can disable sprites over the HUD. 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
		LYC_REG = 144 - 16 + 8; 		// HUD
//		add_LCD( half_tile_isr );
		add_LCD( hud_isr );
		add_VBL( my_vblank_isr ); 		// Two hard problems. 
		set_interrupts( VBL_IFLAG | LCD_IFLAG );
//		set_interrupts( VBL_IFLAG );
	}

	// FPS / HUD - using window 
//	init_win( 6 ); 
	init_win( 0x64 ); 		// Darken HUD to solid color / generic dither 
//	move_win( 7, 128 ); 		// Coordinates start one tile/sprite offscreen. (144-16) throws a warning. Shrug.
	move_win( 7, 136 ); 		// Coordinates start one tile/sprite offscreen. (144-16) throws a warning. Shrug.  
	SHOW_WIN; 		// Equivalent to LCDC_REG|=0x20U 

	// Initial game state
	// Distance-based changes to the tube, indicating curves. 
	twist_factor = 0; 		// -4..4 or thereabouts. 
//	twist_degree = 1; 		// Basically 4 - abs( twist_factor ), whose sign chooses between rotation+= or -=. 


	// ---------- Control flow ----------



	while(1) {
		// Skip menu while fucking with gameplay loop 
		main_menu(); 		// Also call at top of main()? Show something cool during loading / setup. 
			// Menu is just a large-print logo reading "STUNNER" and some depiction of the tube and/or car. 
			// Only options will be start / continue, or else a level select. 
			// Difficulty would be era-appropriate, but consider: meh. 
//		attract_screen(); 	// If game_over==0, this will show some random level / crappy input. 
			// May get called by main_menu instead. (Yep.) 
		while( ! game_over ) { 		// Cycle through levels unless you -really- fuck up. 
			enter_level(); 	// Some cool little drive-up cutscene, time allowing
			play_level(); 		// Side effects on exit increment level if you didn't die. 
			show_stats(); 		// Inter-level time, score, whatever
		} 
	}

}





// ---------- Main menu ---------- 

void main_menu() {
	HIDE_WIN; 		// No HUD

	// Show main screen artwork - be fancy, if possible. 
	printf( "\n\n\n    Press Start" ); 		// Debug 

	uint8_t timer = 0; 
	while( ! ( joypad() & J_START ) ) { 		// Wait until player presses start
		if( field_count > 60 ) { 
			timer++; 
			field_count = 0; 		// User global frame counter to count seconds. 
		} 
		wait_vbl_done();  		// May as well idle. 
//		if( timer > 10 ) { break; } 		// After waiting, exit menu, go to attract_screen.
		if( timer > 10 ) {  		// After waiting a bit, play a demo. 
			timer = 0; 
			attract_screen(); 
//			printf( "\nAttract screen dummy" ); 		// Debug
		}
	} 

	// Play a little fade-out animation, then exit menu 
}






// --------- Start-of-level cutscene, such as it is ---------
void enter_level() {
/*
	for( uint8_t n = 0; n < 18; n++ ) { 
		draw_row( ); 		// rolling_row increments as a side effect. 
	}
	// Move player ship up from the bottom 
*/
	// Woof, no. This takes a lot more setup than it ought to. 
}









// ---------- Gameplay loop ----------

// Uh, this doesn't loop on its own anymore. It really should. Do while(1) and break when you die. 
void play_level() { 

// Make it work - make it fast - make it pretty. In that order. 

/*
	// Display all tiles... again. 
	// Obviously only from 0..255, where sprites somehow also go from 128 to 255 in the same space? Okay, sure. 
	for( int y = 0; y < 16; y++ ) {
		vram_pointer = get_bkg_xy_addr( 0, y );
		for( int x = 0; x < 16; x++ ) { 
			set_vram_byte( vram_pointer++, x + y * 16 );
		}
	}
	continue; 
*/

	// Setup

	SHOW_WIN; 		// Display HUD
	SHOW_SPRITES; 		// Display player / obstacles

//	level_obstacles( next_level ); 		// Ordinal 1, just because. This function sets fill_function_a/b/c/d. 

	uint8_t* ob_types = level_obstacle_types[ next_level ]; 		// Which object types litter this level 

	region_x = 0; 

	const region_t* this_level = regions[ next_level ]; 		// Two hard problems. 

	cutoff_distance = 0; 		// No cutoff by default. 

	curve_state = 0; 
	twist_factor = 0; 

	rotation = 0; 

	const uint8_t level_end = level_lengths[ next_level ]; 

	accelerator = 0; 

	init_bkg( 0x64 ); 		// Not "init_bg" because go fuck yourself. 

	you_died = 0; 
	controls_locked = 0; 
	if( health < 128 ) { health = 128; } 
	if( boost < 128 ) { boost = 128; } 

	paused = 0; 



	// Actual loop for gameplay 

	while(1) { 		// Only exit with explicit break command. 

		// Fill in new obstacles behind the player, so we'll wrap around to them later. 
		// clear_and_fill( spot )? Useful for hitting more than one, as is apparently required, 
			// and using a function lets us swap in function pointers. 
		// Maybe clear here but fill inside the function(s). 
		const uint8_t passed_spot = ( scroller_x - 1 ) >> 2;
		const uint8_t passed_spot_plus_one = passed_spot + 1; 

		// This would be a loop over an array of function pointers, if those weren't hideously complicated. 
		// I'd unroll it anyway. 


		// Clear obstacles when passed. (Can't do it in place_obstacle, or they clobber one another.) 
		obstacles[ passed_spot ].type = 0; 
		obstacles[ passed_spot_plus_one ].type = 0; 

		place_obstacle( ob_types[ 0 ], passed_spot, ob_density[0], ob_facets[0] ); 
		place_obstacle( ob_types[ 1 ], passed_spot, ob_density[1], ob_facets[1] ); 
		place_obstacle( ob_types[ 2 ], passed_spot, ob_density[2], ob_facets[2] ); 
//		place_obstacle( ob_types[ 3 ], passed_spot, ob_density[3], ob_facets[3] ); 

		place_obstacle( ob_types[ 0 ], passed_spot_plus_one, ob_density[0], ob_facets[0] ); 
		place_obstacle( ob_types[ 1 ], passed_spot_plus_one, ob_density[1], ob_facets[1] ); 
		place_obstacle( ob_types[ 2 ], passed_spot_plus_one, ob_density[2], ob_facets[2] ); 
//		place_obstacle( ob_types[ 3 ], passed_spot_plus_one, ob_density[3], ob_facets[3] ); 


		// Input
		// joypad() reads get buffered by the vblank ISR. It's always 60 Hz even when rendering is crap. 
		// ... y'know, I could just do this IN the vblank ISR. It should be pretty quick. 
		// We only have one scanline interrupt and it's at the bottom. 
		// Downside of physics in ISR: might impact rendering mid-render. Mixed bag.
		const uint8_t jb_backbuffer = jb_offset; 		// Whoops, grab this first. 
		jb_offset ^= 16; 		// 32-element array, offset by half or zero. 
		last_input = 0; 		// Non-cleared variable-length buffer. (See vblank ISR.) 


		if( input & J_START ) { 
			// This is where pause functionality would go if I could do it without GBDK spitting in my face. 
			// I'm getting "unreachable code" errors off of shit like if(paused==0){} if(paused>20){}. 
			// That's pretty fucking reachable, "Evelyn." Heel. 
		} 

		// Sound effects directly from player inputs:
		if( ( input & J_B ) && ! spoiler_already_on ) { 		// When you start pushing B
			play_sound( 10 ); 
			spoiler_already_on = 1; 
		} else if( ! ( input & J_B ) && spoiler_already_on ) { 		// When you stop pushing B
			play_sound( 11 ); 
			spoiler_already_on = 0; 
		}

		if( ( input & J_A ) && ! currently_boosting && boost ) { 		// When you start pushing A (and have fuel) 
			play_sound( 14 ); 
			currently_boosting = 1; 
		} else if ( ! ( input & J_A ) && currently_boosting ) { 		// When you stop pushing A
			play_sound( 15 ); 
			currently_boosting = 0; 
		}

		if( currently_boosting && !boost ) { 		// Boost runs out 
			play_sound( 15 ); 
			currently_boosting = 0; 
		} 

		// Partial rendering 
		// Bleh. Can I just chunk the screen into thirds or whatever? 
		// Unrolled and inlined:
		draw_row( ); 		// rolling_row increments as a side effect. 
		draw_row( );
		draw_row( );

		draw_row( );
		draw_row( );
		draw_row( );

		if( rolling_row >= 18 ) { 
			rolling_row = 0; 
			reset_render_variables = 1; 		// So scroll_x / scroll_y only update between frames. 
		}

		// Controls & Physics
		int8_t round_count = field_count; 		// So we can zero out field_count. 
		field_count = 0;
		for( int8_t rounds = round_count; rounds > 0; rounds-- ) { 		// Rolling shutter. 
			// Rolling shutter / partial rendering makes this for-loop's head a little weird: 
				// we want to clear field_count once, immediately, 
				// so we don't clobber any vblanks that occur during physics. 

			// vblank routine buffers joypad inputs. Above 6 Hz they should never fill up. 
			// Double-buffering them still seems weird but felt sensible at the time. 
			uint8_t input = joy_buffer[ jb_backbuffer + round_count - rounds ]; 
			if( round_count - rounds > 16 ) { input = 0; } 		// Safety check: no spurious input data.  


			// Briefly prevent player input. 
			if( controls_locked ) { 
				controls_locked--; 
				input = 0; 

				if( you_died && ! controls_locked ) { return; } 		// Dead? After a brief wait: exit level, start over. 
			} 


			// Physics
			// Physics values have a fixed-point factor of 8. (I think. Honestly it's changed a few times.) 
			if( input & J_DOWN ) { 		// Fine adjustment when holding down.
				if( input & J_LEFT ) { rotation--; } 
				if( input & J_RIGHT ) { rotation++; } 
			} else { 
				// Accelerate left or right - less, when pressing B. 
				if( input & J_LEFT ) { 
					if( input & J_B ) { velocity -= 8; } else { velocity -= 16; } 
				} else if( input & J_RIGHT ) {
					if( input & J_B ) { velocity += 8; } else { velocity += 16; } 
				}
			}


			// Possibly have entirely separate physics for "smooth" sections, 
				// like the tube changes to a plain gradient and you can suddenly go over. Only there. 
			// Bottom section may otherwise have strong friction. (Eh.) 

			// I can label "sides" whichever values I want. 
			// New arbitrary "side" arrangement:
			//    1
			// 5     4
			// 3     2
			//    0

			// Change frame of reference before doing physics. 
			rotation += tilt; 

			uint8_t side = rotation_to_side[ ( ( rotation / 8 ) + 16 ) ];
	//			uint8_t side = rotation_to_side[ rotation >> 3 ];  
				// Shifting unsigned numbers is fucky even when you try to account for it. 

			// And then gravity / friction should be unconditional reads froma 6- or 12-element array. 
			if( input & J_B ) { side += 6; } 		// Change read area for friction / gravity. 
			// Use this to limit when you can go over-the-top based on speed. 
//			if( accelerator < 100 ) { side += 12; } 		// Different B physics at low speed
			if( accelerator < 120 ) { side += 12; } 		// Different B physics at low speed  
			
			velocity += side_gravity[ side ]; 

			#define MAX_VELOCITY 40
			if( velocity < -MAX_VELOCITY ) { velocity = -MAX_VELOCITY; } 
			else if( velocity > MAX_VELOCITY ) { velocity = MAX_VELOCITY; } 

			rotation += velocity / 16; 

			// Friction -after- movement, so no speed is too low to move. 
			// No friction when hit>0? Nah, opposite of intended effect: you go up walls and come right back down. 
				// Net position is often closer to center than you started! 
			if( velocity > 0 ) { 
				velocity -= side_friction[ side ]; 
				if( velocity < 0 ) { velocity = 0; } 
			} else { 
				velocity += side_friction[ side ]; 
				if( velocity > 0 ) { velocity = 0; } 
			} 

			// Undo rotation tilt from curve physics - pointedly -inside- the physics loop. 
				// Otherwise we'd apply tilt several times (sometimes while the curve changes) and then undo it once. 
			rotation -= tilt; 



			// Decrement i-frame countdown. Or just shake countdown if we have no i-frames. 
			// Goes here because otherwise it's conditional on speed_accumulator incrementing scroller_x. Which is goofy. 
			if( hit > 0 ) { 
				hit--;
			} 


			// Acceleration, forward speed:
			// Increase speed over time, up to some variable max_speed. 
			// Decrease speed if past that. 
			// Also done with a fixed-point intermediate variable, because move_speed is ridiculous past about 14. 
			// Move speed / max speed: 10 is 80, 14 is 112, 16 is 128. 
			// Having played more - move_speed 10 is a bit pokey. 

//			if( input & J_B ) { max_speed = 80; } else { max_speed = 112; } 		// 80 might be low.
			if( input & J_B ) { max_speed = 80; } else { max_speed = 144; } 		// 80 might be low.  
//			if( you_died ) { max_speed = 0; } 

			// Easy fix for too-fast recovery: don't accelerate while "hit." The screen shake effect is now a punishment. 
			if( !hit  ) { accelerator++; } 
			if( ( input & J_A ) && boost ) {  		// Boost. Presumably limited, in final game. 
				accelerator += 10; 
				boost--; 
			}

			// Slow to nothing when dead. 
			if( you_died ) { accelerator /= 2; } 

			// +=3 is reasonable. +=10 is ridiculous. So we're sticking with +=10. 
			#define ACCELERATOR_CAP 200 		// move_speed 25. 
			// Primary purpose of a hard cap is to avoid overflow, e.g. so boosts don't drop you to zero. 
			// I love that I can refer to this as "the nuclear Ghandi problem." 
			if( accelerator > max_speed ) { accelerator -= 2; } 
			if( accelerator > ACCELERATOR_CAP ) { accelerator = ACCELERATOR_CAP; } 
			move_speed = accelerator >> 3; 
				// Note: not >>4. We can go above 16, even if we really really shouldn't. 
				// Some of the obstacle handling assumes scroller_x will only change by 0 or 1. 




			// Proper fixed-point accumulator for scroller_x / tube position. 
			// This has worse performance because we run more rounds. 
			// Might move it further down so we can enact controls but skip physics (or at least collision) 
				// onrounds where we don't advance scroller_x. 
			// Or: 30 Hz controls. 

			speed_accumulator += move_speed; 
			if( speed_accumulator >> 4 == 0 ) { continue; } 		// Debug - disable this for manual motion. 
			old_scroller_x = scroller_x; 
			scroller_x += speed_accumulator >> 4; 		// Add integer portion. Should always be 0 or 1. Should. 
				// Accidentally works up to a lot more than 0 or 1. Dunno if collision handles that well. 
				// Anything more than 60 Hz would be really goddamn twitchy even at 60 FPS. 
			speed_accumulator &= 0x0F; 		// Only keep fractional portion. 



			// New region.
			// Level progress, more generally. 
			// Oh god it's going to be such a pain to get shorter sections. 
			if( scroller_x < old_scroller_x ) { 		// Detect when we've passed a 256-unit segment.
				region_x++; 

				// Change twist, cutouts, cutoff, etc. 
				// Level data, but simpler: we only have like three obstacle types. 
				// So: per-level hazards, random curves, random placement, random density? 
				// We'll only have three, MAYBE four fill functions. The only reason to maintain pointers is to shave cycles. 
				// (Call level_obstacles(0) before level_obstacles(next_level) to re-establish defaults.)

				const region_t* region = &this_level[ region_x ]; 
//				twist_factor = curve_to_twist[ this_level[ region_x ].curve & CURVE_MASK ]; 		// -4..4
				curve_state = curve_to_twist[  (region->curve) & CURVE_MASK ]; 		// -4..4
				ob_density[0] = prevalence_to_density[ (uint8_t) ( ( region->thing_a ) & PREVALENCE_MASK ) ]; 
				ob_density[1] = prevalence_to_density[ (uint8_t) ( ( region->thing_b ) & PREVALENCE_MASK ) ]; 
				ob_density[2] = prevalence_to_density[ (uint8_t) ( ( region->thing_c ) & PREVALENCE_MASK ) ]; 
//				ob_density[3] = prevalence_to_density[ (uint8_t) ( ( region->thing_d ) & PREVALENCE_MASK ) ]; 

				ob_facets[0] = ( ( region->thing_a ) & FACET_MASK ) >> 2; 
				ob_facets[1] = ( ( region->thing_b ) & FACET_MASK ) >> 2; 
				ob_facets[2] = ( ( region->thing_c ) & FACET_MASK ) >> 2; 
//				ob_facets[3] = ( ( region->thing_d ) & FACET_MASK ) >> 2; 

				// Level-end debug test:
				// Level end, level exit, end level, end of level, fuck's sake Ctrl+F 
				// Straight, nothing present, maybe slow to a stop? 
				if( region_x >= level_end ) { 
					ob_density[0] = 0; 
					ob_density[1] = 0; 
					ob_density[2] = 0; 
					ob_facets[0] = 0; 
					ob_facets[1] = 0; 
					ob_facets[2] = 0; 
					cutoff_distance = 128; 
					curve_state = 0; 
//					return; 
//					accelerator = 190; 		// Doesn't work right. 
				} 
			} 
			// May need to separately test for passing the cutoff, and switch current / 'next' values. 

			if( cutoff_distance && ( scroller_x > cutoff_distance ) ) {
				if( region_x > level_end ) { 
					next_level++; 
					return; 
				} 
			} 




			// ---------- Curves ---------- 




	 			// Debug - sit still, dammit 
			// Gradually align twist state to the curve we're supposed to be in. 
			// Speed of twist should be controlled by segment length and/or degree of curve. 
			if( twist_factor != curve_state ) { 
				curve_twist_counter--; 
				if( curve_twist_counter == 0 ) { 
					if( twist_factor < curve_state ) { twist_factor++; } 
					else { twist_factor--; } 		// No need to check equality. 
					curve_twist_counter = 5; 		// Arbitrary guess. 5 was decent, 15 sucks, 10... no strong opinion. 
						// Honestly the ideal is that I can make the curve start and stop at specific distances, 
							// so it's a real thing you approach and then exit. 
						// Approaching looks kinda terrible. Dangit. 
						// 15's not a terrible speed to change at, but it is very far from smooth. 
						// Suddenly being in a curve fits the early-90s vibe I'm going for, with this 32 KB ROM. 
						// This game's supposed date is 1992 at the latest. 
				} 

				// Frame of reference can only change when twist_factor changes. 
				// (Though we do modify rotation back and forth every frame.) 
				tilt = 16 * twist_factor; 
			} 




			// ---------- Collision ----------

				object_collision_redux( 0 ); 
				// hit-- no longer goes here - it should happen every frame, and not be conditional on scroller_x changing. 

		} 		// Physics / controls for-loop 





		// Debug inputs 
		input = joypad(); 		// Debug - buffered input no longer fills this old global variable. 
	//		if( input & J_UP ) { curve_x += 1; } 
	//		if( input & J_DOWN ) { curve_x -= 1; }
		// Manual curve-bend-twist effect: 
	//		if( input & J_UP ) { if( twist_factor < 4 ) { twist_factor += 1; } } 
	//		if( input & J_DOWN ) { if( twist_factor > -4 ) { twist_factor -= 1; } }  
		// Manual screen shift left / right: 
	//		if( input & J_B ) { pan_x += 5; } 
	//		if( input & J_A ) { pan_x -= 5; } 
		// Manual tunnel advance / reverse:
	//		if( input & J_B ) { scroller_x += 5; } 
	//		if( input & J_A ) { scroller_x -= 5; } 
		// Manual forward speed changes:
	//	if( input & J_UP ) { move_speed++; } 
	//	if( input & J_DOWN ) { if( move_speed > 0 ) { move_speed--; } }  
		// Manual position changes:
	//		hit = 0; move_speed = 0; 
	//		if( input & J_UP ) { scroller_x++; } 
	//		if( input & J_DOWN ) { scroller_x--; } 
	/*
		if( ( input & J_A ) && ( ( scroller_x & 0x07 ) == 0 ) ) { 		// Not better. 
			if( obstacles_on ) { obstacles_on = 0; } 
			else { obstacles_on = 1; } 
		}
		// Enable / disable obstacles, while I fuck with physics
		// Fucking hell, this needs debounce. Such a constant annoyance. 
	*/


		// Get >>twist_degree from twist_factor -4..4.
		// No need for conditions because this goes unused if twist_factor == 0. 
		twist_degree = 4 - abs( twist_factor ); 
		pan_x = 8 * -twist_factor; 		// Slide the screen to indicate inertial force. 

		hit_shake--; 		// Avoid conditional - underflow makes no difference. 
		if( hit ) {		// This belongs here. hit_shake is once-per-frame, and twist_factor clobbers pan_x. 
			pan_x += ( hit_shake & 0x02 ) * 2; 		// Oscillate between +/- 4... but this gets overwritten anyway. 
			pan_y = 3 * ( hit_shake & 0x01 ); 		// Oscillate between +/- 3
		}

		// Screen placement
		// Use fine hardware scrolling, you ding-dong. 
		const int8_t half_rotation = rotation / 2; 

		int8_t scroll_x = -half_rotation; 		// Much cleaner. 
		if( rotation > 64 ) { scroll_x = -64 + half_rotation; } 		// Past the horizon, reverse back toward 0. 
		else if( rotation < -64 ) { scroll_x = 64 + half_rotation; } 

		int8_t scroll_y = ( abs( half_rotation ) >> 2 );  		// Don't reverse Y when upside-down. 


		// Debug - no sliding around while dorking with curves:
	//	scroll_x = scroll_y = 0; 
		scroll_y += pan_y; 
		scroll_x += pan_x; 

		// The simple fix is to always render 32x18. That'll at least let us figure out if we're tracking sensibly. Perf later. 
		// Setting SCX/SCY_REG eventually has to go in the vblank interrupt, for when we do double-buffering and vsync. 
		uint8_t scx = scroll_x + 8*((32-20)/2); 		// Okay, sure. 8x for bytes, not bits. 
		uint8_t scy = scroll_y + 8*(32-18)/2 + 32; 		// Jumble of constants is to center the screen. (And offset Y.) 
		SCX_REG = scx; 		// This indirection (scx -> SCX_REG) might be redundant. It was intended for ystart etc. 
		SCY_REG = scy; 

		// Rendering 
		// Simplify panning: the logical screen is always 32x32 tiles. We just try not to draw what we can't see. 

		#define TWIST_CORRECTION 4
		// Partial rendering setup: only change certain values between complete frames. 
		if( reset_render_variables ) { 
			reset_render_variables = 0; 

			ystart = scy / 8; 
			xstart = scx / 8; 
			ystop = ystart + 17; 
			xstop = xstart + 21;  
				// Screen is 18 tiles tall. +1 for overlap... except we're kinda covering up the bottom with some HUD stuff. 
				// Yeah, place the window to cover up two rows. We get a whole extra frame per second. 

			// Twisting is not centered on where the player is, so fix how it looks. 
			render_rotation = rotation + twist_factor * TWIST_CORRECTION; 
//			this_tube = &tube_multicolor[ render_rotation >> 5 ][ 0 ];

			// Tube features?
			// Declared globally, so draw_tile can use them - done here, once per rame. 
//			cutoff_distance = 128; 		// Debug. 

		} 		// if reset_render_variables 







		// Sprite stuff

		// BG coordinate system is scrolled to center tilemap, more or less. 
		// Might remove +4s so larger sprites don't have to account for it. 
		center_x = 128 - scx + 4; 
		center_y = -scy - 128 + 8+4;  		// This +8 makes no sense, but whatever. 

		// Obstacle-oriented sprite generation. 

		// Twisting rotation for sprites, yeah? 
		#define SPRITE_TWIST_CORRECTION 4
	//	rotation += twist_factor * TWIST_CORRECTION; 
		rotation += twist_factor * SPRITE_TWIST_CORRECTION; 

		free_sprite = 8; 		// Lowest available sprite. 8 is a wild guess for the player's needs.    
		// Hang on, render_sprite increments ob_index and adds appropriate distance to obstacle_distance. 
		// We're still only drawing out to a distance of 64. But we only have 64 obstacle slots. 
		// Can I just unroll this? 
	//	if( obstacles_on ) { 
			#define RENDER_DISTANCE 64
			ob_index = ( scroller_x + 1 ) >> 2;    

			// Unrolled loop. Only 64 slots across 256 scroller_x units, and draw distance is 64, so... only check one-quarter.
			// render_sprite increments ob_index and adds appropriate distance to obstacle_distance. 
			obstacle_distance = 3 + 3 - scroller_x & 0x03; 		// Bottom two bits, otherwise distances alias to multiples of 4


				// Apparently we run out of sprites juuust barely past what I've been doing. 
				// Nope, it was an issue with obstacle_distance -around- 64. 
				// So this begins with a value between 4 and 6. We immediately add 4. 
				// After the 12th render_sprite() call (and +=4), it's 57, +/-1. 
			// Normal objects: scale to fit. 
			obstacle_distance += 4;
			render_sprite(); 	obstacle_distance += 4;
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  

			render_sprite(); 	obstacle_distance += 4;
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  

			render_sprite(); 	obstacle_distance += 4;
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  
			render_sprite(); 	obstacle_distance += 4;  		// obstacle_distance = 57, +/- 1

//			obstacle_distance = 63;  
			render_sprite(); 	obstacle_distance += 4; 		// 60-63
			obstacle_distance = 63;  
			render_sprite(); 	//obstacle_distance += 4;  		// 64-68
			render_sprite(); 	 
			render_sprite(); 	

			// Distant objects: render at max distance. 
			render_sprite(); 
			render_sprite(); 
			render_sprite(); 
			render_sprite(); 

			render_sprite(); 
			render_sprite(); 
			render_sprite(); 
			render_sprite(); 

			render_sprite(); 
			render_sprite(); 
			render_sprite(); 
			render_sprite(); 

			render_sprite(); 
			render_sprite(); 
			render_sprite(); 
			render_sprite(); 


	//	} 		// Debug obstacles_on conditional 

		// Undo twisting rotation for sprites. 
		// (Physics / collision stuff happens -before- this, and is not affected by anything graphical.) 
		// This is still screwy, no pun intended. Sprites drift by nearly 45 degrees as the curve changes. 
	//	rotation -= twist_factor * TWIST_CORRECTION;
		rotation -= twist_factor * SPRITE_TWIST_CORRECTION; 



		// Player sprite
		// Eventually: pick sprite based on turning direction etc. 
		uint8_t px = center_x; 
		uint8_t py = center_y + 8*8; 

		// Spoiler gimmick, when you press B.
		int8_t wings_up = 0; 
		if( input & J_B ) { 
			// Lower wing sprites - dirt cheap alternative to new sprites with raised flaps or whatever. 
			wings_up = 2; 
			py += ship_bob[1][ ( hit_shake ) & 0x7 ];		// Needs slight bob to avoid looking grounded. 
		} else { 
			// Otherwise make the ship bob up and down as it flies. 
			py += ship_bob[0][ ( hit_shake >> 1 ) & 0x7 ]; 		// %8, god willing. 
		} 

		// When sliding the screen around to emphasize a curve, move the player the other way. 
		// Player distance is ostensibly 20+ units from the camera. 
		// We know which quadrant we're using based on twist_factor's sign. 
		if( twist_factor ) { 
			int8_t p_rotation = 8 * twist_factor; 
			int8_t p_rotation_sample = abs( p_rotation % 64 ) / 4;
			if( twist_factor > 0 ) { 
				px -= 2 * sin_from_polar[ p_rotation_sample ][ 64 - 18 ]; 
			} else { 
				px += 2 * sin_from_polar[ p_rotation_sample ][ 64 - 18 ];
			} 
			py += sin_from_polar[ 15 - p_rotation_sample ][ 64 - 18 ] - 5*8 - 3;
		}

		// Tilt sprite using twist_factor. 

		// This tilt should be based on horizontal distance from vanishing point, not just the curve bend. 
		// Which doesn't actually happen except in curves. Hmm. So more like horizontal distance from center of screen?

//		int8_t player_shear = ( 80 - px ) / 16 + twist_factor / 2; 
		// Tiny bit strong? Like it's obvious the sprite has to be wider, to stretch at such an angle. 
		// Either tone it down from (80-px)/8 or nudge px closer together based on strength of shear. 
		// px is not quite the right basis, in a curve. But center_x is still completely wrong in a curve. Backwards, even. 
	//		if( twist_factor ) { player_shear = twist_factor / 2; } 
		// Adding twist_factor/2 is... still kinda crap. Eh. Cosmetic fine-tuning. 
//		int8_t scrunch = abs( twist_factor ) / 2; 
		// Really, just sample from angle. Get it right. 

		// 8x16 tiles cannot be set to odd values. The bottom bit is clobbered in hardware. 
		/*
			GBTD's fucky sprite order goes: 
			0 2 8 A
			1 3 9 B
			4 6 C E
			5 7 D F
			I understand why, but it's still awful. 
		*/

		// Bit 6 is vertical flip, bit 5 is horizontal flip, bit 4 is palette 0 / 1. 
			// May also flicker between 0 and 1 if the main difference is swapping one grey for white. Flare the engines. 
		#define VFLIP 0b01000000
		#define HFLIP 0b00100000
		#define PSWAP 0b00010000

/*
		// Using hit_shake because it increments every rendered frame. 
		place_sprite( 0, 0x00, player_ship[ hit_shake & 0x1 ][0], 
			px - (16 - 2*scrunch), py - 2*player_shear + wings_up ); 

		place_sprite( 1, 0x00, player_ship[ hit_shake & 0x1 ][1], 
			px - (8 - scrunch), py - player_shear ); 

		place_sprite( 2, HFLIP, player_ship[ hit_shake & 0x1 ][2], 
			px, py );  

		place_sprite( 3, HFLIP, player_ship[ hit_shake & 0x1 ][3], 
			px + (8 - scrunch), py + player_shear + wings_up ); 
*/

		int player_shear = ( 80 - px ) / 16; 		// No twist_factor influence. Not ideal, but less ugly. 
		// Using hit_shake because it increments every rendered frame. 
		place_sprite( 0, 0x00, player_ship[ hit_shake & 0x1 ][0], 
			px - (16), py - 2*player_shear + wings_up ); 

		place_sprite( 1, 0x00, player_ship[ hit_shake & 0x1 ][1], 
			px - (8), py - player_shear ); 

		place_sprite( 2, HFLIP, player_ship[ hit_shake & 0x1 ][2], 
			px, py );  

		place_sprite( 3, HFLIP, player_ship[ hit_shake & 0x1 ][3], 
			px + (8), py + player_shear + wings_up ); 




		// Clear unused sprites: 
		// This probably shouldn't be its own for-loop. 
		// Check if doing this at the front, unrolled, is faster. 
			// ... after making OAM DMA updates manual. 
		for( uint8_t c = free_sprite; c < 40; c++ ) { 
			move_sprite( c, 0, 150 ); 		// Betting 150 beats 0,0 because OAM search will never see it. 
		} 

		// Print framerate. Fine performance can be tracked by updating during hblank routine, if needed / applicable. 
		// Numeral sprites start at 16. 
		// Oh of course these have a meaningful impact on framerate. Possibly just because of division. 
		const uint16_t this_frame = line_count; 
		line_count = 0; 

		// Very long running average. 
	//		running_average = ( running_average << 5 ) - ( running_average >> 1 ) + ( this_frame >> 1 ); 
	//		running_average = running_average >> 5; 

		running_average = ( running_average << 4 ) - ( running_average ) + ( this_frame ); 
		running_average = running_average >> 4; 

		// Oh just print the field count. Lower is better. 
		// Octal because chars aren't arranged for easy hex. 
		vram_pointer = get_win_xy_addr( 0, 0 );
		set_vram_byte( ( vram_pointer++ ), ( ( running_average >> 9 ) & 0x07 ) + 16 ); 
		set_vram_byte( ( vram_pointer++ ), ( ( running_average >> 6 ) & 0x07 ) + 16 ); 
		set_vram_byte( ( vram_pointer++ ), ( ( running_average >> 3 ) & 0x07 ) + 16 ); 
		set_vram_byte( ( vram_pointer++ ), ( ( running_average ) & 0x07 ) + 16 ); 

		display_number( accelerator, 5 ); 
		display_number( health, 8 ); 
		display_number( boost, 12 ); 

	} 		// End of while(1) for gameplay loop 

} 		// End of play_level() 








void show_stats() {
	HIDE_WIN;
	HIDE_SPRITES; 		// Doesn't work. Fuck you. 

	// Clunk clunk. 
	for( uint8_t c = 0; c < 40; c++ ) { 
		move_sprite( c, 0, 150 ); 		// Betting 150 beats 0,0 because OAM search will never see it. 
	} 

	init_bkg( 0x0 );

	// Show numbers onscreen, slowly: 
		// Clear time
		// ... actually that might be all. 
	// Just write "CLEARED" in a big-ass font. Same aesthetic as the start-screen logo. 
		// Ideally draw it on BG1 and just swap that out. Instant fullscreen change. 
	SCX_REG = 0; 
	SCY_REG = 0;
	if( ! you_died ) { 
		draw_text( "CLEARED", 6, 9 ); 
	} else { 
		draw_text( "FAILED", 7, 9 ); 
	} 

	// Clear playfield. 
	for( uint8_t c = 0; c < 64; c++ ) { 
		obstacles[c].type = 0; 
	} 

	// Wait for J_START
	while( ! ( joypad() & J_START ) ) {
		wait_vbl_done();
	}
}







//const uint8_t* window_address;// = get_win_xy_addr( 0, 0 ); 		// Maybe?
const char hex[] = "0112234455677889"; 
void display_number( uint8_t number, uint8_t x ) { 
	vram_pointer = get_win_xy_addr( x, 0 ); 
//	set_vram_byte( ( vram_pointer++ ), number >> 4 ); 
//	set_vram_byte( ( vram_pointer++ ), number & 0x0F ); 
	set_vram_byte( ( vram_pointer++ ), hex[ number >> 4 ] - 0x20 ); 
	set_vram_byte( ( vram_pointer++ ), hex[ number & 0x0F ] - 0x20 ); 
} 

void draw_text( char* string, uint8_t x, uint8_t y ) { 
	vram_pointer = get_bkg_xy_addr( x, y ); 
	while( *string ) { 
		set_vram_byte( ( vram_pointer++ ), *string - 0x20 ); 
		string++; 
	} 
}

// Display raw line_count as well, because why not. 
// (Or whatever else I want to track.)
// this_frame, field_count, rotation, tile_count, curve_x, velocity, 
	// twist_factor, twist_degree, pan_x, move_speed, side (ish), 
void debug_output( uint8_t variable, uint8_t xpos, uint8_t ypos ) { 
	vram_pointer = get_win_xy_addr( xpos, ypos );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable / 100) % 10 ) + 16 );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable / 10) % 10 ) + 16 );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable ) % 10 ) + 16 );
} 








// Performance is all about making this a hot loop. 
// So: elide as much complexity as possible. 
// (render_sprite is now also terrible, so unfuck that too.) 
void draw_tile() { 
	const uint8_t distance_sample = distance_table[ lookup ]; 		// Distance from camera, for twist. 
	const uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 
//	const uint8_t distance = distance_table[ lookup ] + scroller_x;

	const uint8_t angle_sample = angle_table[ lookup++ ];		// For diagonals.  
	uint8_t angle = angle_sample + render_rotation; 
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 

	uint8_t outbyte = tube_color[ angle ]; 

	outbyte -= segment_color[ distance >> 5 ]; 
	set_vram_byte( vram_pointer++, outbyte );
} 




void draw_tile_generic() { 

	// DRY: use variable for sampling shenanigans. (Eventually for Y as well.)
	// Is const faster? Yeah, wow: 6.4 FPS with a reused global variable, 6.6 with const distance, 6.8 for both. 
		// Presumably thanks to informing the compiler it's just a scratch value. 
	//	uint8_t distance = distance_table[ x + 32 * y ] + scroller_x;
	//	uint8_t angle = angle_table[ x + 32 * y ] + rotation;

	// You idiot - twist the tunnel. Add rotation based on distance. 
	const uint8_t distance_sample = distance_table[ lookup ]; 		// Distance from camera, for twist. 
	const uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 
//	const uint8_t distance = distance_table[ lookup ] + scroller_x;

	const uint8_t angle_sample = angle_table[ lookup++ ];		// For diagonals.  
	uint8_t angle = angle_sample + render_rotation; 
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 

/*
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 
	if( twist_factor ) {
		const int8_t twist_rotation = distance_sample >> twist_degree;

//		if( twist_factor < 0 ) { twist_rotation = -twist_rotation; }
//		angle += twist_rotation;
		if( twist_factor < 0 ) { angle -= twist_rotation; } 		// Should be marginally more efficient. 
		else { angle += twist_rotation; }
	}
*/

//	const uint8_t angle = angle_function( distance_sample ); 

	uint8_t outbyte = tube_color[ angle ]; 		// This one. 
//	uint8_t outbyte = tube_color[ angle++ ];
//	uint8_t outbyte = tube_multicolor[ distance >> 5 ][ angle ]; 		// Woof, no help. 
//	const uint8_t second = tube_color[ angle ];

//	uint8_t outbyte = tube_multicolor[ render_rotation >> 5 ][ angle ]; 
//	uint8_t outbyte = this_tube[ angle ];

/*
	uint8_t* tube_sample = &tube_color[angle]; 
	uint8_t outbyte = *(tube_sample++); 
	uint8_t second = *tube_sample; 
*/

/*
	// Startburst diagonals test - reasonably effective, kind of expensive. 
//	if( tube_color[ angle + 1 ] != outbyte ) { 
//	if( outbyte != second ) { 
	if( outbyte & 0x40 ) { 		// Flagged as 'the next angle is different' 
//		outbyte = 0; 
		outbyte += 2; 
//		outbyte += diagonal_along_angle[ angle ]; 
	} 
*/

//	outbyte += ( angle >> 1 ) & 0x70; 

/*
	// Concentric diagonals test - reasonably effective, weirdly cheap? 
//	if( ( distance >> 5 ) != ( ( distance + 2 ) >> 5 ) ) { 	// Surely expressible as distance & 0xNN > X. 
	else if( ( distance & 0b00011111 ) < 2 ) { 
//		outbyte = 1; 
		outbyte += 2; 
//		outbyte += diagonal_against_angle[ angle ]; 
	} 
*/

	// Diagonals will be the 16-tile-wide rows below the generic tiles. (Which might become directional themselves.) 
	// So... angle_sample>>5 to get 3 bits (only 8 rows of 16), but then we want to add 16*rows to that. 
//	outbyte += ( angle_sample >> 1 ) & 0xF0;
//	outbyte += ( angle_sample + 16 >> 1 ) & 0xF0;  
	// Woof, no. 

/*
	if( cutoff_distance && distance > cutoff_distance ) {
		set_vram_byte( vram_pointer++, outbyte - 3 ); 
		return; 
	} 
*/


	// Tube segments in slightly different colors:
//	outbyte -= segment_color[ ( ( distance >> 4 ) & 0x07 ) ];
//	outbyte -= segment_color[ distance >> 4 ]; 		// Padded array to avoid bitwise shenanigans.
	outbyte -= segment_color[ distance >> 5 ]; 		// Padded array to avoid bitwise shenanigans.  
//	outbyte -= ( distance >> 5 ) & 0x1; 

/*		// Hard shrug on this anti-aliasing attempt - all segment colors are one unit apart. 
//	const uint8_t second_sample = outbyte; 
//	const uint8_t segment_sample = distance >> 5; 
	const uint8_t second_sample = ( outbyte - segment_color[ ( distance + 8 ) >> 5 ] ) & 0x0F; 
	outbyte -= segment_color[ distance >> 5 ]; 
	outbyte &= 0x0F;
	outbyte = ( outbyte + second_sample ) / 2; 
*/


	// Multiplicative lighting
//	outbyte *= segment_lighting[ ( ( distance >> 4 ) & 0x07 ) ];
//	outbyte *= segment_lighting[ ( ( distance >> 3 ) & ( ( 1 << 5 ) - 1 ) ) ];  	// 32 elements  

/*
	// Bottom path
	// With the >>5 &0x03 stuff, the tube segments look more like lighting. 
	// Chevrons in dark areas are darker. So maybe we'd rather ramp tube colors up and down. But yikes. 
	uint8_t diagonal = angle - 4*43; 
	outbyte += ( ( diagonal < 43 ) && ! ( distance & 0b1100 ) ); 		// Chevrons
//	outbyte += 15 * ( ( ( diagonal < 43 ) && ! ( distance & 0b1100 ) ) ); 		// Chevrons - multiplicative - bad
		// In multiplicative lighting, chevrons should go before the multiplication. 
*/

//	outbyte >>= 4; 		// GB CPU "swap" command should make this cheap. Should. 
//	outbyte |= 0x80; 		// Tiles start at 128. I should absolutely change this by moving the font data. 

//	set_vram_byte( vram_pointer++, outbyte & 0x8F );
	set_vram_byte( vram_pointer++, outbyte );
//	set_vram_byte( vram_pointer++, outbyte + 0x80 );
//	health = outbyte; 		// Stupid debug to make sure we're not optimizing into nothing 
//	*(vram_pointer++) = outbyte;
} 



void draw_tile_positive() { 

	const uint8_t distance_sample = distance_table[ lookup ]; 		// Distance from camera, for twist. 
	const uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 
//	const uint8_t distance = distance_table[ lookup ] + scroller_x;

	const uint8_t angle_sample = angle_table[ lookup++ ];		// For diagonals.  
	uint8_t angle = angle_sample + render_rotation; 
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 

	const int8_t twist_rotation = distance_sample >> twist_degree;
	angle += twist_rotation; 

	uint8_t outbyte = tube_color[ angle ]; 		// This one. 

	// Tube segments in slightly different colors:
	outbyte -= segment_color[ distance >> 5 ]; 		// Padded array to avoid bitwise shenanigans.  

	set_vram_byte( vram_pointer++, outbyte );
} 


void draw_tile_negative() { 

	const uint8_t distance_sample = distance_table[ lookup ]; 		// Distance from camera, for twist. 
	const uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 
//	const uint8_t distance = distance_table[ lookup ] + scroller_x;

	const uint8_t angle_sample = angle_table[ lookup++ ];		// For diagonals.  
	uint8_t angle = angle_sample + render_rotation; 
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 

	const int8_t twist_rotation = distance_sample >> twist_degree;
	angle -= twist_rotation;

	uint8_t outbyte = tube_color[ angle ]; 		// This one. 

	// Tube segments in slightly different colors:
	outbyte -= segment_color[ distance >> 5 ]; 		// Padded array to avoid bitwise shenanigans.  

	set_vram_byte( vram_pointer++, outbyte );
}




void draw_tile_cutoff() { 

	const uint8_t distance_sample = distance_table[ lookup ]; 		// Distance from camera, for twist. 
	const uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 
//	const uint8_t distance = distance_table[ lookup ] + scroller_x;

	const uint8_t angle_sample = angle_table[ lookup++ ];		// For diagonals.  
	uint8_t angle = angle_sample + render_rotation; 
//	uint8_t angle = angle_table[ lookup++ ] + render_rotation; 

	uint8_t outbyte = tube_color[ angle ]; 		// This one. 

	if( cutoff_distance && distance > cutoff_distance ) {
		set_vram_byte( vram_pointer++, outbyte - 3 ); 
		return; 
	} 
	outbyte -= segment_color[ distance >> 5 ]; 		// Padded array to avoid bitwise shenanigans.  

	set_vram_byte( vram_pointer++, outbyte );
} 






//void draw_row( int8_t row ) { 		// Maintain xstart / ystart as global, during each complete frame?
void draw_row( ) { 		// Maintain xstart / ystart as global, during each complete frame?  
	render_rotation = rotation + twist_factor * TWIST_CORRECTION; 

//	vram_pointer = get_bkg_xy_addr( xstart, ystart + row );
	vram_pointer = get_bkg_xy_addr( xstart, ystart + rolling_row );
	x = xstart; 
//	y = ystart + row; 
	y = ystart + rolling_row; 
//	row = y*32; 
	lookup = x+y*32;

	if( twist_factor == 0 && !cutoff_distance ) { 
		draw_tile();
		draw_tile();
		draw_tile();
		draw_tile();

		draw_tile();
		draw_tile();
		draw_tile();

		draw_tile();
		draw_tile();
		draw_tile();
		draw_tile();

		draw_tile();
		draw_tile();
		draw_tile();

		draw_tile();
		draw_tile();
		draw_tile();
		draw_tile();

		draw_tile();
		draw_tile();
		draw_tile();
	} else if( twist_factor > 0 ) { 
		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 

		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 

		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 

		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 

		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 

		draw_tile_positive(); 
		draw_tile_positive(); 
		draw_tile_positive(); 
	} else if( twist_factor < 0 ) { 
		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 

		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 

		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 

		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 

		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 

		draw_tile_negative(); 
		draw_tile_negative(); 
		draw_tile_negative(); 
	} else { 		// cutoff != 0
		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();

		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();

		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();

		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();

		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();

		draw_tile_cutoff();
		draw_tile_cutoff();
		draw_tile_cutoff();
	}


	rolling_row++; 
}






void place_sprite( uint8_t object, uint8_t properties, uint8_t graphic, uint8_t x, uint8_t y ) { 
	set_sprite_prop( object, properties ); 
	set_sprite_tile( object, graphic ); 
	move_sprite( object, x, y ); 
}












// Obstacle sprite arrays go from 1x1 to 4x4, but 4x4 is only 8 sprites, because they're all 8x16. 
// So the big 32x32px mine is 0x10, 0x12, 0x18, 0x1A, 0x14, 0x16, 0x1C, 0x1E. 
unsigned char mine4x4[] = { 0x10, 0x12, 0x18, 0x1A, 0x14, 0x16, 0x1C, 0x1E }; 
	// 3x3 is a hot mess:
unsigned char mine3x3[] = { 0x26, 0x28, 0x2A, 0x2C, 0x2E, 0x34 }; 
unsigned char mine2x2[] = { 0x20, 0x22 };
unsigned char mine1x1[] = { 0x24 };  
// Maybe an array of pointers, based on scale and orientation? Lots of duplicated addresses. 
// Booleans per-row? Plain 4.4 dimensions in one byte? Generic obstacles are only 3x2 sprites 'at 3x3.' '
// Oh, just set them to 0, and if( first tile of second row ) { draw that row }. 

unsigned char bump4x4[] = { 0x40, 0x42, 0x48, 0x4A, 0x44, 0x46, 0x4C, 0x4E }; 
unsigned char bump3x3[] = { 0x30, 0x32, 0x38, 0x00, 0x00, 0x00 }; 
unsigned char bump2x2[] = { 0x3C, 0x3E }; 
unsigned char bump1x1[] = { 0x3A }; 

// sprite_list[ kind ][ size ]. 
unsigned char* sprite_list[5][4] = { 
	{ mine1x1, mine2x2, mine3x3, mine4x4 }, 		// type 0 - fake - should never render - dontcare values
	{ bump1x1, bump2x2, bump3x3, bump4x4 }, 		// type 1 - generic lump 
	{ mine1x1, mine2x2, mine3x3, mine4x4 }, 		// type 2 - mmmMMICHAELBAYEXPLOSIONS 
	{ bump1x1, bump2x2, bump3x3, bump4x4 }, 		// type 3 - shattered debris 
	{ mine1x1, mine2x2, mine3x3, mine4x4 } 		// type 4 - power-up (placeholder values) 
}; 




// render_rotation reset_render_variables;
void render_sprite( ) { 
	ob_index++; 		// Index. Wraps around while obstacle_distance stays monotonic increasing. 
//	if( ob_index > 63 ) { ob_index = 0; } 		// Nope, manual wraparound, because we shortened the list. 
	ob_index &= 63; 		// 0b00111111 - 2^n-1, simple enough. 
//			obstacle_distance++;
//			obstacle_distance += 4;  
//			if( obstacles[ ob_index ].type ) {
	const obstacle_t* this_obstacle = &obstacles[ ob_index ]; 
	if( free_sprite > 40 ) { return; } 

//	if( ! obstacles[ ob_index ].type ) { return; }
	if( ! this_obstacle->type ) { return; }  

	// Only calculate rotation if it's in range. 
//	int8_t obstacle_rotation = obstacles[ ob_index ].orientation + render_rotation; 
	int8_t obstacle_rotation = this_obstacle->orientation + render_rotation; 
	if( twist_factor ) { 		// twist_factor != 0 
		if( twist_factor > 0 ) { 
			obstacle_rotation += obstacle_distance >> twist_degree; 
		} else { 		// twist_factor < 0
			obstacle_rotation -= obstacle_distance >> twist_degree; 
		} 
	}

	// Gotta position the obstacle in screen-space before we can exclude offscreen obstacles. 
	// Change quadrant's values to match sprite-flipping properties. 
		// I.e. 0x40 if it's in the upper half, and 0x20 if we flip left/right from default. 
	int8_t quadrant = 0; 		// Default: upper left. 
		if( abs( obstacle_rotation ) < 64 ) { quadrant = 1; } 		// +1 if lower. (Rotation 0 is the bottom.) 
		if( obstacle_rotation < 0 ) { quadrant += 2; } 		// +2 if left? I think? Coordinate systems are agony. 

	// Does const matter here? 7.0 FPS with, 7.0 FPS without. shrug. 
	const int8_t distance_sample = 64 - ( obstacle_distance & 0x3F ); 
	int8_t rotation_sample = abs( obstacle_rotation % 64 ) / 4;

	int8_t osx, osy; 
	switch( quadrant ) { 		// 90-degree sine table, so cosine is sine backwards. 16 angles per quadrant. 
		case 0: 		// Upper left. 
		osx = center_x - sin_from_polar[ ( 15 - rotation_sample ) ][ distance_sample ];
		osy = center_y - sin_from_polar[ rotation_sample ][ distance_sample ]; 
		break; 

		case 1: 		// Lower right. 
		osx = center_x - sin_from_polar[ rotation_sample ][ distance_sample ];
		osy = center_y + sin_from_polar[ ( 15 - rotation_sample ) ][ distance_sample ];
		break; 

		case 2:		// Upper right. Despite all logic. 
		osx = center_x + sin_from_polar[ ( 15 - rotation_sample ) ][ distance_sample ]; 
		osy = center_y - sin_from_polar[ rotation_sample ][ distance_sample ]; 
		break; 

//		case 3:		// Lower left. 
		default:		// Silences compiler warning 84: osx / osy "may be used before initialization."
		osx = center_x + sin_from_polar[ rotation_sample ][ distance_sample ]; 
		osy = center_y + sin_from_polar[ ( 15 - rotation_sample ) ][ distance_sample ]; 
		break; 
	}

	// Mildly questionable pattern: 'exit early if it's bad,' rather than 'do the rest if it's good.' 
	// "Warning 94: comparison is always false due to limited range of data type." 
	// Ah, signed can't be more than +127. 
	// What a pain in the ass it is to fit a range from 0-160 inside 0-255. 
	// I guess subtract it down to some middle value, then check abs(that)? Shift range to +/- 80-ish. 
	// Obstacles disappearing early might be a math/logic error here. 
	// -16 gets shunted to 16, so just osx_abs>160+16 means 0..160. 
	const uint8_t osx_abs = osx + 16; 
	const uint8_t osy_abs = osy + 16; 
	if( osx_abs > ( 160 + 16 + 16 ) || osy_abs > ( 144 + 16 + 16 ) ) { 		// 16 on either side. Whoops. 
		return; 
	}

	// set_sprite_prop's second parameter: 0x40 for upside-down, 0x20 flip left/right, 0x10 second palette. 
	// Oh god. Finer scaling by overlapping sprites? 
		// Requires treating them as one size larger, and changing spacing. 
		// Otherwise you need an art style  where gaps look normal. 
//	const uint8_t cutoffs[] = { 20, 26, 40 }; 		// Separations for four phases. 
//	const uint8_t cutoffs[] = { 18, 32, 53 }; 		// Ehhh. 
//	const uint8_t cutoffs[] = { 10, 20, 30 }; 		// Oh just eyeball it. 
	const uint8_t cutoffs[] = { 15, 22, 40 }; 		// Eyeballing it. Again: ehhh. 
	// The problem is that we spend almost no time at 3x3, 
		// and then obstacles stay the same size in front of your vehicle and then all the way offscreen. 
	// This was the worst thing that Iridion 3D did. 

	const uint8_t thing = this_obstacle->type & 0x0F;  

	uint8_t flags = 0x00; 
	if( thing == 4 ) { 		// Pickup
		flags = PSWAP; 		// Different colors 
	} 

	const unsigned char* which_sprite; 
	if( obstacle_distance < cutoffs[1]  ) { 
		if( obstacle_distance < cutoffs[0] ) { 		// Closest, 4x4

			which_sprite = sprite_list[ thing ][ 3 ]; 		// [which][size] 

			const uint8_t osy_top = osy - 16; 		// The tiniest bit better. 
			place_sprite( free_sprite++, flags, which_sprite[0], osx - 16, osy_top ); 
			place_sprite( free_sprite++, flags, which_sprite[1], osx - 8, osy_top ); 
			place_sprite( free_sprite++, flags, which_sprite[2], osx, osy_top ); 
			place_sprite( free_sprite++, flags, which_sprite[3], osx + 8, osy_top ); 

			// Bottom row:
			place_sprite( free_sprite++, flags, which_sprite[4], osx - 16, osy ); 
			place_sprite( free_sprite++, flags, which_sprite[5], osx - 8, osy ); 
			place_sprite( free_sprite++, flags, which_sprite[6], osx, osy ); 
			place_sprite( free_sprite++, flags, which_sprite[7], osx + 8, osy ); 

		} else { 		// Second closest, 3x3
			// Woof, 3x3 with 8x16 sprites is going to be wasteful. 
			// Either we fudge things to 24x16 for three sprites - or we burn another three sprites as half-full. 

			which_sprite = sprite_list[ thing ][ 2 ]; 		// [which][size] 

			place_sprite( free_sprite++, flags, which_sprite[0], osx - 12, osy - 12 ); 
			place_sprite( free_sprite++, flags, which_sprite[1], osx - 4, osy - 12 ); 
			place_sprite( free_sprite++, flags, which_sprite[2], osx + 4, osy - 12 ); 

			// Bottom row?
			// Ah fuck, this is set up to overlap the bottom and top rows. 
			if( which_sprite[3] ) { 		// 3x3 can sometimes be 3x2
				place_sprite( free_sprite++, flags, which_sprite[3], osx - 12, osy + 4 ); 
				place_sprite( free_sprite++, flags, which_sprite[4], osx - 4, osy + 4 ); 
				place_sprite( free_sprite++, flags, which_sprite[5], osx + 4, osy + 4 ); 
			}

		}
	} else {
		if( obstacle_distance < cutoffs[2] ) { 		// Third closest, 2x2

			// 8x16 sprites. One's x=-8 to x=0, other's x=0 to x=8. 
			// Ah fuck, we'd have to swap these if the h-flip property is set. 

			which_sprite = sprite_list[ thing ][1]; 		// [which][size] 

			// Eventually incorporate angle, to offset Y and shear in some fake rotation. 
			place_sprite( free_sprite++, flags, which_sprite[0], osx - 8, osy - 8 ); 
			place_sprite( free_sprite++, flags, which_sprite[1], osx, osy - 8 ); 

		} else { 		// Fourth closest, 1x1

			which_sprite = mine1x1; 
			which_sprite = sprite_list[ thing ][0]; 		// [which][size] 

			// Sprite flipping is conditional on quadrant, which we've already calculated. 
			// Oh: we could probably match that value to this. The switch-case literls are arbitrary. 
			// 8x16 sprites are still treated as 8x8. Their origin is unchanged. So: -4,-4. 
			place_sprite( free_sprite++, flags, which_sprite[0], osx - 4, osy - 4 ); 

		}
	}

}






// k is relative position to the player, i.e., 0 is same position - in scroller_x units. 
void object_collision_redux( int8_t k ) { 
//	const uint8_t check = scroller_x + k;
//	const uint8_t check = ( ( scroller_x >> 1 ) + k ) & 0x7F;
//	const uint8_t check = ( scroller_x + k + 10 ) >> 2;
	const uint8_t check = ( ( scroller_x + k + 10 ) >> 2 ) & 0x3F; 		// Make damn sure we're 0..64. 

	obstacle_t* this_thing = &obstacles[ check ]; 
	// switch( type & 0x8F ) { 0x0F, 0x80, and 0x8F return; default continues. } 
	if( ( this_thing->type & 0x0F ) == 0 ) { return; } 		// If this isn't an object, return. 
	if( ( this_thing->type & 0x80 ) == 0 ) { return; } 		// If this object is not hittable, return.  

	// Basically - use the uppermost bit of obstacle.type to indicate things you can collide with. 
	// May benchmark that idea versus giving obstacle_t a separate "hittable" flag. 
	// Explosions and head-on collisions should turn the object into generic visual clutter. 

	// Contact should probably be DRY'd. E.g. 0 is dead-on, +/-1 is glancing, +/- 2 is a near miss. 5 is right out. 
	// Obviously replace this with a table. rotation -> where_are_we. 
	const int8_t obstacle_rotation = this_thing->orientation + rotation; 
	int8_t where_are_we; 
	if( obstacle_rotation < 20 && obstacle_rotation > -20 ) { 		// Widest possible proximity
		if( obstacle_rotation > 16 ) { where_are_we = 2; } 		// Near miss, no contact
		else if( obstacle_rotation < -16 ) { where_are_we = -2; } 
		else if( obstacle_rotation > 8 ) { where_are_we = 1; } 		// Close brush, side impact
		else if( obstacle_rotation < -8 ) { where_are_we = -1; } 
		else{ where_are_we = 0; } 		// Head-on collision, direct impact
	} else { where_are_we = 5; } 		// Nowhere near. Yes, it's a Monty Python joke. Shut up. 
	if( where_are_we == 5 ) { return; } 		// Still a comparison because we're gonna use a table. 

	// Repetition is fine because conditionals are expensive. 
	switch( this_thing -> type ) { 

		case 0x80 + 4: 		// Some generic positive pickup, TBD
			this_thing->type = 0; 		// Disappear completely. 
			// Increment health and/or fuel, or something. 
			damage( -30, 0 ); 
//			boost += 30; 
			if( boost > (254-30) ) { boost = 255; } else { boost += 30; }
			play_sound( 20 ); 
		break; 


		// ... you should also get a speed boost for passing near bombs. 
		case 0x80 + 2: 		// Bombs / explosives
			switch( where_are_we ) { 		// All impacts cause explosions
				case -1: 
					velocity -= 75; 
					rotation -= 16; 
					this_thing->type = 0x03; 
					accelerator = 10; 
					play_sound( 3 ); 		// May also play a generic collision sound effect. 
					hit = 40; 
					damage( 40, -1 ); 
				break; 
				case 1:
					velocity += 75; 
					rotation += 16; 
					this_thing->type = 0x03; 
					accelerator = 10; 
					play_sound( 3 ); 		// May also play a generic collision sound effect. 
					hit = 40; 
					damage( 40, 1 ); 
				break;
				case 0: 
					this_thing->type = 0x03; 
					accelerator = 10; 
					play_sound( 3 ); 		// May also play a generic collision sound effect. 
					hit = 40; 
					damage( 40, 0 ); 
				break; 
			}
		break; 


		case 0x80 + 1:		// Generic obstacles
		default:
			switch( where_are_we ) { 		// Nested switch statements? Yeah sure why not. 
				case -2: accelerator += 20; break; 		// Near miss, no contact
				case 2: accelerator += 20; break; 
				case -1: 		// Close brush, side impact
					if( ! hit ) { 		// Don't clobber sound, don't boost while slow 
						velocity -= 60; 		// Smack left. 
						this_thing->type = 3;		// Debug - visual indicator - effect seems subtle.
						this_thing->type = 6;		// Debug - this shape SHOULD NOT APPEAR, coming down the pipe 
						this_thing->type &= 0x7F; 		// Flag as unhittable. 
						accelerator += 60; 		// Fixed-point forward speed, not actual acceleration, but shut up. 
						play_sound( 1 ); 
						damage( 1, -1 ); 
					} 
				break;  
				case 1: 
					if( ! hit ) {
						velocity += 60; 		// Smack right. 
						this_thing->type = 3;		// Debug - visual indicator - effect seems subtle.
						this_thing->type = 6;		// Debug - this shape SHOULD NOT APPEAR, coming down the pipe 
						this_thing->type &= 0x7F; 		// Flag as unhittable. 
						accelerator += 60; 		// Fixed-point forward speed, not actual acceleration, but shut up. 
						play_sound( 1 ); 
						damage( 1, 1 ); 
					} 
				break; 
				case 0: 
					hit = 30; 
					damage( 20, 0 ); 
					this_thing->type = 3;		// Eventually change to broken do-nothing value. 
					this_thing->type = 6;		// Debug - this shape SHOULD NOT APPEAR, coming down the pipe 
					this_thing->type &= 0x7F; 		// Flag as unhittable. 
					// Should also slow down forward speed, which is not "velocity," because naming things is in NP-hard. 
					accelerator -= 60; 		// Bit harsh...
					if( accelerator < 20 ) { accelerator = 20; } 		// ... or maybe this should be higher. 
					play_sound( 2 ); 
				break; 
			} 
		break; 

	} 

}






// Generic obstacle placement function. 
// Might still be referenced by specific functions like generic_debris - so we can still do weird shit. 
// E.g. sometimes you want a whole side blocked off by clustered obstacles, or you want a forced spiral of bombs. 
void place_obstacle( uint8_t type, uint8_t index, uint8_t density, uint8_t facet_mask ) {
//	if( density == 0 || density == 0xFF ) { return; } 
	if( facet_mask == 0 ) { return; } 		// 
	// Each type has its own offset, so they won't usually clobber one another.  

	// Why the fuck is density creating clusters instead of spacing things out? 
	// It's the same goddamn code as the other fill functions!
	// We pass the encoded value through prevalence_to_density. It goddamn well SHOULD be 1s at the bottom. 
	// But it plainly fucking isn't. 
	// Added spurious zeroes to the end of PREVALENCE_MASK. Goddammit. 

//	if( ( ( index + ( type & density ) ) & index ) == 0 ) { 
//	if( ( ( index + ( type & 0x0F ) ) & density ) == 0 ) {
//	if( ( ( index + type ) & 0x01 ) == 0 ) {
//	if( ( ( index + type ) & 0x07 ) == 0 ) {    
//	density = 0x07; 
	if( ( ( index + ( type & 0x0F ) ) & density ) == 0 ) {
		obstacles[ index ].type = type;
//		uint8_t read = urandom[ index ^ region_x ];
		int8_t read = srandom[ index ^ region_x ];  

		// Is there any elegant way to test for 'value in facet' - let alone shift one into a valid facet? 
		// Dropping invalid attempts would be fine. Want more? Increase density. 
		// Weirdly complicated because of the possibility space for six independent sides. 

/*
		// Pick top / bottom to reduce possibility space to three facets. 
		// Durrr orientation is signed. (Still screwy.) 
		if( ( read & 0x1 ) && ( facet_mask & 0b00000111 ) ) { 		// Coin toss, and check that toss is valid.
//			read &= 0x7F; 		// Clear highest bit
//			read |= 0x80; 
//			read += 64; 
			if( abs( read ) < 64 ) { read += 127; } 		// Intentional overflow
		} else { 		// facet_mask == 0 does not matter. 
//			read |= 0x80; 		// Set highest bit 
//			read |= 0x80; 
//			read -= 64; 
			if( abs( read ) > 64 ) { read += 127; } 		// Intentional overflow
		} 
		// ... why the fuck are these all over the place? 
*/

//		read |= 0x80;

/*
		// Force to bottom side, in the clunkiest way possible, because all attempts to be clever get fucked over:
		if( read < -64 || read > 64 ) { 
			read += 127; 
		} 

		if( ( read & 0x1 ) && ( facet_mask & 0b00111000 ) ) { 		// Coin toss: move to top side, if possible. 
			read += 127; 
		} else { 
		} 
*/


		if( !( facet_mask & 0b00111000 ) ) { 		// Nothing on top? Force to bottom. 
			if( read < -64 || read > 64 ) { 
				read += 127; 
			} 
		} else if( !( facet_mask & 0b00000111 ) ) { 		// Nothing on bottom? Force to top. 
			if( read > -64 || read < 64 ) { 
				read += 127; 
			} 
		} 


		// 2 1 0
		// 3 4 5

//		if( read < -( 127 - 22 ) && !( facet_mask & 0b001000 ) ) { read += 43; } 
//		if( read < -( 127 - (22+43) ) && !( facet_mask & 0b000100 ) ) { read += 43; } 
//		if( read < 0 && !( facet_mask & 0b000100 ) ) { read += 43; } 

/*			// Nope. Fuck me, I guess. 
		if( abs( read ) > ( 127 - 22 ) && !( facet_mask & 0b010000 ) ) { read += 43; } 		// Off top facet
		if( read < -64 && !( facet_mask & 0b100000 ) ) { read += 43; } // Off upper left facet
		if( read < -22 && !( facet_mask & 0b000100 ) ) { read += 43; } // Off lower left facet
		if( abs( read ) < 22 && !( facet_mask & 0b000010 ) ) { read += 43; } // Off bottom facet
		if( read < 64 && !( facet_mask & 0b000001 ) ) { read += 43; } 		// Off lower right facet 
*/

		obstacles[ index ].orientation = read; 		// Incorrect, but kick the can a bit. 
	}
}

// Obstacle-generating function(s). 
void generic_debris( uint8_t index ) { 
// New approach: directly take &0x07 kinda byte as an argument, to control density, 
	// and use six bits as a mask for which facets to appear on. 
//void generic_debris( uint8_t index, uint8_t density, uint8_t facet_mask ) { 
	// Make the &0x07 a variable so we can turn on low / high difficulty. 
	if( ( ( index + 1 ) & 0x07 ) == 0 ) { 		// Every eighth spot.
//	if( ( ( index + 1 ) & density ) == 0 ) { 		// Every eighth spot.
		obstacles[ index ].type = 0x81; 		// 0x80 = hittable, 0x01 = generic 
		obstacles[ index ].orientation = abs( srandom[ index ^ region_x ] ) - 64; 		// On bottom half
			// Using index instead of random_index makes this repeatable. 
			// I just need this to be deterministic based on index, 
				// because each spot might get called more than once. 
			// Easy fix for better randomization: xor index with whatever counter increments on scroller_x rolling over. 
	} 
} 


void bomb_obstacles( uint8_t index ) { 		// Bombs / explosions
	if( ( ( index + 1 + 2 ) & 0x1F ) == 0 ) { 		// Less often than debris, in-between spaces. 
		obstacles[ index ].type = 0x82; 		// 0x80 = hittable, 0x05 = bomb
		obstacles[ index ].orientation = abs( srandom[ index ^ region_x ] ) / 2 - 32; 		// On center facet... ish
	} 
}

void side_pickups( uint8_t index ) { 
//	if( ( ( index + 1 + 2 ) & 0b10101111 ) == 0 ) { 		// Very rarely
	if( ( ( index + 1 + 4 ) & 0x07 ) == 0 ) { 		// Every eighth spot (debug)
		obstacles[ index ].type = 0x86; 		// 0x80 = hittable, 0x06 = health, let's say
		int8_t read = abs( srandom[ index ^ region_x ] ) - 64; 		// Bottom half
		if( abs( read ) < 32 ) { read = read + read; } 		// Side facets
//		obstacles[ index ].orientation = srandom[ index ^ region_x ] ) / 4; 		// Side facets
		obstacles[ index ].orientation = read; 
	}
} 






// Change ship health
void damage( int8_t amount, int8_t direction ) { 
	// Change HP value
	// 0..255 now, so things get kind of annoying. 
	uint8_t oldhealth = health; 
	health -= amount; 

	if( amount > 0 && oldhealth < health ) { 		// Underflow indicates zero crossing - you dead. 
		health = 0; 
		// Kill player
		you_died = 1; 
		controls_locked = 250; 		// Frame countdown
	} else if ( amount < 0 && oldhealth > health ) { 		// Overflow? Max health. 
		health = 255; 
	} 


	//// Eventually damage wings and midsection based on direction
	uint8_t which = hit_shake & 0b11; 		// Random portion of the ship, 0..4

	if( amount > 0 ) { 		// You ran into something and it hurt 

		if( oldhealth < health ) { 		// Underflow indicates zero crossing - you dead. 
			health = 0; 
			// Kill player
		}

		// If damage is sufficient by itself, change part of the sprite. 
		if( abs( amount ) >= 20 ) { 

			switch( direction ) { 
				// Sideswipe? Damage appropriate wing. 
				case -2: 		// Shouldn't count, but just in case.
				case -1: 
					player_ship[ 0 ][ 3 ] = damaged_ship[ 0 ][ 3 ]; 
					player_ship[ 1 ][ 3 ] = damaged_ship[ 1 ][ 3 ]; 
				break; 

				case 1: 
				case 2:
					player_ship[ 0 ][ 0 ] = damaged_ship[ 0 ][ 0 ]; 
					player_ship[ 1 ][ 0 ] = damaged_ship[ 1 ][ 0 ]; 
				break;

				case 0: 		// Direct hit? Damage either central portion. 
					which = ( which & 0x1 ) + 1; 		// 0..4 -> 1..2
					player_ship[ 0 ][ which ] = damaged_ship[ 0 ][ which ]; 
					player_ship[ 1 ][ which ] = damaged_ship[ 1 ][ which ]; 
				break; 

				default: 		// Any random portion 
					player_ship[ 0 ][ which ] = damaged_ship[ 0 ][ which ]; 
					player_ship[ 1 ][ which ] = damaged_ship[ 1 ][ which ]; 
				break; 
			}

		} 

		// If HP below "shit's fucked" threshold, damage entire ship sprite
		if( health < 64 ) { 
			for( int8_t n = 0; n < 4; n++ ) { 
				player_ship[ 0 ][ n ] = damaged_ship[ 0 ][ n ];
				player_ship[ 1 ][ n ] = damaged_ship[ 1 ][ n ];
			}
		} 

	} else { 		// You picked up health and it did "negative damage"

		player_ship[ 0 ][ which ] = normal_ship[ 0 ][ which ]; 		// Randomly heal one section of the sprite
		player_ship[ 1 ][ which ] = normal_ship[ 1 ][ which ]; 
		// Tempted to repair the closest part, since we already calculate "direction" in collision. 

		// Clip to maximum HP. 
			// If max HP, repair entire ship sprite. 
			// Play some kind of pleasant noise? 
		if ( oldhealth > health ) { 		// Overflow? Max health. 
			health = 255; 
			for( int8_t n = 0; n < 4; n++ ) { 
				player_ship[ 0 ][ n ] = normal_ship[ 0 ][ n ];
				player_ship[ 1 ][ n ] = normal_ship[ 1 ][ n ];
			}
		} 

	} 



}






// We might just trigger self-decaying sounds. No buffer - just fire-and-forget. 
// Keep this function so we can deal with that later. 
// Maybe a minimal buffer that plays a different sound on the next frame?
	// Like if each channel has a one-element holdover, and if there's something there, it'll play that note and clear it. 

// Obstacle noises
// 0: cleanly pass obstacle
// 1: crunch against obstacle
// 2: slam into obstacle
// 3: explosion - may also play a collision explosion, if they use separate channels 

// Car noises
// 10: spoiler on? continuous subtle spoiler whine? upward jet? 
// 11: boosting (continuous?)
// 12: clunk between tube segments (e.g. scroller_x++ % 16 == 0)

// Pickup noises
// 20: minor pickup
// 21: major pickup
// 22: floor boost 

// CH4 "cons sel" with high "poly cnt freq" and "env nb step" produces lovely ringing explosions. 
// E.g. NR41-44 0x 3A A7 A8 80 for your car exploding, and A8->98 for bombs. 
// Higher "poly cnt div" might fit for generic obstacle collisions. 
// "Poly cnt step" to 0 adds more conflagration. NR43 0xX8 -> X0. 

// Might put a doppler shift into CH3 - ramp up, ramp down. Make it the "cleanly pass" noise. 
// Alternately, do find some use for that channel, since it can also be cranked up and down to arbitrary carrier frequencies. 

void play_sound( uint8_t which ) { 
//	uint8_t cached_index = audio_index+1; 		// Avoid race conditions with interrupts. (Might even +2.) 
	switch( which ) { 
		// Obstacle noises
		case 0: 		// Cleanly pass obstacle - possibly always hard panned left or right. 
			// CH2? NR21-24 0x 09 67 B4 83 
			NR21_REG = 0x09;
			NR22_REG = 0x67;
			NR23_REG = 0xB4;
			NR24_REG = 0x83;
		break;

		case 1: 		// Sideswipe obstacle
			// CH4 NR41-44 0x 3A 92 5D 80
			// Or 0x 3A 92 53 C0
			NR41_REG = 0x3A;
			NR42_REG = 0x92;
			NR43_REG = 0x53;
			NR44_REG = 0x80; 		// C0 didn't work right? 
		break;

		case 2: 		// Slam into obstacle
			// CH4 NR41-44 0x 3A C3 98 80
			// Or possibly 3A C3 89 80
			NR41_REG = 0x3A;
			NR42_REG = 0xC3;
			NR43_REG = 0x98;
			NR44_REG = 0x80;
		break;

		case 3: 		// Explosion
			// CH4 NR41-43 0x 3A C5 99 80
			NR41_REG = 0x3A;
			NR42_REG = 0xC5;
			NR43_REG = 0x99;
			NR44_REG = 0x80;
		break;


		// Car noises
		case 10: 		// Spoiler on - immediate or continuous?
			// Maybe on/off:
			// CH1 NR10-14 0x 77 41 44 47 C5 for on and 77 -> 7F for off
			// NR10 74 / 7C work better. Or 74 / 7B. They don't have to match perfectly. 
			NR10_REG = 0x74; 
			NR11_REG = 0x41;
			NR12_REG = 0x44;
			NR13_REG = 0x47;
			NR14_REG = 0xC5;
		break;

		case 11: 		// Spoiler off
			// Maybe on/off:
			// CH1 NR10-14 0x 77 41 44 47 C5 for on and 77 -> 7F for off
			// NR10 74 / 7C work better. Or 74 / 7B. They don't have to match perfectly. 
			NR10_REG = 0x7B; 
			NR11_REG = 0x41;
			NR12_REG = 0x44;
			NR13_REG = 0x47;
			NR14_REG = 0xC5;
		break;

		case 12: 		// Clunk between tube segments 
			// If CH3's "sound length" actually did anything, I could use whatever's there to do a quick high-pitched "click." 
		break;

		case 13: 		// Car explodes, game over
			// CH4 NR41-44 0x 34 F7 A0 80
			NR41_REG = 0x34;
			NR42_REG = 0xF7;
			NR43_REG = 0xA0;
			NR44_REG = 0x80;
			// May also modify CH2 registers to make sure boosting noise ends. Just in case. 
		break; 

		case 14: 		// Boosting - immediate or continuous? 
			// Continuous until released, since it's limited:
			// CH2 NR21-24 0x CE 7F 93 80
			// Just remember to turn it off! 
			// Sounds terrible for some reason. 
			NR21_REG = 0xCE;
			NR22_REG = 0x7F;
			NR23_REG = 0x93;
			NR24_REG = 0x80;
		break;

		case 15: 		// Disable boosting noise. Not technically a sound? Play silence on CH2. 
			NR21_REG = 0xCE;
			NR22_REG = 0x72;
			NR23_REG = 0x93;
			NR24_REG = 0xC6;
		break; 


		// Pickup noises 
		case 20: 		// Minor pickup
			// CH1 NR10-14 0x 55 83 74 73 86 
			// Quieter. 
			NR10_REG = 0x55; 
			NR11_REG = 0x83;
			NR12_REG = 0x74;
			NR13_REG = 0x73;
			NR14_REG = 0x86;
		break;

		case 21: 		// Major pickup
		break;

		case 22: 		// Floor boost 
			// CH1 NR10-14 0x 4F C0 95 9F 87
		break;

		default: 		// Shut up the compiler. 
		break; 		
	}
} 























