#include <gb/gb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>		// For e.g. abs()
//#include <types.h> 	// For e.g. fixed? galaxy.c doesn't use this. WTF. 

#include <gb/bgb_emu.h>

#include "tunnel_tables.h" 

// Game Boy Competition 2021 entry.
// https://itch.io/jam/gbcompo21 
// T-minus one month and a couple days. 
// Thinking a tunnel rotzoomer, shamelessly inspired by one in "Gejmbaj" by Snorpung & Nordloef. 
	// Theirs uses 40x18 logical pixels in 16-ish shades, which I infer means they're doing 
		// tile compression via scanline shenanigans. 
	// Hence using GBDK's text_scroller.c as a basis. 
	// Not exactly Quake, here, but still a lookup gimmick that Snorpung only gets 20-30 Hz out of. 
	// Pros: well-worn demoscene territory, double-buffered (probably), fancy rotation.
	// Cons: extremely low-res by default, speed is not a gimme, kind of a one-trick pony. 
	// The initial goal is STUN Runner. I do love and appreciate that game, 
		// but not so much that I'm afraid to ignore "correct" behavior and do something cool. 
	// But I just about giggled myself to sleep over the idea of rotzoomer Half-Life. 
	// The tunnel gimmick is perspective-correct-ish for tight hallways. 
	// Walls and side passages are possible. Even in STUN Runner, I expect to do cutouts and skyboxes.
	// For now - fixed projection, flying through a straight tunnel. 
// Learning GBDK as I go. Some of this is so-so because it disguises magic. 
	// In particular, some demos use a bitmap, which is not strictly supposed to be possible. 
	// I presume there's a scanline gimmick that swaps BG memory from starting at 0 to starting at 128. 
	// Which is fine, and doesn't mess with sprites, but it can cause weirdness, 
		// and it must have an associated performance cost. It should be less hand-wavy. 
	// Basically, magic is fine, but make please the invocation obvious. 


//	set_sprite_prop( 0, 0x00 );
	// https://gbdk-2020.github.io/gbdk-2020/docs/api/gb_8h.html#a99ea3252469e3614e977cce2aa1d06f7
	// Sprite property bits. 7: priority, 0 is behind BG. 6: vertical flip. 5: horizontal flip. 4: DMG OBJ palette 0/1. 
		// 3: GBC sprite bank. 2/1/0: GBC palette. 
//	set_sprite_tile( 0, 132 ); 		// Sprite number 0 to 39, CHR-RAM tile number 0 to... 256? GBDK might fudge it to 128. 
		// No, I strongly suspect GBDK accurately reflects the hardware and makes sprite tile 0 = BG tile 128. (Yep.)
		// So I should probably re-aim set_sprite_data. (Did.)
		// Oh why the fuck is it warning about overflow for 128+3? Is it signed? 
		// No - just more stupidity with macros. The actual value is fine. 
//	move_sprite( 0, 160/2, 144/2);



//const uint8_t scanline_offsets_tbl[] = {0, 1, 2, 3, 3, 2, 1, 0, 0, 1, 2, 3, 3, 2, 1, 0};
//const uint8_t * scanline_offsets = scanline_offsets_tbl;

uint8_t scroller_x = 0; 		// This accidentally became our player / camera position variable. 
	// It should maybe be 16-bit and it should definitely be "z" instead. 

// Some of these are redundant holdovers from the original text_scroller.c code. I forget which. 
uint8_t* scroller_vram_addr;
//uint16_t base, limit;

uint8_t* vram_pointer; 



// Rendering stuff
uint8_t outbyte, angle, screen_distance, distance, input; 		// Rendering scratch variables 
uint8_t scx, scy; 		// Vertical sync / vsync buffers for SCX/SCY_REG
//uint8_t row_buffer[32]; 		// Intermediate main-RAM holdover for grouped VRAM writes. 
OAM_item_t sprite_array[ 64 ]; 		// Oversized sprite array, so we can be lazy about memory safety

// Tube stuff
//int8_t gravity; 		// Physics scratch 
int8_t rotation = 0; 		// Game state - initially 11 for testing
int8_t rotation_impulse = 10; 		// Input accumulator
int8_t velocity = 0; 		// Necessary for momentum
uint8_t tube_color[256]; 		// Might make this multi-dimensional. 
	// E.g. tube_color[2][256] for alternating patterns, 
		// or straight-up using this to encode our level designs. 
	// Some map could be sections 0, 0, 0, 7, 3, and that'd be normal shit followed by cutouts or whatever. 
// Eventually need centripital force variable. Though curve info may suffice. (If all tracks are level.) 
uint8_t controls_locked; 		// Boolean. Over-the-top lock. 
int8_t twist_factor; 		// Adjust sampled rotation based on distance. 
int8_t twist_degree; 		// The actual number to shift by.
	// This is game state because it's not used directly for rendering.
	// twist=distance>>0 is extreme, >>4 is nothing. 
	// And we have to do rotation +/- this distance factor. 

// Obstacles
#define MAX_OBSTACLES 32
// Distances should maybe be 16-bit? Or fixed-point, if I can get GBDK to play nice with fixed-point. 
struct obstacle { 
	uint8_t type; 		// 0 for nothing, other values for enemies, barriers, etc. 
	uint8_t location; 		// Distance, basically. Not an ideal name. 
	int8_t orientation; 		// Rotation. Objective placement around the pipe. 
};
struct obstacle obstacles[ MAX_OBSTACLES ]; 
uint8_t nearby_obstacles[ MAX_OBSTACLES ]; 		// Indices to objectacles[] 
uint8_t nearby_obstacle_count = 0; 
uint8_t hit = 0; 		// Collision indicator, i-frame timer
uint8_t hit_shake = 0; 		// Framerate-dependent screen shake 
uint8_t severity = 0; 		// Strength of collision - damage dealt 
//uint8_t invincible = 0; 		// Flag for i-frames, and potentially a powerup timer
	// Nope, just use "hit." At least, for now. 

// FPS stuff
uint16_t line_count = 0; 		// This frame 
uint16_t running_average = 1024; 		// Over time - nonzero initial value
uint16_t field_count = 1; 		// Number of whole frames to hand-wave, for variable framerate
uint16_t field_overflow = 0; 		// Leftover scanlines, to roll over into whole frames 
int16_t tile_count; 

// Debug stuff?
uint8_t obstacles_on = 0xFF; 
uint8_t side;		// Shouldn't be global, but needed for debug



#if 0
/*
// Banged this out in JS console because GBDK has no trig library. 
for( j = 0; j < 1; j++ ) { 
n = 0; d = 0; p = 0; z = 0; t += 1; screen = ""; xmax = 32; ymax = 32;
for( sy = 0; sy < ymax; sy++ ) { screen += "\n"; 
for( sx = 0; sx < xmax; sx++ ) { 
x = ( sx - ( xmax - 1 ) / 2 ); y = ( sy - (ymax-1)/2 ); y *= -1; 
d = Math.hypot( x * 20 / xmax, y * 18 / ymax ); 
z = 128/(d+0.5);
if( x > 0  && y > 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) } 
else if ( x < 0 && y > 0 ) { n = parseInt( 180 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
else if ( x < 0 && y < 0 ) { n = parseInt( Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) + 180 }
else if ( x > 0 && y < 0 ) { n = parseInt( 360 - Math.atan( Math.abs( y/x ) ) * 360 / ( 2 * Math.PI ) ) }
p = n % 120  > 120/2; 
p = p ^ ( z % 10 > 5 ); 
screen += parseInt( n * 256 / 360 ) + ", " ; }  } console.log( screen ); }
*/

// Might be better off as one table with interleaved elements because consecutive reads are cheaper. 
// Dither these. 
const uint8_t distance_table[] = 
		// 32x32 version - wide, so we can pan, and at least theoretically tall and y-sheared. 
{ 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9, 
9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10, 9, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 14, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 
10, 11, 11, 12, 12, 13, 13, 14, 15, 15, 16, 16, 17, 17, 18, 18, 18, 18, 17, 17, 16, 16, 15, 15, 14, 13, 13, 12, 12, 11, 11, 10, 
10, 11, 11, 12, 13, 13, 14, 15, 15, 16, 17, 18, 18, 19, 19, 19, 19, 19, 19, 18, 18, 17, 16, 15, 15, 14, 13, 13, 12, 11, 11, 10, 
11, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20, 21, 21, 21, 21, 21, 21, 20, 19, 18, 17, 16, 15, 15, 14, 13, 12, 12, 11, 11, 
11, 11, 12, 13, 14, 14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 24, 24, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 14, 13, 12, 11, 11, 
11, 12, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 20, 18, 17, 16, 15, 14, 13, 12, 12, 11, 
11, 12, 13, 14, 14, 15, 17, 18, 19, 21, 23, 25, 26, 28, 29, 30, 30, 29, 28, 26, 25, 23, 21, 19, 18, 17, 15, 14, 14, 13, 12, 11, 
11, 12, 13, 14, 15, 16, 17, 19, 20, 22, 24, 27, 29, 32, 34, 35, 35, 34, 32, 29, 27, 24, 22, 20, 19, 17, 16, 15, 14, 13, 12, 11, 
12, 12, 13, 14, 15, 16, 18, 20, 21, 24, 26, 29, 33, 36, 40, 41, 41, 40, 36, 33, 29, 26, 24, 21, 20, 18, 16, 15, 14, 13, 12, 12, 
12, 13, 13, 14, 16, 17, 18, 20, 22, 25, 28, 32, 37, 42, 47, 51, 51, 47, 42, 37, 32, 28, 25, 22, 20, 18, 17, 16, 14, 13, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 23, 26, 30, 35, 41, 49, 58, 65, 65, 58, 49, 41, 35, 30, 26, 23, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 24, 27, 31, 37, 44, 56, 72, 91, 91, 72, 56, 44, 37, 31, 27, 24, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 18, 19, 21, 24, 27, 32, 38, 47, 61, 86, 139, 139, 86, 61, 47, 38, 32, 27, 24, 21, 19, 18, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 18, 19, 21, 24, 27, 32, 38, 47, 61, 86, 139, 139, 86, 61, 47, 38, 32, 27, 24, 21, 19, 18, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 24, 27, 31, 37, 44, 56, 72, 91, 91, 72, 56, 44, 37, 31, 27, 24, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 14, 15, 16, 17, 19, 21, 23, 26, 30, 35, 41, 49, 58, 65, 65, 58, 49, 41, 35, 30, 26, 23, 21, 19, 17, 16, 15, 14, 13, 12, 
12, 13, 13, 14, 16, 17, 18, 20, 22, 25, 28, 32, 37, 42, 47, 51, 51, 47, 42, 37, 32, 28, 25, 22, 20, 18, 17, 16, 14, 13, 13, 12, 
12, 12, 13, 14, 15, 16, 18, 20, 21, 24, 26, 29, 33, 36, 40, 41, 41, 40, 36, 33, 29, 26, 24, 21, 20, 18, 16, 15, 14, 13, 12, 12, 
11, 12, 13, 14, 15, 16, 17, 19, 20, 22, 24, 27, 29, 32, 34, 35, 35, 34, 32, 29, 27, 24, 22, 20, 19, 17, 16, 15, 14, 13, 12, 11, 
11, 12, 13, 14, 14, 15, 17, 18, 19, 21, 23, 25, 26, 28, 29, 30, 30, 29, 28, 26, 25, 23, 21, 19, 18, 17, 15, 14, 14, 13, 12, 11, 
11, 12, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 24, 25, 26, 27, 27, 26, 25, 24, 22, 21, 20, 18, 17, 16, 15, 14, 13, 12, 12, 11, 
11, 11, 12, 13, 14, 14, 15, 16, 17, 18, 20, 21, 22, 23, 23, 24, 24, 23, 23, 22, 21, 20, 18, 17, 16, 15, 14, 14, 13, 12, 11, 11, 
11, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20, 21, 21, 21, 21, 21, 21, 20, 19, 18, 17, 16, 15, 15, 14, 13, 12, 12, 11, 11, 
10, 11, 11, 12, 13, 13, 14, 15, 15, 16, 17, 18, 18, 19, 19, 19, 19, 19, 19, 18, 18, 17, 16, 15, 15, 14, 13, 13, 12, 11, 11, 10, 
10, 11, 11, 12, 12, 13, 13, 14, 15, 15, 16, 16, 17, 17, 18, 18, 18, 18, 17, 17, 16, 16, 15, 15, 14, 13, 13, 12, 12, 11, 11, 10, 
10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 
9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 14, 14, 14, 13, 13, 12, 12, 11, 11, 10, 10, 9, 
9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10, 9, 
9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9 }; 

const uint8_t angle_table[] = 
		// 32x32 version for panning and/or y-shearing. 
{ 96, 94, 93, 91, 89, 88, 86, 83, 81, 79, 77, 75, 72, 70, 67, 64, 62, 59, 56, 54, 51, 49, 47, 45, 43, 41, 39, 37, 36, 34, 32, 32, 
96, 96, 93, 92, 91, 88, 87, 85, 83, 81, 78, 76, 73, 70, 67, 64, 62, 59, 56, 54, 51, 49, 46, 44, 41, 39, 38, 36, 34, 33, 32, 30, 
98, 97, 96, 93, 92, 90, 88, 86, 84, 81, 79, 76, 73, 71, 68, 65, 61, 59, 56, 53, 50, 47, 45, 42, 40, 38, 36, 34, 33, 32, 29, 29, 
100, 98, 97, 96, 93, 92, 90, 88, 85, 83, 80, 77, 74, 71, 68, 65, 61, 59, 55, 52, 49, 46, 44, 41, 39, 36, 34, 33, 32, 29, 28, 27, 
101, 100, 98, 97, 96, 93, 91, 89, 87, 84, 81, 78, 75, 72, 68, 65, 61, 58, 54, 51, 48, 45, 42, 39, 37, 35, 33, 32, 29, 28, 27, 25, 
103, 102, 100, 98, 97, 96, 93, 91, 88, 86, 83, 80, 76, 73, 69, 65, 61, 57, 54, 50, 46, 44, 41, 38, 36, 33, 32, 29, 28, 26, 24, 24, 
105, 103, 102, 100, 99, 97, 96, 93, 91, 88, 85, 81, 78, 73, 69, 66, 61, 57, 53, 49, 45, 41, 39, 36, 34, 32, 29, 27, 26, 24, 23, 22, 
107, 105, 104, 103, 101, 100, 98, 96, 93, 90, 86, 83, 79, 75, 71, 66, 61, 56, 51, 47, 44, 40, 36, 34, 32, 29, 27, 25, 24, 22, 21, 19, 
109, 108, 106, 105, 103, 102, 100, 98, 96, 92, 89, 85, 81, 76, 71, 66, 61, 55, 50, 45, 41, 37, 34, 32, 29, 27, 24, 23, 21, 20, 19, 17, 
111, 110, 109, 108, 106, 105, 103, 100, 98, 96, 92, 88, 83, 78, 72, 66, 60, 54, 48, 43, 39, 34, 32, 28, 26, 24, 22, 20, 19, 17, 17, 15, 
113, 113, 111, 110, 109, 108, 105, 104, 101, 98, 96, 91, 86, 81, 74, 67, 59, 52, 46, 40, 35, 32, 28, 25, 22, 21, 19, 17, 16, 15, 14, 13, 
115, 115, 114, 113, 112, 110, 109, 108, 105, 103, 99, 96, 90, 84, 76, 68, 59, 50, 42, 36, 32, 27, 24, 21, 19, 17, 16, 14, 13, 12, 12, 11, 
118, 118, 117, 116, 115, 114, 113, 111, 109, 107, 104, 100, 96, 88, 80, 69, 57, 46, 38, 32, 26, 22, 19, 17, 15, 14, 12, 11, 10, 9, 9, 8, 
120, 120, 120, 119, 118, 118, 117, 115, 114, 112, 110, 106, 102, 96, 85, 71, 55, 41, 32, 24, 20, 17, 14, 12, 11, 9, 9, 8, 7, 7, 6, 6, 
123, 123, 123, 123, 122, 121, 121, 120, 119, 118, 116, 114, 110, 105, 96, 76, 50, 32, 21, 16, 12, 10, 8, 7, 7, 5, 5, 4, 4, 4, 3, 3, 
126, 126, 125, 125, 125, 125, 125, 125, 125, 124, 123, 123, 121, 119, 114, 96, 32, 12, 7, 5, 4, 3, 2, 2, 2, 2, 1, 1, 1, 1, 0, 0, 
128, 128, 129, 129, 129, 129, 130, 130, 130, 130, 131, 132, 133, 135, 140, 160, 224, 242, 247, 249, 251, 251, 252, 253, 253, 253, 253, 253, 253, 253, 254, 254, 
131, 131, 132, 132, 132, 133, 133, 135, 135, 136, 138, 140, 144, 149, 160, 178, 204, 224, 233, 238, 242, 244, 246, 247, 248, 249, 249, 250, 251, 251, 251, 251, 
134, 134, 135, 135, 136, 137, 137, 139, 140, 142, 145, 148, 152, 160, 169, 183, 199, 213, 224, 230, 234, 238, 240, 242, 243, 245, 246, 246, 247, 248, 248, 248, 
136, 137, 137, 138, 139, 140, 142, 143, 145, 147, 150, 154, 160, 166, 174, 185, 197, 208, 216, 224, 228, 232, 235, 237, 239, 241, 242, 243, 244, 245, 246, 246, 
139, 140, 140, 141, 142, 144, 145, 147, 149, 152, 155, 160, 164, 170, 178, 187, 196, 204, 212, 218, 224, 227, 231, 233, 236, 237, 238, 240, 241, 242, 243, 243, 
141, 142, 143, 144, 145, 147, 149, 150, 153, 156, 160, 163, 168, 174, 180, 187, 195, 202, 209, 214, 219, 224, 226, 229, 232, 233, 236, 237, 238, 239, 241, 241, 
143, 145, 145, 147, 148, 150, 152, 154, 156, 160, 162, 167, 171, 176, 182, 188, 194, 200, 206, 211, 216, 220, 224, 226, 228, 231, 233, 234, 236, 237, 238, 239, 
145, 147, 148, 149, 151, 152, 155, 157, 160, 162, 165, 169, 173, 178, 183, 189, 194, 199, 204, 209, 213, 217, 220, 224, 226, 228, 230, 231, 233, 234, 236, 237, 
147, 149, 150, 152, 153, 155, 157, 160, 162, 164, 168, 172, 175, 179, 184, 189, 194, 199, 203, 207, 211, 214, 218, 221, 224, 226, 228, 229, 231, 232, 233, 235, 
150, 151, 152, 154, 155, 157, 160, 162, 164, 167, 169, 173, 177, 181, 185, 189, 194, 197, 201, 206, 209, 213, 216, 219, 221, 224, 225, 227, 228, 230, 231, 233, 
152, 152, 154, 156, 157, 160, 161, 164, 166, 169, 172, 174, 178, 182, 185, 189, 193, 197, 201, 204, 208, 211, 214, 216, 219, 221, 224, 225, 226, 228, 230, 231, 
153, 155, 156, 157, 160, 161, 163, 165, 167, 170, 173, 176, 179, 182, 186, 189, 193, 196, 200, 203, 206, 209, 212, 215, 217, 219, 221, 224, 225, 226, 228, 229, 
155, 156, 157, 160, 161, 162, 164, 167, 169, 172, 174, 177, 180, 183, 187, 189, 193, 196, 199, 202, 205, 208, 211, 213, 216, 218, 220, 221, 224, 225, 226, 228, 
157, 157, 160, 161, 162, 164, 166, 168, 170, 173, 175, 178, 181, 184, 187, 189, 193, 196, 199, 201, 204, 207, 209, 212, 214, 216, 218, 220, 221, 224, 225, 226, 
158, 160, 161, 162, 164, 166, 167, 169, 172, 174, 177, 179, 182, 184, 187, 190, 192, 195, 198, 201, 204, 206, 209, 211, 213, 215, 216, 219, 220, 221, 224, 224, 
160, 160, 162, 164, 165, 167, 169, 171, 173, 175, 177, 179, 182, 184, 187, 190, 192, 195, 198, 200, 203, 205, 207, 209, 211, 214, 216, 217, 219, 221, 222, 224 }; 

// Trig shit. 
// Sine / cosine table, using the obvious gimmick of a 90-degree offset to overlap them. 
/* JS: 
JSON.stringify( 
	new Array( 256 * 1.5 )
		.fill(0).map( (v,i,a) => Math.floor( 
			127 * Math.cos( Math.PI * i / 256.0 ) 
		) ) 
).split(',').join(', ')
*/
/*
const int8_t cos[] = 
{ 127, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 125, 125, 125, 125, 124, 124, 124, 123, 123, 123, 122, 122, 121, 121, 121, 120, 120, 119, 119, 118, 117, 117, 116, 116, 115, 114, 114, 113, 112, 112, 111, 110, 109, 108, 108, 107, 106, 105, 104, 103, 102, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 91, 90, 89, 88, 87, 86, 85, 84, 82, 81, 80, 79, 78, 76, 75, 74, 73, 71, 70, 69, 67, 66, 65, 63, 62, 61, 59, 58, 57, 55, 54, 52, 51, 50, 48, 47, 45, 44, 42, 41, 39, 38, 36, 35, 33, 32, 30, 29, 27, 26, 24, 23, 21, 20, 18, 17, 15, 13, 12, 10, 9, 7, 6, 4, 3, 1, 0, -2, -4, -5, -7, -8, -10, -11, -13, -14, -16, -18, -19, -21, -22, -24, -25, -27, -28, -30, -31, -33, -34, -36, -37, -39, -40, -42, -43, -45, -46, -48, -49, -51, -52, -53, -55, -56, -58, -59, -60, -62, -63, -64, -66, -67, -68, -70, -71, -72, -74, -75, -76, -77, -79, -80, -81, -82, -83, -85, -86, -87, -88, -89, -90, -91, -92, -94, -95, -96, -97, -98, -99, -100, -101, -102, -103, -103, -104, -105, -106, -107, -108, -109, -109, -110, -111, -112, -113, -113, -114, -115, -115, -116, -117, -117, -118, -118, -119, -120, -120, -121, -121, -122, -122, -122, -123, -123, -124, -124, -124, -125, -125, -125, -126, -126, -126, -126, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -125, -125, -125, -124, -124, -124, -123, -123, -122, -122, -122, -121, -121, -120, -120, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -113, -112, -111, -110, -109, -109, -108, -107, -106, -105, -104, -103, -103, -102, -101, -100, -99, -98, -97, -96, -95, -94, -92, -91, -90, -89, -88, -87, -86, -85, -83, -82, -81, -80, -79, -77, -76, -75, -74, -72, -71, -70, -68, -67, -66, -64, -63, -62, -60, -59, -58, -56, -55, -53, -52, -51, -49, -48, -46, -45, -43, -42, -40, -39, -37, -36, -34, -33, -31, -30, -28, -27, -25, -24, -22, -21, -19, -18, -16, -14, -13, -11, -10, -8, -7, -5, -4, -2 }; 

const int8_t* sin = &cos[ 128 ]; 
*/

// Precomputed division table, because that is weirdly expensive.
// May not get used - but like trig, it's come up enough to include, just in case. 
/*
const uint8_t divide256by[] = 
// Rounding down:
// JSON.stringify( new Array( 256 ).fill(0).map( (v,i,a) => Math.floor( -0.5 + 256 / i ) ) ).split(',').join(', ');
{ 255, 255, 127, 84, 63, 50, 42, 36, 31, 27, 25, 22, 20, 19, 17, 16, 15, 14, 13, 12, 12, 11, 11, 10, 10, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
*/

// Big dumb table(s) for sprite origins. 
// Got it down to one: quadrants are mirrored, and one quarter-turn of cosine is sine's quarter-turn, backwards. 
// Bizarrely, the limiting factor is syntax highlighting for this fat nested array literal. 
/*
JSON.stringify( 
new Array( angle_count = 16 ).fill(0).map( (v,angle,a) => 
new Array( distance_count = 64 ).fill(0).map( (value,distance,arr) => Math.floor( 
8.0 * ( 32.0 / 20.0 ) * 127.0 / ( 256.0 * ( 1.0 - ( ( distance + distance_count ) / (2*distance_count) ) ) )
* Math.sin( angle / angle_count * 0.5*Math.PI )
) ) ) 
).replace( /,/g, ', ' ).replace( /\[/g, '{' ).replace( /\]/g, '}' )

JSON.stringify( 
new Array( angle_count = 16 ).fill(0).map( (v,angle,a) => 
new Array( distance_count = 64 ).fill(0).map( (value,distance,arr) => Math.floor( 
8.0 * ( 32.0 / 20.0 ) * 127.0 / ( 256.0 * ( 1.0 - ( ( distance + distance_count ) / (2*distance_count) ) ) )
* Math.sin( angle / angle_count * 0.5*Math.PI )
) ).map( v => v > 127 ? 127 : v ) ) 
).replace( /,/g, ', ' ).replace( /\[/g, '{' ).replace( /\]/g, '}' )
// This is still the tiniest bit off and it's going to drive me crazy if I don't move on. 
*/
const int8_t sin_from_polar[ 16 ][ 64 ] = 
// 16x64 angle x distance
{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 6, 6, 7, 7, 8, 9, 11, 13, 15, 19, 26, 39, 79}, {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 8, 8, 9, 9, 10, 11, 12, 13, 14, 15, 17, 19, 22, 26, 31, 39, 52, 79, 127}, {3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 11, 11, 12, 13, 13, 14, 15, 16, 18, 19, 21, 23, 26, 29, 33, 39, 47, 58, 78, 117, 127}, {4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 13, 14, 14, 15, 16, 17, 18, 19, 20, 22, 23, 25, 28, 31, 34, 38, 44, 51, 62, 77, 103, 127, 127}, {5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 27, 29, 31, 34, 38, 42, 47, 54, 63, 76, 95, 127, 127, 127}, {7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 18, 18, 19, 20, 21, 22, 23, 25, 26, 28, 30, 32, 34, 37, 41, 45, 50, 56, 64, 75, 90, 112, 127, 127, 127}, {8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 19, 19, 20, 21, 22, 23, 24, 25, 27, 28, 30, 32, 34, 36, 39, 42, 46, 51, 57, 64, 73, 85, 103, 127, 127, 127, 127}, {8, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 17, 17, 18, 19, 19, 20, 21, 22, 22, 23, 24, 26, 27, 28, 30, 31, 33, 35, 38, 41, 44, 47, 52, 57, 63, 71, 82, 95, 114, 127, 127, 127, 127}, {9, 9, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 15, 15, 16, 16, 16, 17, 17, 18, 19, 19, 20, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 34, 36, 39, 41, 44, 48, 52, 57, 62, 69, 78, 89, 104, 125, 127, 127, 127, 127}, {10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 24, 25, 25, 27, 28, 29, 30, 32, 33, 35, 37, 39, 42, 45, 48, 51, 56, 61, 67, 75, 84, 96, 112, 127, 127, 127, 127, 127}, {11, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 23, 24, 25, 26, 27, 28, 29, 31, 32, 34, 35, 37, 39, 42, 44, 47, 51, 55, 59, 65, 71, 79, 89, 102, 119, 127, 127, 127, 127, 127}, {11, 11, 12, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 15, 15, 15, 15, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 20, 21, 22, 22, 23, 24, 25, 25, 26, 27, 28, 30, 31, 32, 34, 35, 37, 39, 41, 44, 46, 50, 53, 57, 62, 68, 75, 83, 93, 107, 125, 127, 127, 127, 127, 127}, {12, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20, 21, 21, 22, 22, 23, 24, 25, 25, 26, 27, 28, 29, 31, 32, 33, 35, 37, 38, 40, 43, 45, 48, 51, 55, 59, 64, 70, 77, 86, 97, 111, 127, 127, 127, 127, 127, 127}, {12, 12, 12, 13, 13, 13, 13, 13, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20, 20, 21, 22, 22, 23, 24, 24, 25, 26, 27, 28, 29, 30, 31, 33, 34, 36, 37, 39, 41, 44, 46, 49, 53, 56, 61, 66, 72, 79, 88, 99, 113, 127, 127, 127, 127, 127, 127}, {12, 12, 13, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 23, 23, 24, 25, 26, 26, 27, 28, 29, 31, 32, 33, 35, 36, 38, 40, 42, 44, 47, 50, 53, 57, 62, 67, 73, 80, 89, 101, 115, 127, 127, 127, 127, 127, 127}};



// Sprite data

/* 
I fucking hate dealing with bitmasks in hex, but binary is so verbose. 

0000 = 0
0001 = 1
0010 = 2
0011 = 3

0100 = 4
0101 = 5
0110 = 6
0111 = 7

1000 = 8
1001 = 9
1010 = A
1011 = B

1100 = C
1101 = D
1110 = E
1111 = F

*/

const unsigned char gradient_data[] = { 

	/* 0xFF to 0x00, presumably white to black */
	/* 0b1010 = A, 0b0101 = 5 */
	// Black. Black / dark. Dark. Dark / light. Light. Light / white. White. 
	// Currently have 13 colors via simple dithering in 4-pixel patterns. Need a few more for easy power-of-two 16. 
	// Could just stuff some duplicate darks in there, for later? Dark is probably where we want more detail. 

	// BB/BB
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, 		// Black: 1/1

	// BB/BD
	0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 0xFF, 0xFF, 0x77, 0xFF, 0xFF, 0xFF, 0xDD, 0xFF, 		// Pips
	0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 0xFF, 0xFF, 0xAA, 0xFF, 		// BB/BB

	// BD/BD
	// B is 1/1, D is 0/1
	0b01010101, 0xFF, 
	0b11101110, 0xFF, 
	0b01010101, 0xFF, 
	0b10111011, 0xFF,

	0b01010101, 0xFF, 
	0b11101110, 0xFF,
	0b01010101, 0xFF, 
	0b10111011, 0xFF,
	0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 0x55, 0xFF, 0xAA, 0xFF, 		// BD/BD 

	// BD/DD
/*
0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 

0x15, 0xFF, 
0x8A, 0xFF, 
0x51, 0xFF, 
0xA8, 0xFF, 
*/
	0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 0x55, 0xFF, 0x00,0xFF, 		// BD/DD 

	// DDDD DDDD / BDDD BDDD / DDDD DDDD / DDBD DDBD 
	// Or should it be DDDB / DBDD? Argh. 
	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF, 

	0x00, 0xFF, 
	0b00010001, 0xFF, 
	0x00, 0xFF, 
	0b01000100, 0xFF,  

	// DD/DD
	0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF, 		// Dark: 0/1

	// DD/DL
	0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,0x00,0xFF, 0x55, 0xAA,

	// DL/DL
	0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA,  	// 0/1 + 1/0 

	// DL/LL
	0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 0xAA, 0x55, 0xFF, 0x00, 

	// LL/LL
	0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00, 		// Light: 1/0

	// LL/LW
	0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 0xFF, 0x00, 0xAA, 0x00, 

	// LW/LW
	0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 	// 1/0 + 0/0

	// LW/WW
	0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 

	// WW/WW
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 		// White: 0/0
	// This needs to not go white-white.
	// Good answers? Dunno. Just mix with black for now. 

//	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 		// W			uint8_t hit = 0; e again

	// BW/BW
	0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA, 0x55, 0x55, 0xAA, 0xAA 
		// Black+white

};

#endif



// Interrupt functions

uint8_t sy = 0; 

// Input buffer(s) & book-keeping 
uint8_t joy_buffer[ 32 ]; 		// Two 15-frame buffers. Elements 0 and 16 are length counters. 
uint8_t jb_offset = 0; 		// 0 or 16. (Or I guess 1 or 17.) 
uint8_t last_input = 0; 		// Guess I only need one length counter, since field_count will match. Tolerable jank. 

void hud_isr() { 
	HIDE_SPRITES; 
} 

void my_vblank_isr() { 
//	LYC_REG = 1; 
//	SCY_REG = 0; 		// Stop doing this if we're not fucking with tilemap compression. 
//	SCX_REG = -16; 
//	sy = 1; 

	// Vsync frame swap, if applicable:
	// SCX_REG = scx; 
	// SCY_REG = scy; 
	// Swap BG0 / BG1 for the main tilemap. (Window is always BG1.) 

	// Enable sprites, since we turn them off over the HUD. 
	SHOW_SPRITES; 

	line_count += 144; 		// FPS tracking. Not 154 because the scanline version doesn't count vblank. 
	line_count += 10; 		// Account for all scanlines. Probably. Might be missing a few anyway. 

	// Take input from joystick(), add it to some input-buffer array, and increment array counter. 
	if( last_input < 16 ) { 
		joy_buffer[ jb_offset + last_input ] = joypad(); 
		last_input++; 
	} 

}


// Globals as fake arguments for draw_tile 
//uint8_t x, y, xplus;
int8_t x, y, xplus;  
int8_t bend_x = 0; 
int8_t bend_y = 0; 

void draw_tile();
void debug_output( uint8_t variable, uint8_t xpos, uint8_t ypos );

void place_sprite( uint8_t object, uint8_t properties, uint8_t graphic, uint8_t x, uint8_t y ); 

int8_t j = 0; 
//void object_collision( uint8_t j );
//void object_collision( ); 
uint8_t object_collision( uint8_t j ); 

void is_obstacle_close( ); 









const uint8_t rotation_to_side[ 32 ] = { 
	// Shift:
//	0, 0, 0, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 1, 1, 1, 		// 0..15 - 3-5-5-3
//	1, 1, 1, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 0, 0, 0			// -16..-1, two's complement

	// Divide and subtract: 
	1, 1, 1, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 0, 0, 0,			// -16..-1, two's complement
	0, 0, 0, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 1, 1, 1 		// 0..15 - 3-5-5-3
};

const int8_t side_gravity[ 12 ] = { 
	0, 0, -4, 4, -24, 24, 		// Bottom, top, lower right, lower left, upper right, upper left. 
	0, 0, 0, 0, 0, 0		// No gravity when pressing B. 
};

const int8_t side_friction[ 12 ] = {
	// Bottom, top, lower right, lower left, upper right, upper left. 
	2, 0, 2, 2, 2, 2, 		// No friction on top
	4, 0, 4, 4, 2, 2 			// B doubles friction along the bottom
};



// Main functionality 

void main() {
	printf( "Loading..." ); // Need a printf for GBDK to include text characters. 

	// Load tile data to CHR-RAM
	set_bkg_data(0x00, 0x08, gradient_data);
	set_bkg_data(128, 128, gradient_data); 		// Overlaps with sprite data. 

	// Sprite data, nonsense for now 
	// 40 hardware sprites. 10 per line. Worth remembering. 
	set_sprite_data( 128, 128, gradient_data ); 		// [ BG tiles { BG & Sprite tiles ] Sprite tiles } - so sprite's 0 = BG's 128. 

	// 64-sprite array for 40 sprites, so we can go over by a fair amount and not clobber nearby memory. 
	// The alternative is losing potentially 15 sprites by checking free_sprite<40-16 before drawing another obstacle. 
	// This does not, as such, work. Poo. 
	SET_SHADOW_OAM_ADDRESS( &sprite_array ); 

	SHOW_SPRITES; 
	SPRITES_8x16; 		// We need this so 4x4 sprites take 8 slots instead of 16. 

	// Fill tube_color because division by six is weirdly expensive. 
	// "Anything that only happens once is free."
	// Oddly difficult to get a loop of 256. 
	// tube_color[] may remain variable so that we can fuck with it. 
		// Though we could just declare 'int8_t* tube' and point it at e.g. tube_type[8][256]. 
		// Probably better to just use two and amortize the next one while using this one. Do one entry per frame. 
	const uint8_t sides[] = { 2, 0, 1, 2, 3, 4, 2, 0 }; 		// 8 instead of 6 because modulo is acting weird. 
	for( uint8_t n = 255; n > 0; n-- ) { 		// Divide into sixths. 
		const uint8_t side = n / 43 + 1; 	// To simplify dealing with non-uniform gradients. 
		tube_color[n] = sides[ side ]; 		// 0..5. 6*43 is 258. 

		// Faux subsampling? 0..5 x2 -> 0..10, and use an in-between color right near the boundary. 
		// "Anti-aliasing." Three colors per side, or just two? Three fits but may be overkill. 
		// Keep dead code for now; we're gonna mix things up during play. 
		tube_color[n] *= 2; 
//		if( n % 43 > 40 ) { tube_color[n]++; } 
//		if( n % 43 < 2 ) { tube_color[n]--; } 
		// Wow, that's nice. 
//		if( n % 43 > 40 ) { tube_color[n] += sides[ ( side + 1 ) % 6 ]; tube_color[n] /= 2; } 
//		if( n % 43 < 2 ) { tube_color[n] += sides[ ( side - 1 ) % 6 ]; tube_color[n] /= 2; } 
		if( n % 43 > 40 ) { 		// Why is anti-aliasing uneven? This is only 41, 42, but the other's only 0, 1. 
											// The bottom facet's diagonals are noticeably askew. 
											// ... maybe just because it's 4->2 instead of 3? Ehh, not really.  
			if( sides[ side + 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}
		else if( n % 43 < 2 ) { 
			if( sides[ side - 1 ] > sides[ side ] ) { tube_color[n]++; } 
			else { tube_color[n]--; } 
		}

		// Anti-aliasing should be swapped out almost entirely for diagonals. 
		// Not exactly fixed tile values, because of rotation, but: a bit flag and two-ish colors. 
		// Picking the right angled graphical tile from CHR-RAM is the drawing routine's problem. 

		// This setup loop should also handle most of the tube-color stuff. 
		// So e.g. add 3 to every thing for a fairly naive sawtooth gradient that looks about right. 
		// But ideally I'd like to make the bottom white(ish), the upper-right dark, 
			// and the lower-right about as dim as the upper-left. 
		tube_color[n] += 3; 

		tube_color[n] += 128; 		// Tiles in the middle. (Letters at the front.) 
			// I could use a bit to indicate boundaries.
			// Really I could use several, we're only encoding 16 shades so far. 
			// Masking is cheap and it'd let us substitute rotation-aware diagonals. 
	}
	// Then set tube_color[0] if it's not supposed to be black. 
	tube_color[0] = tube_color[1]; 		// Easy hack. 

	// Compression to 4-scanline-high tiles has tolerable performance impact. 
	// It's rendering all those tiles that kills us. 
	// We might go for diagonal tiles and skip scanline shenanigans altogether. 
	// In which case: we do still need VBL_IFLAG. (Or is that just for wait_vbl_done?) 
	// VBL is back so we can disable sprites over the HUD. 
	CRITICAL {
		STAT_REG |= 0b01000000; LYC_REG = 0;
		LYC_REG = 144 - 16; 		// HUD
//		add_LCD( half_tile_isr );
		add_LCD( hud_isr );
		add_VBL( my_vblank_isr ); 		// Two hard problems. 
		set_interrupts( VBL_IFLAG | LCD_IFLAG );
//		set_interrupts( VBL_IFLAG );
	}

	// FPS / HUD - using window 
	init_win( 6 ); 
	move_win( 7, 128 ); 		// Coordinates start one tile/sprite offscreen. (144-16) throws a warning. Shrug. 
	SHOW_WIN; 		// Equivalent to LCDC_REG|=0x20U 

	// Initial game state
	// Distance-based changes to the tube, indicating curves. 
	twist_factor = 0; 		// -4..4 or thereabouts. 
//	twist_degree = 1; 		// Basically 4 - abs( twist_factor ), whose sign chooses between rotation+= or -=. 

	int8_t pan_x = 0; 		// Debug - nope, now a nudge value for collision effect
	int8_t pan_y = 0; 

	uint8_t speed_accumulator = 0; 
	uint8_t move_speed = 10; 		

	// Jank first-whack track bend variable. 
	int8_t curve_state = 0; 		// Desired twist_factor to adjust toward. 
	int8_t curve_twist_counter = 5; 		// Physics frames (60 Hz-ish) between changes to twist_factor. 

	// Centripital frame of reference, temporarily added / subtracted from rotation. 
	int8_t tilt = 0; 

	// Gameplay loop.

	// Make it work - make it fast - make it pretty. In that order. 
	while ( 1 ) {

		// New random obstacles - probably shouldn't go here - fits better after rendering
		// Does this for loop impact performance? Not really. 
		for( int8_t k = 0; k < 20; k++ ) { 
			if( ! obstacles[ k ].type ) { 		// Fill empty obstacles
				obstacles[ k ].type = 1; 	
				obstacles[ k ].location =  scroller_x + 128 + 6*k; 		// Just stick 'em way out there.  
				obstacles[ k ].orientation = 30*k;		// Should be more random. 
			}
		}

		// Input
		// joypad() reads get buffered by the vblank ISR. It's always 60 Hz even when rendering is crap. 
		// ... y'know, I could just do this IN the vblank ISR. It should be pretty quick. 
		// We only have one scanline interrupt and it's at the bottom. 
		// Downside of physics in ISR: might impact rendering mid-render. Mixed bag.
		const uint8_t jb_backbuffer = jb_offset; 		// Whoops, grab this first. 
		jb_offset ^= 16; 		// 32-element array, offset by half or zero. 
		last_input = 0; 		// Non-cleared variable-length buffer. (See vblank ISR.) 

		// Controls & Physics
		for( int8_t rounds = field_count; rounds > 0; rounds-- ) { 		// Not "tics" because I keep typing "ticks". 

//			uint8_t input = *joy_buffer[ field_count - rounds ]; 
//			if( field_count - rounds > 16 ) { input == 0; } 

			uint8_t input = joy_buffer[ jb_backbuffer + field_count - rounds ]; 
			if( field_count - rounds > 16 ) { input = 0; } 		// Safety check: no spurious input data. 






			// Physics values have a fixed-point factor of 8. 
			// They're signed, so we only have seven bits, and it's easy to overflow by throwing 32s around. 

/*
			int8_t tilt = 0; 
			tilt = 16 * twist_factor; 
				// twist_factor goes from -4..4. We want, what, 90 degrees at most? 256 / 4 = 64. 64 / 4 = 16. 
				// 16 * twist_factor is alright, but it should probably be a touch lower than that. 
				// 16 lets you go over just by holding one direction. 12 does not. A touch of B will do it, though. 
				// Does it only happen at 16 exactly? 14 will do it. 
				// Ah fuck, it doesn't re-center properly. But it does for 16? Not 14. It does for 12. Bizarre. 
				// Y'know what, stick with 16, because it'll only be that severe with a full curve of +/- 4. 
				// Smaller curves and tilts will also appear, so you can't just always go over. 
				// Or: you can't just always go over, for free. Because there's always the B button and its presumed cost. 
			rotation += tilt; 
				// This could be amortized across frames. It doesn't always update. 
*/
			// Got moved down to physics. 


			// Physics
/*
			if( ! ( input & ( J_LEFT | J_RIGHT ) ) ) { rotation_impulse = 0; } 		// The added force drops to zero instantly. 
			else { 
				if( input & J_LEFT ) { 
					rotation_impulse = -16; 
				} 
				else if( input & J_RIGHT ) { 		// Technically can't have both at once. (Physically prevented.) 
					rotation_impulse = 16; 
				} 
			}
			if( input & J_B ) { rotation_impulse /= 2; } 			// Slow down movement if pressing B. 
			velocity += rotation_impulse; 
*/

			// Accelerate left or right - less, when pressing B. 
			if( input & ( J_LEFT | J_RIGHT ) ) { 
				rotation_impulse = 16; 
				if( input & J_B ) { rotation_impulse = rotation_impulse >> 1; } 
				if( input & J_LEFT ) { rotation_impulse = -rotation_impulse; }
				velocity += rotation_impulse; 
			}




#if 0
			// Fucky controls when upside-down, with very little else going on, suggests "side" is broken. 
			// Do I need a table just to bin rotations to six fucking regions? 

			//    1
			// 2     0
			// 3     5
			//    4
//			uint8_t side; 

			// Get it right now, make it fast later. 
			if( rotation > 0 ) { 
				if( rotation < 22 ) { side = 4; } 
				else if( rotation < 22 + 43 ) { side = 5; }
				else if( rotation < 127 - 22 ) { side = 0; }
				else { side = 1; } 
			} else { 
				if( rotation > -22 ) { side = 4; } 
				else if( rotation > -( 22 + 43 ) ) { side = 3; }
				else if( rotation > -( 127 - 22 ) ) { side = 2; }
				else { side = 1; } 
			} 

			// Two's-complement wraps to all ones when you go below zero. 

//			side = tube_color[ rotation ]; 		
				// Aaalmost makes sense. You'd have to adjust the answer... and 0 doesn't work right. 
			// Really we could just have a 16-element lookup. 

			// side is only used in sliding force... and technically friction. 
			// "Technically" because it'd be easy enough to test abs(rotation) for sides 4 and 1. 
			// And the 'double friction on the bottom, when holding B' could apply everywhere. 

			// Possibly have entirely separate physics for "smooth" sections, 
				// like the tube changes to a plain gradient and you can suddenly go over. Only there. 
			// Bottom section may otherwise have strong friction. (Eh.) 

			// Being up the right side and pushing left causes you to stop in place. What. 
				// Does it overflow? 
				// Ugh, even with lower friction, getting up high and pressing down gives you hangtime. 
				// That is the opposite of what you expect. 
				// It happens at the edge, so it could be excused, but I'd rather just fix it. 
			// And it's still so very squirrelly. 
				// velocity / 32 instead of /16? Same math, half the speed. Oh yeah. Much better. 
			// How the fuck does it still get stuck?
				// Not an issue with n-=a+b, thank goodness. 
				// I don't -think- I've fucked up which side is which, since you still go down properly, further up. 
				// It is a very specific angle - some intermediate color has to be visible in front of the player sprite. 
				// Is it just getting the side wrong? Again, shouldn't be a thing, since that's all if-else. 
				// Side displays as expected - you're in side zero when stuck. (I.e., holding down, staying up.) 
				// Does it underflow? -48 + -32 is -80, well within -127..127. Coincidentally equal to MAX_VELOCITY. 
				// MAX_VELOCITY is only tested greater-than or less-than and sets velocity directly. 
				// Is it friction? It fucking shouldn't be, since rotation happens before that. 
				// Okay, it happens anywhere on e.g. side 0. 
			// Velocity gets up to 100 when going across the bottom facet. 
				// Because rotation_impulse gets added on, every frame. 
				// Which obviously puts us in range of overflowing. For fuck's sake. 
				// Simple-ish answer: divide everything by 2. 
			// This should be a very small table. 
			if( side != 4 && ! ( input & J_B ) ) { 		// Off the flat bottom, B not pressed

				// Lower sides
				if( side == 3 ) { velocity += 4; } 
				if( side == 5 ) { velocity -= 4; } 

				// Upper sides
				if( side == 2 ) { velocity += 16+8; } 
				if( side == 0 ) { velocity -= 16+8; } 

			} 

//			debug_output( abs( velocity ), 6, 0 ); 		// Weirdly strong performance hit. 

			#define MAX_VELOCITY 40
			if( velocity < -MAX_VELOCITY ) { velocity = -MAX_VELOCITY; } 
			else if( velocity > MAX_VELOCITY ) { velocity = MAX_VELOCITY; } 

			// I switched to fixed-point and then did almost nothing with it. 
			// Should this be dithered? I.e., add some pseudorandom value, -then- reduce to a small integer. 
			rotation += velocity / 16; 

			// Jank-ass basic controls for testing graphics: 
//			if( input & J_LEFT ) { rotation -= 1; } 
//			if( input & J_RIGHT ) { rotation += 1; } 

			// Friction AFTER movement, so I can add 1 and not get instantly zeroed out. 
			int8_t friction = 2; 
			if( side == 1 ) { friction = 0; } 		// No friction at the top - barely any contact. 
			if( side > 2  && ( input & J_B ) ) { friction += friction; } 		// Jet at the bottom? Double friction. 
			if( ! controls_locked ) { 
				if( velocity > 0 ) { 
					velocity -= friction; 
					if( velocity < 0 ) { velocity = 0; } 
				} 
				if( velocity < 0 ) { 
					velocity += friction; 
					if( velocity > 0 ) { velocity = 0; } 
				} 
			} 



#else

/*
			// I can label "sides" whichever values I want. 
			uint8_t side; 
			int8_t absrotation = abs( rotation ); 
			if( absrotation < 22 ) { side = 0; } 		// Bottom 
			else if( absrotation > 127 - 22 ) { side = 1; } 		// Top 
			else {
				if( absrotation < 22+43 ) { side = 2; } else { side = 4; } 		// Lower, else upper
				if( rotation < 0 ) { side++; } 		// Lefthand side
			}
			// New arbitrary "side" arrangement:
			//    1
			// 5     4
			// 3     2
			//    0
*/

			// Change frame of reference before doing physics. 
			rotation += tilt; 

			uint8_t side = rotation_to_side[ ( ( rotation / 8 ) + 16 ) ];
//			uint8_t side = rotation_to_side[ rotation >> 3 ];  
				// Shifting unsigned numbers is fucky even when you try to account for it. 

			// And then gravity / friction should be unconditional reads froma 6- or 12-element array. 
			if( input & J_B ) { side += 6; } 


			
			velocity += side_gravity[ side ]; 

//			debug_output( abs( velocity ), 6, 0 ); 		// Honest to god, this is a huge performance hit. Bluh. 

			#define MAX_VELOCITY 40
			if( velocity < -MAX_VELOCITY ) { velocity = -MAX_VELOCITY; } 
			else if( velocity > MAX_VELOCITY ) { velocity = MAX_VELOCITY; } 

			rotation += velocity / 16; 



			if( velocity > 0 ) { 
				velocity -= side_friction[ side ]; 
				if( velocity < 0 ) { velocity = 0; } 
			} else { 
				velocity += side_friction[ side ]; 
				if( velocity > 0 ) { velocity = 0; } 
			} 

			// if( abs( velocity ) < friction? ) 

#endif

			// You can only move between adjacent sides. (Nope, that'd be slower than using an array.) 

			// Undo rotation tilt from curve physics - pointedly -inside- the physics loop. 
				// Otherwise we'd apply tilt several times (sometimes while the curve changes) and then undo it once. 
			// Oops, probably want to undo this before testing collision. 
			rotation -= tilt; 





			// scroller_x++ stuff should go here, with an early "continue" otherwise. 


			// I guess just... don't increment scroller_x? And so ignore physics, even if you just slid sideways
				// into an obstacle. "Rubbing is racing." 
			// Dunno if we should still do curve_twist_counter stuff in that case. 
				// Probably not: static curve, variable motion through it. 

			// Proper fixed-point accumulator. 
			// Oh, that's smooth. 

			// Debug: disable automatic scrolling so I can fine-tune twisting displacement. 

			// Forward "scroll" speed needs to be somewhere between 30 and 60 units per second. 
			// 60 is entirely too fast for how far we draw sprites. 30 is just... sedate. 
			// So do we do retest physics when there's no motion? 

			// This has worse performance because we run more rounds. 
			// Might move it further down so we can enact controls but skip physics (or at least collision) 
				// onrounds where we don't advance scroller_x. 
			// Or: 30 Hz controls. 

			speed_accumulator += move_speed; 
			if( speed_accumulator >> 4 == 0 ) { continue; } 
			scroller_x += speed_accumulator >> 4; 		// Add integer portion. Should always be 0 or 1. Should. 
				// Accidentally works up to a lot more than 0 or 1. Dunno if collision handles that well. 
				// Anything more than 60 Hz would be really goddamn twitchy even at 60 FPS. 
			speed_accumulator &= 0x0F; 		// Only keep fractional portion. 

			// Curve / twist / bend handling. 
			// Debug: straight, for benchmarking sprite stuff. 
			// Curve testing: bend back and forth whenever we loop scroller_x. Every 6 seconds or so. 
			// Is this getting overwritten or something? We keep going back and forth at random, now. 
			if( scroller_x == 0 ) { 
				if( curve_state == 0 ) { curve_state = 4; } 
				else if( curve_state == 4 ) { curve_state = -4; } 
				else { curve_state = 0; } 
			} 

			// Gradually align twist state to the curve we're supposed to be in. 
			if( twist_factor != curve_state ) { 
				curve_twist_counter--; 
				if( curve_twist_counter == 0 ) { 
					if( twist_factor < curve_state ) { twist_factor++; } 
					else { twist_factor--; } 		// No need to check equality. 
					curve_twist_counter = 5; 		// Arbitrary guess. 5 was decent, 15 sucks, 10... no strong opinion. 
						// Honestly the ideal is that I can make the curve start and stop at specific distances, 
							// so it's a real thing you approach and then exit. 
				} 

				// Frame of reference can only change when twist_factor changes. 
				// (Though we do modify rotation back and forth every frame.) 
				tilt = 16 * twist_factor; 
			} 


			if( obstacles_on ) { 		// Debug option - enable / disable obstacles, for benchmarking

			// Collision for obstacles
			// Oh, we can probably stop doing collision once you get hit. 
			// The player should mmmaybe still get thrown around. 
			// Or we might be absolutely merciless and have no i-frames.
				// (In which case we'd need to mark obstacles as having-been-hit, so you don't Megaman 1 yourself.)
/*
			for( int8_t j = 0; j < MAX_OBSTACLES && !hit; ) 	{ 		// Add !hit to exit condition, after benchmarking this unroll. 
				object_collision( j ); j++; 		// 32 obstacles, 4 groups of 8. 
				object_collision( j ); j++; 
				object_collision( j ); j++; 
				object_collision( j ); j++; 

				object_collision( j ); j++; 
				object_collision( j ); j++; 
				object_collision( j ); j++; 
				object_collision( j ); j++; 
			}
*/

/*
			// Amortized: handle a chunk of obstacles on every physics frame. 
			// Hmm. Collision tests +/- 2, but I suspect it still misses some hits. 
			// If I went back to object_collision taking obstacle number as an argument, 
				// I could mark and test some close-up objects more often. 
			// But if I could do that I don't know why I'd bother testing anything else. 
			// You almost definitely just breeze through some obstacles. Bleh. 
			object_collision( ); 
			object_collision( ); 
			object_collision( ); 
			object_collision( ); 

			object_collision( ); 
			object_collision( ); 
			object_collision( ); 
			object_collision( ); 
*/

			// Amortize moving obstacles to a short list of things near enough to care about. 
			// Ah, fuck - we add obstacles multiple times. 
			is_obstacle_close( ); 		// Implicity, argument is j, and j++ is a side effect. 
			is_obstacle_close( );
			is_obstacle_close( );
			is_obstacle_close( );

			if( j >= MAX_OBSTACLES ) { j = 0; } 

			// Properly test nearby obstacles. 
			for( uint8_t ob = 0; ob < nearby_obstacle_count; ob++ ) { 
				if( object_collision( ob ) ) { 		// Returns true if we've moved past this obstacle. 
					// Take obstacle from end of list. 
					nearby_obstacles[ ob ] = nearby_obstacles[ nearby_obstacle_count - 1 ];
					// Shorten list. 
					nearby_obstacle_count--; 
					// Avoid repeating or skipping any nearby obstacles. 
					ob--; 
				}
			}



			if( hit ) { 
				// More serious use of this will set "you got smacked" flag, and trigger i-frames and animation. 
				// Variable framerate makes the screen-shake weird. 
				// Add another variable that only updates on rendered frames. 
				hit--; 
				// Debug: no screen shake. 
				if( hit ) { 
					pan_x = ( hit_shake & 0x02 ) * 2 - 4; 		// Oscillate between +/- 4
					pan_y = 3 * ( hit_shake & 0x01 ); 		// Oscillate between +/- 3
				} else { 
					pan_x = pan_y = 0; 		// Reset when done hurting
//					invincible = 0; 		// If there's a power-up for this, beware of no-harm collisions turning it off. 
				}

			} 


			}		// Debug obstacles_on conditional



		} 		// Physics / controls for-loop 
//		if( hit_shake ) { hit_shake--; } 		// Framerate-dependent screen shake from impact. 
		hit_shake--; 		// Avoid conditional - underflow makes no difference. 




		// Curve test
		input = joypad(); 		// Debug - buffered input no longer fills this old global variable. 
//		if( input & J_UP ) { curve_x += 1; } 
//		if( input & J_DOWN ) { curve_x -= 1; }
		// Manual curve-bend-twist effect: 
//		if( input & J_UP ) { if( twist_factor < 4 ) { twist_factor += 1; } } 
//		if( input & J_DOWN ) { if( twist_factor > -4 ) { twist_factor -= 1; } }  
		// Manual screen shift left / right: 
//		if( input & J_B ) { pan_x += 5; } 
//		if( input & J_A ) { pan_x -= 5; } 
		// Manual tunnel advance / reverse:
//		if( input & J_B ) { scroller_x += 5; } 
//		if( input & J_A ) { scroller_x -= 5; } 
		// Manual forward speed changes:
		if( input & J_UP ) { move_speed++; } 
		if( input & J_DOWN ) { if( move_speed > 0 ) { move_speed--; } }  

		if( input & J_A ) { if( obstacles_on ) { obstacles_on = 0; } else { obstacles_on = 1; } }
		// Enable / disable obstacles, while I fuck with physics

		// Get >>twist_degree from twist_factor -4..4.
		// No need for conditions because this goes unused if twist_factor == 0. 
		twist_degree = 4 - abs( twist_factor ); 
		pan_x = 8 * -twist_factor; 		// Slide the screen to indicate inertial force. 

		// Screen placement
		// Use fine hardware scrolling, you ding-dong. 
		const int8_t half_rotation = rotation / 2; 

		// "Evelyn" keeps barking about these.
		// Possibly because we're currently ignoring physics?
		int8_t scroll_x = -half_rotation; 		// Much cleaner. 
		if( rotation > 64 ) { scroll_x = -64 + half_rotation; } 		// Past the horizon, reverse back toward 0. 
		else if( rotation < -64 ) { scroll_x = 64 + half_rotation; } 

		int8_t scroll_y = ( abs( half_rotation ) >> 2 );  		// Don't reverse Y when upside-down. 
		// Nudge screen upward when crossing panel edges? Prior notes:
			// Make xstart follow rotation, so the camera tracks a car going up the wall. 
				// I'm okay with the chunky motion up and down, because it kinda matches where your car hits an angled wall. 
			// (Though sloppy correlation is fine because I do like the coincidental transition between facets.) 


		// Debug - no sliding around while dorking with curves:
//		scroll_x = scroll_y = 0; 
		scroll_y += pan_y; 
		scroll_x += pan_x; 

		// The simple fix is to always render 32x18. That'll at least let us figure out if we're tracking sensibly. Perf later. 
		// Setting SCX/SCY_REG eventually has to go in the vblank interrupt, for when we do double-buffering and vsync. 
		uint8_t scx = scroll_x + 8*((32-20)/2); 		// Okay, sure. 8x for bytes, not bits. 
		uint8_t scy = scroll_y + 8*(32-18)/2 + 32; 		// Jumble of constants is to center the screen. (And offset Y.) 
		SCX_REG = scx; 		// This indirection (scx -> SCX_REG) might be redundant. It was intended for ystart etc. 
		SCY_REG = scy; 

		// Rendering 
		// Simplify panning: the logical screen is always 32x32 tiles. We just try not to draw what we can't see. 
		// The stupid version of this is to check x and y in each loop and "continue" if they're fully offscreen. 

		// Note: for-y and for-y loops don't use WIDTH / HEIGHT because we're still only drawing 20x18. 
		// "Evelyn" keeps barking about this: 
		const int8_t ystart = scy / 8; 
		const int8_t xstart = scx / 8; 
		const int8_t ystop = ystart + 17; 
		const int8_t xstop = xstart + 21;  
			// Screen is 18 tiles tall. +1 for overlap... except we're kinda covering up the bottom with some HUD stuff. 
			// Yeah, place the window to cover up two rows. We get a whole extra frame per second. 

//		tile_count = 0; 		// How much are we drawing? 










		// MAIN BG RENDERING LOOP IS RIGHT HERE
		// (It really gets lost now that it's a for-for-function blip.) 

		// Twisting is not centered on where the player is, so fix how it looks. 
		#define TWIST_CORRECTION 4
		rotation += twist_factor * TWIST_CORRECTION; 

		// Smaller window for testing physics under a higher framerate.
		// ystart + 4 and ystop - 4 for narrower window, when higher framerate is required for testing. 
//		xplus = 1;

		vram_pointer = get_bkg_xy_addr( xstart, ystart );
		for( y = ystart; y < ystop; y++ ) { 
//			for( x = xstart; x < xstop; x++ ) { 
//				draw_tile(); 

			// Unrolled loop, three groups of seven. 
			x = xstart;
			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
 
			vram_pointer += ( 32 - 21 );
		}
		// A second for-loop would go right about here (or inside for-y) if we can be faster than set_vram_byte. 

/*
		// Narrow view, for higher-framerate testing. (Physics, controls, sprite performance, etc.) 
		vram_pointer = get_bkg_xy_addr( xstart+4, ystart+4 );
		for( y = ystart+4; y < ystop-4; y++ ) { 
			// Loop unrolling test. Wow - 9.3 to 12.0 FPS. 
			x = xstart+4;
			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
			draw_tile(); x++; 
			draw_tile(); x++; 
			draw_tile(); x++; 

			draw_tile(); x++;
 
			vram_pointer += ( 32 - 21 + 8 );  
		}
*/

		// Undo twisting displacement. Only the background needs adjustment. 
		// Nope, sprites need it too. 
		// (Physics / collision stuff happens -before- this, and is not affected by anything graphical.) 
		rotation -= twist_factor * TWIST_CORRECTION; 









		// Sprite stuff

		// BG coordinate system is scrolled to center tilemap, more or less. 
		// Might remove +4s so larger sprites don't have to account for it. 
		const int8_t center_x = 128 - scx + 4; 
		const int8_t center_y = -scy - 128 + 8+4;  		// This +8 makes no sense, but whatever. 

		// Obstacle-oriented sprite generation. 
		// MAX_OBSTACLES likely to be 32, so we always have some sprites left over for the player and so on. 
		// This still fucks up rendering sometimes. I think GBDK assumes you'll only do 40 sprites.
			// But it'd be faster to allocate 64 slots for sprites, and have OAM DMA pretend there's only 40. 
		// OAM_item_t seems to be the type. 
		// SET_SHADOW_OAM_ADDRESS( void* address ). 
		// So... OAM_item_t sprite_array[ 64 ]; then use &sprite_array? 
		// Still causes random panning. God dammit. 
			// Slim chance the panning is from collision code. "hit" makes the screen wobble. 
			// Eh, did some burn-in with <40-4 and it seems fine. Good enough.

		// Twisting rotation for sprites, yeah? 
		#define SPRITE_TWIST_CORRECTION 4
//		rotation += twist_factor * TWIST_CORRECTION; 
		rotation += twist_factor * SPRITE_TWIST_CORRECTION; 


		// Opportunistic partial sorting? I.e., track lowest empty obstacle slot, and if anything's especially close, move it there. 
		// The intent being, try to always draw big close-up obstacles, and if we miss a few distant blips then oh well. 
		int8_t free_sprite = 8; 		// Lowest available sprite. 8 is a wild guess for the player's needs.  
		if( obstacles_on ) {
		for( uint8_t ob = 0; ob < MAX_OBSTACLES && free_sprite < 40 - 4; ob++ ) { 	// Can't draw if no sprites are free. 

//			free_sprite = 8;		// Debug: reuse the first few sprites. See if we get rendering errors. 

			// If this obstacle exists, and is within visible range, draw it. 
			// scroller_x logic felt backwards because distance is backwards. The table is fucky.  
				// Changed distance_sample so that obstacle_distance is distance from camera. 
			const uint8_t obstacle_distance = obstacles[ ob ].location - scroller_x; 
//			const int8_t obstacle_rotation = obstacles[ ob ].orientation + rotation;
			if( obstacles[ ob ].type 		// Might instead be .type, where 0 is empty and anything else is some enemy or barrier. 
				&& obstacle_distance < 64 		// Should be obstacle.position - scroller_x. (Too-close objects get removed.) 
//			if( obstacle_distance < 64
			) { 
				// Only calculate rotation if it's in range. 
				int8_t obstacle_rotation = obstacles[ ob ].orientation + rotation; 
				if( twist_factor ) { 		// twist_factor != 0 
					if( twist_factor > 0 ) { 
						obstacle_rotation += obstacle_distance >> twist_degree; 
					} else { 		// twist_factor < 0
						obstacle_rotation -= obstacle_distance >> twist_degree; 
					} 
				}

				// Gotta position the obstacle in screen-space before we can exclude offscreen obstacles. 
				// Change quadrant's values to match sprite-flipping properties. 
					// I.e. 0x40 if it's in the upper half, and 0x20 if we flip left/right from default. 
				int8_t quadrant = 0; 		// Default: upper left. 
					if( abs( obstacle_rotation ) < 64 ) { quadrant = 1; } 		// +1 if lower. (Rotation 0 is the bottom.) 
					if( obstacle_rotation < 0 ) { quadrant += 2; } 		// +2 if left? I think? Coordinate systems are agony. 

				// Does const matter here? 7.0 FPS with, 7.0 FPS without. shrug. 
				const int8_t distance_sample = 64 - ( obstacle_distance & 0x3F ); 
				int8_t d_rotation_sample = abs( obstacle_rotation % 64 ) / 4;

				int8_t osx, osy; 
				switch( quadrant ) { 		// 90-degree sine table, so cosine is sine backwards. 16 angles per quadrant. 
					case 0: 		// Upper left. 
					osx = center_x - sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ];
					osy = center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					break; 

					case 1: 		// Lower right. 
					osx = center_x - sin_from_polar[ d_rotation_sample ][ distance_sample ];
					osy = center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ];
					break; 

					case 2:		// Upper right. Despite all logic. 
					osx = center_x + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ]; 
					osy = center_y - sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					break; 

//					case 3:		// Lower left. 
					default:		// Silences compiler warning 84: osx / osy "may be used before initialization."
					osx = center_x + sin_from_polar[ d_rotation_sample ][ distance_sample ]; 
					osy = center_y + sin_from_polar[ ( 15 - d_rotation_sample ) ][ distance_sample ]; 
					break; 
				}

				// Mildly questionable pattern: 'exit early if it's bad,' rather and 'do the rest if it's good.' 
				// "Warning 94: comparison is always false due to limited range of data type." 
				// Ah, signed can't be more than +127. 
				// What a pain in the ass it is to fit a range from 0-160 inside 0-255. 
				// I guess subtract it down to some middle value, then check abs(that)? Shift range to +/- 80-ish. 
				// Obstacles disappearing early might be a math/logic error here. 
				// -16 gets shunted to 16, so just osx_abs>160+16 means 0..160. 
				const uint8_t osx_abs = osx + 16; 
				const uint8_t osy_abs = osy + 16; 
				if( osx_abs > ( 160 + 16 + 16 ) || osy_abs > ( 144 + 16 + 16 ) ) { 		// 16 on either side. Whoops. 
					continue; 
				}

				// Count on all obstacles being roughly the same size, for simplicity. 
				// Scale to 1x1, 2x2, 3x3, or 4x4 according to distance. 
				// 4x4 would be at maximum proximity, which is like 10 units. Possibly more, since we're not seeing all 32x32. 
				// Yeah, it's about 20. So "full scale" would be n/20=4, ergo 80. 
				// Bad answer: division. Good answer: table. Sensible answer: there's only four sizes; chain conditionals. 
				// 80/n=3, n = 26. 80/n=2, n = 40. Anything further is 1x1. (May get fudged for rounding.) 
				// The options are 15-20, 20-26, 26-40, and 40-127. 
				// 4x4 looks too big, too soon. Adjust cutoffs accordingly. 
				// 80/n = 1.5, n = 53. 2.5, n = 32. 3.5, n = 23. 4.5, n = 18. 

				// set_sprite_prop's second parameter: 0x40 for upside-down, 0x20 flip left/right, 0x10 second palette. 
				// DEBUG: &&0 on some conditionals so we always go for 1x1. 
				// Unsure how to handle lack of free sprites. 
					// I don't want to check if free_sprite < 40 for every one I add. 
					// I don't think they'll wrap around? Like if I assign some region as shadow OAM, it'll go past 40. 
					// Which means I could just allocate 64 sprites, and if the last one drawn needs 16 sprites,
						// but there's only 1 available, we'll just throw bytes into WRAM that never make it to VRAM. Shrug. 
				// Okay... this is backwards. Did not see that coming. 
				// The swap to 2x2 feels weirdly close. Maybe draw things at distance=64..127 with constant offset?
					// Like a ring barely off-center, so you know something's coming in a given facet. 
					// Ideally with some spritework for finer scaling. E.g. one 2x2-pixel blob up to an 8x8-pixel blob. 
				// Oh god. Finer scaling by overlapping sprites? 
					// Requires treating them as one size larger, and changing spacing. 
					// Otherwise you need an art style  where gaps look normal. 
				// Larger sprites should be offset a little higher, so the bases look well-placed. 
					// Mostly an issue with "3x3" sprites actually being 3x2. 
				const uint8_t cutoffs[] = { 20, 26, 40 }; 		// Separations for four phases. 
//				const uint8_t cutoffs[] = { 18, 32, 53 }; 		// Ehhh. 
//				const uint8_t cutoffs[] = { 10, 20, 30 }; 		// Oh just eyeball it. 
				if( obstacle_distance < cutoffs[1]  ) { 
					if( obstacle_distance < cutoffs[0] ) { 		// Closest, 4x4

//						const uint8_t osy_top = osy - 16; 		// No evident benefit. 
						place_sprite( free_sprite++, 0x00, 132, osx - 16, osy - 16 ); 
						place_sprite( free_sprite++, 0x00, 132, osx - 8, osy - 16 ); 
						place_sprite( free_sprite++, 0x00, 132, osx, osy - 16 ); 
						place_sprite( free_sprite++, 0x00, 132, osx + 8, osy - 16 ); 

						// Bottom row:
						place_sprite( free_sprite++, 0x00, 132, osx - 16, osy ); 
						place_sprite( free_sprite++, 0x00, 132, osx - 8, osy ); 
						place_sprite( free_sprite++, 0x00, 132, osx, osy ); 
						place_sprite( free_sprite++, 0x00, 132, osx + 8, osy ); 

					} else { 		// Second closest, 3x3
						// Woof, 3x3 with 8x16 sprites is going to be wasteful. 
						// Either we fudge things to 24x16 for three sprites - or we burn another three sprites as half-full. 

						place_sprite( free_sprite++, 0x00, 132, osx - 12, osy - 12 ); 
						place_sprite( free_sprite++, 0x00, 132, osx - 4, osy - 12 ); 
						place_sprite( free_sprite++, 0x00, 132, osx + 4, osy - 12 ); 

						// Bottom row?
						place_sprite( free_sprite++, 0x00, 132, osx - 12, osy - 4 ); 
						place_sprite( free_sprite++, 0x00, 132, osx - 4, osy - 4 ); 
						place_sprite( free_sprite++, 0x00, 132, osx + 4, osy - 4 ); 

					}
				} else {
					if( obstacle_distance < cutoffs[2] ) { 		// Third closest, 2x2

						// 8x16 sprites. One's x=-8 to x=0, other's x=0 to x=8. 
						// Ah fuck, we'd have to swap these if the h-flip property is set. 
						place_sprite( free_sprite++, 0x00, 132, osx - 8, osy - 8 ); 
						place_sprite( free_sprite++, 0x00, 132, osx, osy - 8 ); 

					} else { 		// Fourth closest, 1x1

						// Sprite flipping is conditional on quadrant, which we've already calculated. 
						// Oh: we could probably match that value to this. The switch-case literls are arbitrary. 
						// 8x16 sprites are still treated as 8x8. Their origin is unchanged. So: -4,-4. 
						place_sprite( free_sprite++, 0x00, 132, osx - 4, osy - 4 ); 

					}
				}

			} 	// Conditional for visible obstacles
		} 		// For loop over all obstacles
		} 		// Debug obstacles_on conditional 

		// Undo twisting rotation for sprites. 
		// Undo twisting displacement. Only the background needs adjustment. 
		// Nope, sprites need it too. 
		// (Physics / collision stuff happens -before- this, and is not affected by anything graphical.) 
		// This is still screwy, no pun intended. Sprites drift by nearly 45 degrees as the curve changes. 
//		rotation -= twist_factor * TWIST_CORRECTION;
		rotation -= twist_factor * SPRITE_TWIST_CORRECTION; 



		// Player sprite
		// Eventually: pick sprite based on turning direction etc. 
		// Eventually: handle projectile somewhere below this. 
		uint8_t px = center_x; 
		uint8_t py = center_y + 8*8; 

		// When sliding the screen around to emphasize a curve, move the player the other way. 
		// Uuugh this is going to make physics so weird. 
			// No: I just have to specify where the player's "zero" is. 
			// Add or subtract some relatively small int8_t value when checking obstacle orientation. 
		// But tilting the player sprite's gonna involve some goofy math. 
//		px += 8 * twist_factor; 		// Bluh, no, we need to go up the circle. 
			// Do I just use the obstacle sprite sine table? 
		// Player distance is ostensibly 20+ units from the camera. 
		// We know which quadrant we're using based on twist_factor's sign. 
		if( twist_factor ) { 
			int8_t p_rotation = 8 * twist_factor; 
			int8_t p_rotation_sample = abs( p_rotation % 64 ) / 4;
			if( twist_factor > 0 ) { 
	//			px -= sin_from_polar[ p_rotation_sample ][ 64 - 18 ]; 		// Accidentally keeps the player dead center. Neat. 
				px -= 2 * sin_from_polar[ p_rotation_sample ][ 64 - 18 ]; 
			} else { 
				px += 2 * sin_from_polar[ p_rotation_sample ][ 64 - 18 ];
			} 
			py += sin_from_polar[ 15 - p_rotation_sample ][ 64 - 18 ] - 5*8 - 3;
	//		py += sin_from_polar[ 15 - p_rotation_sample ][ 64 - 18 ] - 8*8;
		}

		// Tilt sprite using twist_factor. 
		// 2x 1x 1x 2x is more correct but very janky-looking. One-half-half-one was probably the right idea. 
		// Art could solve a lot of this. Low sides, flat bottom. Not a big dumb rectangle. Any wings / fins diagonal. 
		// Middle is goofy. In full tilt, sprites go bottom, +4, +8, +4. 
		// +2 / -2 was not the right answer. Looks good in exactly one place. 
		// Really, just don't do -2x, -1x... +1x, +2x. 
		// Alright, now it looks right, but the center might be a bit screwy in curves. Beware. 

		set_sprite_prop( 0, 0x00 ); 
		set_sprite_tile( 0, 134 ); 
		move_sprite( 0, px - 16, py - 2*twist_factor ); 

		set_sprite_prop( 1, 0x00 ); 
		set_sprite_tile( 1, 134 ); 
		move_sprite( 1, px - 8, py - twist_factor ); 

		set_sprite_prop( 2, 0x00 ); 
		set_sprite_tile( 2, 134 ); 
		move_sprite( 2, px, py ); 

		set_sprite_prop( 3, 0x00 ); 
		set_sprite_tile( 3, 134 ); 
		move_sprite( 3, px + 8, py + twist_factor ); 

		// No reason to set properties and graphics every frame. Not for the player. 
		// (Okay maybe the middle ones get animated for a flickering jet plume.) 
		// No major performance difference. 
/*
		move_sprite( 0, px - 16, py - 2*twist_factor ); 
		move_sprite( 1, px - 8, py - twist_factor ); 
		move_sprite( 2, px, py ); 
		move_sprite( 3, px + 8, py + twist_factor ); 
*/





		// Clear unused sprites: 
		// This probably shouldn't be its own for-loop. 
		// Check if doing this at the front, unrolled, is faster. 
		for( uint8_t c = free_sprite; c < 40; c++ ) { 
			move_sprite( c, 0, 150 ); 		// Betting 150 beats 0,0 because OAM search will never see it. 
		} 

		// Print framerate. Fine performance can be tracked by updating during hblank routine, if needed / applicable. 
		// Numeral sprites start at 16. 
		// Oh of course these have a meaningful impact on framerate. Possibly just because of division. 
		// I should make this a function. 
		const uint16_t this_frame = line_count; 
		line_count = 0; 

		// Very long running average. 
		running_average = ( running_average << 5 ) - ( running_average >> 1 ) + ( this_frame >> 1 ); 
		running_average = running_average >> 5; 

		const uint16_t fps = ( 60 * 144 ) / ( running_average / 10 ); 

		vram_pointer = get_win_xy_addr( 0, 0 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 100) % 10 ) + 16 );
		set_vram_byte( ( vram_pointer++ ),  ( (fps / 10) % 10 ) + 16 );
 		set_vram_byte( ( vram_pointer++ ),  14 ); 		// Decimal point. 
		set_vram_byte( ( vram_pointer++ ),  ( (fps ) % 10 ) + 16 );

		// Variable framerate: divide line count by 144. 
			// And possibly modulo by 144? Rollover would keep things more accurate. 
		field_count = ( this_frame + field_overflow ) / 144; 		// field_overflow from previous render
		field_overflow = this_frame % 144;

		// 30 Hz gameplay instead? 
		// Might need to change how input buffers work. It's in a vblank ISR - locked at 60 Hz. 
//		field_count = ( this_frame + field_overflow ) / 288; 		// field_overflow from previous render
//		field_overflow = this_frame % 288;  

//		field_count = 1; 		// Debug - go slowly

		// We don't want to wait unless we're hitting 60 Hz, which, no. 
		// Well, maybe for double-buffering. (That should still be at the start of vblank... not the end.)
//		wait_vbl_done();	
	}
}



// Display raw line_count as well, because why not. 
// (Or whatever else I want to track.)
// this_frame, field_count, rotation, tile_count, curve_x, velocity, 
	// twist_factor, twist_degree, pan_x, move_speed, side (ish), 
void debug_output( uint8_t variable, uint8_t xpos, uint8_t ypos ) { 
	vram_pointer = get_win_xy_addr( xpos, ypos );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable / 100) % 10 ) + 16 );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable / 10) % 10 ) + 16 );
	set_vram_byte( ( vram_pointer++ ),  ( ( variable ) % 10 ) + 16 );
} 






void draw_tile() { 

	// DRY: use variable for sampling shenanigans. (Eventually for Y as well.)
	// Is const faster? Yeah, wow: 6.4 FPS with a reused global variable, 6.6 with const distance, 6.8 for both. 
		// Presumably thanks to informing the compiler it's just a scratch value. 
	//	uint8_t distance = distance_table[ x + 32 * y ] + scroller_x;
	//	uint8_t angle = angle_table[ x + 32 * y ] + rotation;

	// You idiot - twist the tunnel. Add rotation based on distance. 
	uint8_t distance_sample = distance_table[ x + 32 * y ]; 		// Distance from camera, for twist. 
	uint8_t distance = distance_sample + scroller_x; 		// Objective position as camera moves through tube. 

	uint8_t angle = angle_table[ x + 32 * y ] + rotation; 
	if( twist_factor ) {
		int8_t twist_rotation = distance_sample >> twist_degree;

		// Cheap curve hack: shift samples closer "inside" the bend. 
		// Hmm. Questionably useful. Cheap, though. 
	//	distance += twist_factor * y; 		// The wrong answer for some reason? 
	//	distance += y >> 2; 

		if( twist_factor < 0 ) { twist_rotation = -twist_rotation; }
		angle += twist_rotation;
	}

	uint8_t outbyte = tube_color[ angle ];

	// Tube segments in slightly different colors:
//	outbyte += ( distance & 0b110000 ) == 0 ? ( distance & 0b00001111 ) >> 2 : 0; 
//	if( ( distance & 0b110000 ) == 0 ) { outbyte -= ( distance & 0b00001111 ) >> 2; } 
//	outbyte -= ( distance & 0b110000 ) * ( ( distance & 0b00001111 ) >> 2 ); 		// Very no. 
	outbyte -= ( ( distance >> 5 ) & 0x03 ) ^ 0x2; 
		// >>4 &0x1 for short rings, >>5 &0x1 (or >>4 &0x2) for long rings, 
			// >>4 &0x3 for four-stage sawtooth pattern. 
		// &0x5 doesn't quite work, for lack of range. Shame. It breaks up the sawtooth look. 
		// Adding ^0x2 does nothing. Odd. 

	// Bottom path
	// With the >>5 &0x03 stuff, the tube segments look more like lighting. 
	// Chevrons in dark areas are darker. So maybe we'd rather ramp tube colors up and down. But yikes. 
	uint8_t diagonal = angle - 4*43; 
	outbyte += ( ( diagonal < 43 ) && ! ( distance & 0b1100 ) ); 		// Chevrons

//	set_vram_byte( vram_pointer++, tube_color[ angle ] );
	set_vram_byte( vram_pointer++, outbyte & 0x8F );

	// Distance rings. 
//	const uint8_t chokes = ( distance & 0b110000 ) == 0 ? ( distance & 0b00001111 ) >> 2 : 0;

} 






void place_sprite( uint8_t object, uint8_t properties, uint8_t graphic, uint8_t x, uint8_t y ) { 
	set_sprite_prop( object, properties ); 
	set_sprite_tile( object, graphic ); 
	move_sprite( object, x, y ); 
}







void is_obstacle_close( ) {
	j++; 
	// const uint8_t obstacle_distance = obstacles[ j ] whatever
	const uint8_t obstacle_distance = obstacles[ j ].location - scroller_x; 
	if( obstacle_distance < 16 ) { 		// Wild stab. 
		nearby_obstacle_count++; 		// Pointer, not counter. 
		nearby_obstacles[ nearby_obstacle_count ] = j; 
	} 
}



//void object_collision( uint8_t j ) {
//void object_collision( ) {  
uint8_t object_collision( uint8_t j ) {
//	j++; 

	if( obstacles[ j ].type == 0 ) { return 0; } 
	// Implicit else:
	const uint8_t obstacle_distance = obstacles[ j ].location - scroller_x; 
	if( obstacle_distance > 10+2 ) { return 0; } 		// Early out for anything too far-off. 

	// Remove obstacles that should be past and offscreen. 
	if( obstacle_distance < 3 ) { 
		obstacles[ j ].type = 0; 

		// Remove obstacle from nearby_obstacles
		return 1; 
	} 

	// Don't need to know rotation until after the early exits pass. 
	const int8_t obstacle_rotation = obstacles[ j ].orientation + rotation; 

	// If we're doing dead hit versus glancing blow, rotation +/- 8 versus +/- 16 seems about right. 
	// Hm. Maybe a little tigher than that, if the jank is not just framerate and sprite centering. 
	if( ! hit &&
		obstacle_distance > 10-2 && 		// +/- 2 seems about right.  
		obstacle_rotation < 16 && obstacle_rotation > -16 ) 		// A hair wide? 
	{
		hit = 30; 	// This is measured in fields. Physics are 60 Hz. 
	} 

	return 0; 

} 


















